-- Stamina locomotion and persistent One Life rules. Native save files are never deleted.
return function(T)
    local U,R=T.U,T.rules
    local function current(args,address)
        return address~=nil and U.address(U.object(args[2]))==address
    end
    local walk_overrides={}
    function T.restore_stamina()
        U.restore_properties(walk_overrides)
        local entry=T.stamina_layer
        if entry then
            pcall(function()
                local now=U.call(entry.layer,"get_Speed")
                if type(now)=="number" and math.abs(now-entry.applied)<0.00001 then entry.layer:call("set_Speed",entry.base) end
            end)
        end
        T.stamina_layer=nil
    end
    function T.enforce_stamina(updater)
        if not updater or U.address(updater)~=T.updater_addr then return end
        if not T.c.enabled or not T.active or not T.s.exhausted or not T.locomotion_safe then
            T.restore_stamina();return
        end
        local input=U.call(updater,"get_InputUnit")
        if input then input:call("set_IsRunSwitch",false) end
        local moving=U.call(input,"get_IsMoveInput")==true or T.moving
        if moving then
            U.override_property(walk_overrides,updater,"ForceToWalkLoopRequest","System.Boolean",true)
            U.override_property(walk_overrides,updater,"ForceToWalkLoop","System.Boolean",true)
            U.override_property(walk_overrides,updater,"ForceToRunLoop","System.Boolean",false)
            T.mark("stamina_walk_forced")
        else U.restore_properties(walk_overrides) end
    end
    function T.update_stamina_motion(ctx)
        local common=U.call(ctx,"get_Common")
        local moving=U.call(common,"get_IsRun")==true or U.call(common,"get_IsWalk")==true
            or U.call(common,"get_IsHoldWalk")==true or T.moving
        if not T.c.enabled or not T.active or not T.s.exhausted or not T.locomotion_safe
            or not moving or U.call(common,"get_IsReloading")==true then T.restore_stamina();return end
        local updater=U.call(ctx,"get_Updater");T.enforce_stamina(updater)
        local motion=U.call(U.call(ctx,"get_GameObject"),"getComponent(System.Type)",sdk.typeof("via.motion.Motion"))
        local layer=U.call(motion,"getLayer",0)
        local speed=U.call(layer,"get_Speed")
        if type(speed)~="number" or speed<=0 then U.note("stamina_motion","missing","No active player locomotion layer");return end
        local entry=T.stamina_layer
        if not entry or U.address(entry.layer)~=U.address(layer) then
            T.restore_stamina();entry={layer=layer,base=speed};T.stamina_layer=entry
        elseif math.abs(speed-(entry.applied or speed))>0.00001 then entry.base=speed end
        local running=U.call(common,"get_IsRun")==true
        local factor=running and T.c.stamina_exhausted_run or T.c.stamina_exhausted_walk
        local desired=entry.base*factor
        layer:call("set_Speed",desired);entry.applied=desired
        T.enforce_stamina(updater)
        T.mark("stamina_motion_scaled");U.note("stamina_motion","observed","Scaled live locomotion playback; input forced to walk")
    end
    function T.prepare_survival(ctx,updater,common)
        T.player_ctx_addr=U.address(ctx);T.common=common
        local input=U.call(updater,"get_InputUnit")
        T.input_addr=U.address(input)
        local terrain=U.call(common,"get_IsTerrainAction")==true
        local damage=U.call(common,"get_IsDamageAction")==true
        local riding=U.call(updater,"get_IsHoldOnRide")==true
        T.locomotion_safe=not terrain and not damage and not riding
        T.sprinting=T.locomotion_safe and U.call(common,"get_IsRun")==true
        T.moving=T.sprinting or U.call(common,"get_IsWalk")==true
            or U.call(common,"get_IsHoldWalk")==true or U.call(input,"get_IsMoveInput")==true
    end
    U.hook("stamina_sprint_gate",U.method("app.PlayerInputBlackboardUnit","get_IsRunSwitch",{},"System.Boolean"),
        function(args,call) call.blocked=T.c.enabled and T.active and T.s.exhausted and current(args,T.input_addr) end,
        function(ret,call)
            if call.blocked then T.mark("stamina_sprint_blocked");return sdk.to_ptr(false) end
            return ret
        end)
    -- The direct setter also covers an inlined sprint-switch getter.
    U.hook("stamina_run_input",U.method("app.PlayerUpdaterBase","updateMoveIntensity",{},"System.Void"),function(args,call)
        if current(args,T.updater_addr) then call.updater=U.object(args[2]);T.enforce_stamina(call.updater) end
    end,function(ret,call) if call.updater then T.enforce_stamina(call.updater) end;return ret end)
    U.hook("stamina_after_input",U.method("app.PlayerInputDriver","applyInputAfter",{},"System.Void"),function(args,call)
        local driver=U.object(args[2]);local updater=U.call(driver,"get_Updater") or U.field(driver,"_Updater")
        if U.address(updater)==T.updater_addr then call.updater=updater end
    end,function(ret,call) if call.updater then T.enforce_stamina(call.updater) end;return ret end)
    -- Only One Life's death lock uses this translation gate. Exhaustion uses
    -- post-input walk requests and the active locomotion layer instead.
    local vectors={}
    U.hook("stamina_movement",U.method("app.PlayerUpdaterBase","scaleMovement",{"via.vec3","via.Quaternion"},"System.Void"),
        function(args,call)
            if not current(args,T.updater_addr) then return end
            local locked=R.run_locked(T.s)
            if not locked then return end
            local ptr=args[3];local key=tostring(ptr)
            if vectors[key] then return end
            local td=U.type("via.vec3");if not td then return end
            local original={}
            for _,axis in ipairs({"x","y","z"}) do
                local v=sdk.get_native_field(ptr,td,axis)
                if type(v)~="number" or v~=v or math.abs(v)>100000 then return end
                original[axis]=v
            end
            local factor=0
            call.vector={ptr=ptr,key=key,td=td,original=original};vectors[key]=true
            for axis,value in pairs(original) do sdk.set_native_field(ptr,td,axis,value*factor) end
            T.mark(locked and "one_life_movement_blocked" or "stamina_movement_scaled")
        end,function(ret,call)
            local v=call.vector
            if v then
                -- Always release nesting protection even if a native field write fails.
                for axis,value in pairs(v.original) do pcall(sdk.set_native_field,v.ptr,v.td,axis,value) end
                vectors[v.key]=nil
            end
            return ret
        end)
    function T.player_died()
        if T.s.await_new_player then return end
        if T.s.easy_pending then return end
        if R.player_died(T.s) then
            T.pending_manual_save=false;T.save_tx=nil
            T.toast("one_life_dead");T.mark("one_life_death");T.flush_soon=true
            -- Flush in the death callback, rather than waiting for a later frame.
            if T.persist then T.persist() end
        end
    end
    U.hook("one_life_death",U.method("app.PlayerUpdaterBase","onDead",{},"System.Void"),function(args)
        if current(args,T.updater_addr) then T.player_died() end
    end)
    U.hook("one_life_context_death",U.method("app.CharacterContext","onDead",{"System.Int32"},"System.Void"),function(args)
        if current(args,T.player_ctx_addr) then T.player_died() end
    end)
    U.hook("one_life_new_game",U.method("app.CharacterManager","setupNewgame",{"app.NewgameSetupEventArgs"},"System.Void"),
        nil,function(ret)
            -- The actual setup callback, never a button press / rejected request.
            if T.c.enabled or T.s.one_life then
                T.s=R.new_campaign(T.s,T.c);T.active=false;T.was_panic=false
                if T.restore_stamina then T.restore_stamina() end
                if T.restore_panic_camera then T.restore_panic_camera() end
                T.pending_manual_save=false;T.save_tx=nil;T.light_blocked=T.s.light_latched
                T.easy_anchor=nil;T.easy_ctx=nil;T.easy_updater=nil;T.easy_request=nil
                T.toast("new_game_started");T.mark("new_game_started");T.flush_soon=true
                if T.persist then T.persist() end
            end
            return ret
        end)
    local function segment_key(segment)
        if type(segment)=="number" then return tostring(math.floor(segment)) end
        -- Enum value types and numeric hook arguments must produce the same key.
        local value=U.field(segment,"value__")
        if type(value)=="number" then return tostring(math.floor(value)) end
    end
    local function slot_key(segment,id)
        local seg=segment_key(segment)
        if not seg or type(id)~="number" or id<0 or id~=math.floor(id) then return nil end
        return seg..":"..tostring(id)
    end
    function T.record_life_save(address)
        if not T.s.one_life or R.run_locked(T.s) then return end
        local key=slot_key(U.call(address,"get_Segment"),U.call(address,"get_SlotId"))
        if key then T.s.life_slots[key]=true;T.mark("one_life_resume_slot")
        else U.note("one_life_slot_identity","missing","Could not identify the successful save; resume remains blocked") end
    end
    local function blocked(call,reason)
        call.blocked=true;T.toast(reason or "one_life_old_save");T.mark("one_life_load_blocked")
        return sdk.PreHookResult.SKIP_ORIGINAL
    end
    -- These gates deliberately remain active for an armed run even when the
    -- general mod checkbox is off. A dead attempt cannot be revived that way.
    U.hook("one_life_load_category",U.method("app.SaveServiceManager","requestLoadCore",{
        "app.SaveSlotCategory","System.Int32","System.Nullable`1<app.SavedataLoadRequestArgs>"},"System.Boolean"),
        function(args,call)
            if not T.s.one_life then return end
            local category=sdk.to_int64(args[3])
            if category==1 or category==4 or category==5 then return end
            if R.run_locked(T.s) then return blocked(call,"one_life_dead") end
            -- All gameplay categories other than manual saves are forbidden.
            if category~=3 then return blocked(call,"one_life_old_save") end
            -- The category overload can inline its final slot overload. Resolve
            -- and enforce the slot here as well, before the native load starts.
            local ok,key=pcall(function()
                local nullable_type=U.type("System.Nullable`1<app.SaveSlotSegmentType>")
                local segment=nullable_type and ValueType.new(nullable_type) or nil
                local address=U.call(U.object(args[2]),"getSaveSlotAddress(app.SaveSlotCategory, System.Int32, System.Nullable`1<app.SaveSlotSegmentType>)",
                    category,sdk.to_int64(args[4]),segment)
                return slot_key(U.call(address,"get_Segment"),U.call(address,"get_SlotId"))
            end)
            local allow,reason=R.life_load_allowed(T.s,ok and key or nil)
            if not allow then return blocked(call,reason) end
        end,function(ret,call) if call.blocked then return sdk.to_ptr(false) end;return ret end)
    U.hook("one_life_load_slot",U.method("app.SaveServiceManager","requestLoadCore",{
        "app.SaveSlotSegmentType","System.Int32","System.Nullable`1<app.SavedataLoadRequestArgs>"},"System.Boolean"),
        function(args,call)
            if not T.s.one_life then return end
            local segment=sdk.to_int64(args[3]);local id=sdk.to_int64(args[4])
            local ok,category=pcall(function()
                local address=ValueType.new(U.type("app.SaveSlotAddress"))
                address._Segment=U.object(args[3]) or segment;address._SlotId=id
                local index=U.call(U.object(args[2]),"getSaveSlotIndex(app.SaveSlotAddress)",address)
                return U.call(index,"get_Category")
            end)
            if ok and (category==1 or category==4 or category==5) then return end
            if not ok or category~=3 then
                return blocked(call,R.run_locked(T.s) and "one_life_dead" or "one_life_old_save")
            end
            local allow,reason=R.life_load_allowed(T.s,slot_key(segment,id))
            if not allow then return blocked(call,reason) end
        end,function(ret,call) if call.blocked then return sdk.to_ptr(false) end;return ret end)
end
