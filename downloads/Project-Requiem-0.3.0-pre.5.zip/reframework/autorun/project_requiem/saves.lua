return function(T)
    local U,R=T.U,T.rules
    local save_scopes={}
    local function push_category(category,call)
        local tid=thread.get_id();local stack=save_scopes[tid] or {}
        save_scopes[tid]=stack;stack[#stack+1]=category;call.scope_tid=tid
    end
    local function pop_category(call)
        local stack=call.scope_tid and save_scopes[call.scope_tid]
        if stack then stack[#stack]=nil end
    end
    local function block_auto(call,category)
        call.blocked=true;T.mark("autosave_blocked");T.last_blocked_save_category=category
        return sdk.PreHookResult.SKIP_ORIGINAL
    end
    -- Guard the final segment/slot overload as well: address/index requests can
    -- bypass the category overload. Resolve their category with the engine's API.
    U.hook("autosave_write_gate",U.method("app.SaveServiceManager","requestSaveCore",{
        "app.SaveSlotSegmentType","System.Int32","System.Nullable`1<app.SavedataSaveRequestArgs>"},"System.Boolean"),function(args,call)
        if not T.c.enabled and not R.run_locked(T.s) then return end
        local stack=save_scopes[thread.get_id()]
        local scoped_category=stack and stack[#stack]
        local category
        local ok,result=pcall(function()
            local address=ValueType.new(U.type("app.SaveSlotAddress"))
            address._Segment=U.object(args[3]) or sdk.to_int64(args[3])
            address._SlotId=sdk.to_int64(args[4])
            local index=U.call(U.object(args[2]),"getSaveSlotIndex(app.SaveSlotAddress)",address)
            return U.call(index,"get_Category")
        end)
        if ok then category=result end
        if category==nil and scoped_category~=nil then
            -- Trust the native category-to-slot translation only when address
            -- lookup is unavailable. A resolved Auto slot always takes priority.
            category=scoped_category;T.mark("save_scope_category_fallback")
        end
        if R.auto_save_category(category) then return block_auto(call,category) end
        if category~=1 and category~=3 and category~=4 and category~=5 then
            call.blocked=true;T.mark("unclassified_save_blocked")
            return sdk.PreHookResult.SKIP_ORIGINAL
        end
        if category==3 and not T.pending_manual_save then
            call.blocked=true;T.mark("unapproved_manual_save_blocked")
            return sdk.PreHookResult.SKIP_ORIGINAL
        end
        if category==3 and R.run_locked(T.s) then
            call.blocked=true;T.mark("one_life_save_blocked")
            return sdk.PreHookResult.SKIP_ORIGINAL
        end
    end,function(ret,call) if call.blocked then return sdk.to_ptr(false) end;return ret end)
    local typ="app.GuiSaveLoadController.Unit"
    local use_name="<setupPhaseSaveStart>g__useSaveItem|35_1"
    local restore_name="<setupPhaseSaveStart>g__restoreSaveItem|35_2"
    local use=U.method(typ,use_name,{},"System.Void")
    local restore=U.method(typ,restore_name,{},"System.Void")
    if not use or not restore then
        U.note("save_restrictions","missing","Save UI implementation changed; save hooks disabled")
    end
    local function inventory()
        local m=U.method("app.GuiUtil","getInventory",{},"app.Inventory")
        return m and m:call(nil)
    end
    local function count(inv,id)
        return inv and id and U.call(inv,"countStock(app.ItemID)",id) or nil
    end
    local function consume(inv,id)
        local event=U.static("app.ItemStockChangedEventType","Default")
        return inv and id and event and U.call(inv,"consumeStock(app.ItemID, System.Int32, app.ItemStockChangedEventType)",id,1,event)==true
    end
    function T.refresh_ink()
        T.ink_id=U.static(typ,"SaveItemId")
        T.ink_id_name=U.name(T.ink_id)
        T.infinity_ink=U.static(typ,"InfinitySaveItemId")
    end
    U.hook("save_prepare",U.method(typ,"setupPhaseSaveStart",{},"System.Void"),function(args)
        if not T.c.enabled then return end
        T.refresh_ink()
        local unit=U.object(args[2]);local setting=U.call(unit,"get__OpenSetting")
        T.save_tx={unit_addr=U.address(unit),requires_ink=U.call(setting,"get_UseSaveItem")==true,
            ticket="ribbon-"..tostring(T.s.save_attempts+1),consumed=false,skip_restore=false}
    end)
    U.hook("save_ink_use",use,function(args,call)
        local tx=T.save_tx
        if not T.c.enabled or not tx or tx.unit_addr~=U.address(U.object(args[2])) or not tx.requires_ink then return end
        call.tx=tx;call.inv=inventory();call.before=count(call.inv,T.ink_id)
    end,function(ret,call)
        local tx=call.tx
        if tx then
            local after=count(call.inv,T.ink_id)
            tx.consumed=call.before and after and call.before>after or false
            -- A bonus infinite ribbon must not bypass the finite resource requirement.
            if not tx.consumed and call.before and call.before>0 then
                tx.consumed=consume(call.inv,T.ink_id)
            end
            T.mark("save_ink_use")
        end
        return ret
    end)
    U.hook("spoiled_ink_no_refund",restore,function(args)
        local tx=T.save_tx
        if T.c.enabled and tx and tx.skip_restore and tx.unit_addr==U.address(U.object(args[2])) then
            T.mark("spoiled_ink_no_refund");return sdk.PreHookResult.SKIP_ORIGINAL
        end
    end)
    U.hook("manual_save_gate",U.method("app.SaveServiceManager","requestSaveCore",{
        "app.SaveSlotCategory","System.Int32","System.Nullable`1<app.SavedataSaveRequestArgs>"},"System.Boolean"),function(args,call)
        if not T.c.enabled and not R.run_locked(T.s) then return end
        local category=sdk.to_int64(args[3])
        if R.auto_save_category(category) then return block_auto(call,category) end
        push_category(category,call)
        if category~=3 then return end
        if not use or not restore then call.blocked=true;return sdk.PreHookResult.SKIP_ORIGINAL end
        call.manual=true
        local allowed,reason=R.save_gate(T.s,T.c)
        local tx=T.save_tx
        if allowed and tx and tx.requires_ink then
            if not tx.consumed then allowed=false;reason="no_ink"
            else
                allowed,reason=R.ink_attempt(T.s,T.c,tx.ticket)
                tx.skip_restore=not allowed and reason=="spoiled"
                T.mark("ink_roll")
            end
        elseif allowed and not tx then
            -- Do not permit trainer / remote manual-save requests to evade the typewriter flow.
            allowed=false;reason="typewriter_only"
        end
        if not allowed then
            call.blocked=true
            local messages={quota="save_quota",cooldown="save_cooldown",spoiled="ink_spoiled",
                no_ink="ink_required",typewriter_only="typewriter_only",one_life_dead="one_life_dead"}
            T.toast(messages[reason] or "save_blocked");T.mark("manual_save_blocked")
            return sdk.PreHookResult.SKIP_ORIGINAL
        end
        T.pending_manual_save=true
    end,function(ret,call)
        pop_category(call)
        if call.blocked then return sdk.to_ptr(false) end
        if call.manual and sdk.to_int64(ret)==0 then T.pending_manual_save=false end
        return ret
    end)
    U.hook("save_finished",U.method("app.SaveServiceManagerBehaviorApp","onSaveFinished",{
        "app.SavedataSaveResultInfo"},"System.Void"),function(args)
        if (not T.c.enabled and not T.s.one_life) or not T.pending_manual_save then return end
        local result=U.object(args[3]);local address=U.call(result,"get_SlotAddress")
        if U.call(address,"get_Category")~=3 then return end
        T.pending_manual_save=false
        if U.call(result,"get_IsSucceeded")==true then
            if R.run_locked(T.s) then return end
            if T.record_life_save then T.record_life_save(address) end
            R.saved(T.s);T.mark("manual_save_success");T.flush_soon=true
            T.toast("save_success",T.s.saves,T.c.max_manual_saves)
            if T.s.one_life and T.persist then T.persist() end
        end
    end)
    U.hook("save_ui_closed",U.method(typ,"onClose",{"app.GuiSaveLoadHandle"},"System.Void"),nil,function(ret)
        T.save_tx=nil;return ret
    end)
    U.note("save_restrictions","installed","Finite ink / spoiled ink / quota; automatic gameplay saves forbidden; system settings save allowed")
end
