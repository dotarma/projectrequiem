-- PROJECT REQUIEM game-independent rules. No REFramework globals are accessed here.
local M = {}
M.VERSION = "0.3.0-pre.5"
M.TITLE = "Project Requiem"

local defaults = {
    enabled = true, language = "en", run_id = "run-1", seed = 9142026,
    enemy_toughness = 1.80, enemy_attack = 1.45, enemy_speed = 1.10,
    enemy_stagger = 0.65, weapon_damage = 0.70,
    fire_delay = 1.35, reload_duration = 1.50,
    heal_effect = 0.45, healing_keep_chance = 0.40,
    stress_gain_near = 1.8, stress_gain_low_hp = 0.9,
    stress_gain_dark = 0.35, stress_decay = 0.65,
    stress_per_hit = 8, stress_per_shot = 0.7,
    stamina_drain = 16, stamina_recovery = 12, stamina_recovery_delay = 2,
    stamina_recover_threshold = 25, stamina_exhausted_walk = 0.60,
    stamina_exhausted_run = 0.40, one_life = false, one_life_mode = "strict",
    jam_heat_per_shot = 0.18, jam_cool_per_second = 0.14,
    jam_min_heat = 0.40, jam_max_chance = 0.16, jam_clear_seconds = 3.0,
    flashlight_seconds = 180, lighter_seconds = 90,
    light_recharge_per_second = 0.15,
    max_manual_saves = 12, save_cooldown_seconds = 900,
    ink_failure_chance = 0.25, ink_keep_chance = 0.45,
    hud = true, hud_x = 28, hud_y = 80,
}
M.defaults = defaults
local ranges = {
    seed={1,2147483646}, enemy_toughness={1,6}, enemy_attack={1,5},
    enemy_speed={1,1.5}, enemy_stagger={0.1,1}, weapon_damage={0.1,1},
    fire_delay={1,4}, reload_duration={1,4}, heal_effect={0.1,1},
    healing_keep_chance={0,1}, stress_gain_near={0,10}, stress_gain_low_hp={0,10},
    stress_gain_dark={0,5}, stress_decay={0,5}, stress_per_hit={0,50},
    stress_per_shot={0,10}, jam_heat_per_shot={0,1}, jam_cool_per_second={0.01,2},
    stamina_drain={1,100}, stamina_recovery={1,100}, stamina_recovery_delay={0,30},
    stamina_recover_threshold={1,100}, stamina_exhausted_walk={0.1,1}, stamina_exhausted_run={0.1,1},
    jam_min_heat={0,1}, jam_max_chance={0,0.75}, jam_clear_seconds={0.5,30},
    flashlight_seconds={10,3600}, lighter_seconds={10,3600},
    light_recharge_per_second={0,1}, max_manual_saves={1,100},
    save_cooldown_seconds={0,7200}, ink_failure_chance={0,1}, ink_keep_chance={0,1},
    hud_x={0,10000},hud_y={0,10000},
}
function M.clamp(n,lo,hi) return math.max(lo,math.min(hi,n)) end
local function finite(n) return type(n)=="number" and n==n and n~=math.huge and n~=-math.huge end
function M.config(raw)
    local c = {}
    raw = type(raw)=="table" and raw or {}
    for k,v in pairs(defaults) do
        local input = raw[k]
        if ranges[k] and finite(input) then
            c[k] = M.clamp(input,ranges[k][1],ranges[k][2])
        elseif k=="language" and (input=="en" or input=="vi") then c[k]=input
        elseif k=="one_life_mode" and (input=="strict" or input=="easy") then c[k]=input
        elseif type(v)=="boolean" and type(input)=="boolean" then c[k]=input
        elseif k=="run_id" and type(input)=="string" and input:match("^[%w_-]+$") and #input<=48 then c[k]=input
        else c[k]=v end
    end
    c.seed=math.floor(c.seed); c.max_manual_saves=math.floor(c.max_manual_saves)
    return c
end
-- Park-Miller PRNG: isolated from other scripts' math.random state.
function M.next_random(state)
    state.rng = (state.rng * 48271) % 2147483647
    return state.rng / 2147483647
end
-- Stable location decision, so revisiting / reloading cannot reroll a world pickup.
function M.roll_key(seed,key)
    local h = math.floor(seed) % 2147483647
    for i=1,#key do h=(h*131+key:byte(i))%2147483647 end
    -- Mix trailing digits too; a raw polynomial hash clusters neighboring spawn IDs.
    for _=1,3 do h=(h*48271)%2147483647 end
    return h / 2147483647
end
function M.new_state(c,raw)
    raw=type(raw)=="table" and raw or {}
    local s={schema=1,run_id=c.run_id,rng=c.seed,stress=0,elapsed=0,panic=false,
        flashlight=c.flashlight_seconds,lighter=c.lighter_seconds,
        saves=0,last_save=-c.save_cooldown_seconds,save_attempts=0,
        spoiled_ink=0, shots=0, jams=0, guns={}, ink_decisions={},
        stamina=100,exhausted=false,stamina_rest=0,one_life=c.one_life,
        dead=false,death_elapsed=0,life_attempt=1,life_slots={},await_new_player=false,
        life_mode=c.one_life_mode,easy_pending=false,easy_deaths=0,death_drops={},
        light_latched={flashlight=false,lighter=false}}
    if raw.run_id~=c.run_id or raw.schema~=1 then return s end
    for k,range in pairs({stress={0,100},elapsed={0,1e9},flashlight={0,c.flashlight_seconds},
        lighter={0,c.lighter_seconds},saves={0,1e6},last_save={-7200,1e9},
        save_attempts={0,1e6},spoiled_ink={0,1e6},shots={0,1e9},jams={0,1e9},rng={1,2147483646},
        stamina={0,100},stamina_rest={0,30},death_elapsed={0,1e9},life_attempt={1,1e9}}) do
        if finite(raw[k]) then s[k]=M.clamp(raw[k],range[1],range[2]) end
    end
    s.rng=math.floor(s.rng)
    s.panic=raw.panic==true and s.stress>90 or s.stress>=100
    s.exhausted=s.stamina<=0 or (raw.exhausted==true and s.stamina<c.stamina_recover_threshold)
    s.one_life=raw.one_life==true or c.one_life
    if raw.one_life==true then s.life_mode=raw.life_mode=="easy" and "easy" or "strict" end
    s.dead=raw.dead==true and s.one_life
    s.easy_pending=raw.easy_pending==true and s.one_life and s.life_mode=="easy"
    if finite(raw.easy_deaths) then s.easy_deaths=math.floor(M.clamp(raw.easy_deaths,0,1e9)) end
    local budget=131072
    local function copy_json(v,depth)
        budget=budget-1;assert(budget>=0 and depth<=64,"Invalid death-drop ledger")
        if type(v)=="boolean" or (type(v)=="string" and #v<=4096) or finite(v) then return v end
        assert(type(v)=="table","Invalid death-drop data")
        local out={}
        for k,value in pairs(v) do
            assert((type(k)=="string" and #k<=192) or (finite(k) and k>=1 and k<=8192),"Invalid death-drop key")
            out[k]=copy_json(value,depth+1)
        end
        return out
    end
    if type(raw.death_drops)=="table" then
        local ok,copy=pcall(copy_json,raw.death_drops,0)
        if ok then s.death_drops=copy else s.easy_error="Invalid death-drop ledger";s.dead=s.one_life end
    end
    if type(raw.easy_error)=="string" then s.easy_error=raw.easy_error:sub(1,512) end
    s.await_new_player=raw.await_new_player==true and not s.dead
    for _,kind in ipairs({"flashlight","lighter"}) do
        local previous
        if type(raw.light_latched)=="table" then previous=raw.light_latched[kind] end
        s.light_latched[kind]=previous==true or (previous==nil and s[kind]<c[kind.."_seconds"]*0.15)
    end
    M.update_light_latches(s,c)
    s.life_attempt=math.floor(s.life_attempt)
    if type(raw.life_slots)=="table" then
        for k,v in pairs(raw.life_slots) do
            if type(k)=="string" and #k<=160 and v==true then s.life_slots[k]=true end
        end
    end
    for _,k in ipairs({"saves","save_attempts","spoiled_ink","shots","jams"}) do s[k]=math.floor(s[k]) end
    if type(raw.ink_decisions)=="table" then
        for k,v in pairs(raw.ink_decisions) do
            if type(k)=="string" and #k<=160 and type(v)=="boolean" then s.ink_decisions[k]=v end
        end
    end
    return s
end
function M.tick(s,c,dt,env)
    -- Only advance on positively identified live gameplay. Long stalls never drain resources.
    if not env or not env.active or M.run_locked(s) or not finite(dt) or dt<=0 or dt>0.5 then return end
    s.elapsed=s.elapsed+dt
    local sprinting=env.sprinting==true and not s.exhausted
    if sprinting then
        s.stamina=math.max(0,s.stamina-c.stamina_drain*dt)
        s.stamina_rest=c.stamina_recovery_delay
    else
        local recovering=math.max(0,dt-s.stamina_rest)
        s.stamina_rest=math.max(0,s.stamina_rest-dt)
        s.stamina=math.min(100,s.stamina+c.stamina_recovery*recovering*(env.moving and 0.5 or 1))
    end
    if s.stamina<=0 then s.exhausted=true
    elseif s.stamina>=c.stamina_recover_threshold then s.exhausted=false end
    local gain=0
    if env.near_enemy then gain=gain+c.stress_gain_near end
    if env.low_hp then gain=gain+c.stress_gain_low_hp end
    if env.dark then gain=gain+c.stress_gain_dark end
    if gain==0 then gain=-c.stress_decay end
    s.stress=M.clamp(s.stress+gain*dt,0,100)
    for _,g in pairs(s.guns) do g.heat=math.max(0,g.heat-c.jam_cool_per_second*dt) end
    for _,kind in ipairs({"flashlight","lighter"}) do
        local cap=c[kind.."_seconds"]
        if env[kind.."_on"] then s[kind]=math.max(0,s[kind]-dt)
        else s[kind]=math.min(cap,s[kind]+c.light_recharge_per_second*dt) end
    end
    M.panic_active(s)
    M.update_light_latches(s,c)
end
function M.update_light_latches(s,c)
    for _,kind in ipairs({"flashlight","lighter"}) do
        if s[kind]<=0 then s.light_latched[kind]=true
        elseif s[kind]+1e-6>=c[kind.."_seconds"]*0.15 then s.light_latched[kind]=false end
    end
end
-- Local quaternion offsets for the render camera and final projectile transform.
function M.rotation_offset(q,pitch,yaw,roll)
    if not q then return nil end
    for _,axis in ipairs({"x","y","z","w"}) do if not finite(q[axis]) then return nil end end
    local function mul(a,b)
        return {x=a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,
            y=a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,
            z=a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,
            w=a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z}
    end
    pitch,yaw,roll=math.rad(pitch)*0.5,math.rad(yaw)*0.5,math.rad(roll)*0.5
    local offset=mul(mul({x=0,y=math.sin(yaw),z=0,w=math.cos(yaw)},
        {x=math.sin(pitch),y=0,z=0,w=math.cos(pitch)}),{x=0,y=0,z=math.sin(roll),w=math.cos(roll)})
    local value=mul(q,offset);local length=math.sqrt(value.x^2+value.y^2+value.z^2+value.w^2)
    if length<0.001 then return nil end
    for axis,v in pairs(value) do value[axis]=v/length end
    return value
end
-- Hysteresis prevents a single quiet frame at 99.99 from cancelling the crisis.
function M.panic_active(s)
    if s.stress>=100 then s.panic=true elseif s.stress<=90 then s.panic=false end
    return s.panic==true
end
-- Rotate the native muzzle-to-target direction inside a bounded cone, preserving
-- range. No random draw here: aim updates must not perturb jam / ink RNG.
function M.panic_target(origin,target,phase,degrees)
    if not origin or not target then return nil end
    local x,y,z=target.x-origin.x,target.y-origin.y,target.z-origin.z
    local length=math.sqrt(x*x+y*y+z*z)
    if not finite(length) or length<0.01 then return nil end
    x,y,z=x/length,y/length,z/length
    local rx,ry,rz=z,0,-x
    if math.abs(y)>0.95 then rx,ry,rz=y,-x,0 end
    local rl=math.sqrt(rx*rx+ry*ry+rz*rz);rx,ry,rz=rx/rl,ry/rl,rz/rl
    local ux,uy,uz=y*rz-z*ry,z*rx-x*rz,x*ry-y*rx
    local angle=math.rad(M.clamp(degrees or 2.5,0,10))
    local a,b=math.cos(phase),math.sin(phase)
    local co,si=math.cos(angle),math.sin(angle)
    return {x=origin.x+length*(x*co+(rx*a+ux*b)*si),
        y=origin.y+length*(y*co+(ry*a+uy*b)*si),
        z=origin.z+length*(z*co+(rz*a+uz*b)*si)}
end
function M.hit(s,c,damage_fraction)
    s.stress=M.clamp(s.stress+c.stress_per_hit+M.clamp(damage_fraction or 0,0,1)*15,0,100)
end
function M.heal_factor(s,c) return c.heal_effect*(1-0.25*s.stress/100) end
function M.healed_hp(before,after,maximum,factor)
    if not finite(before) or not finite(after) or before<=0 or after<=before then return nil end
    return math.min(maximum,before+(after-before)*factor)
end
local function gun(s,key)
    local g=s.guns[key]
    if not g then g={heat=0,last_shot=-1e6,jammed=false,clear_at=nil};s.guns[key]=g end
    return g
end
function M.can_fire(s,c,key,base_interval)
    local g=gun(s,key)
    if g.jammed then return false,"jammed" end
    local interval=math.max(0,base_interval or 0)*(c.fire_delay)*(1+0.3*s.stress/100)
    if s.elapsed-g.last_shot+1e-6<interval then return false,"delay" end
    return true
end
function M.try_shot(s,c,key,base_interval)
    local allowed,reason=M.can_fire(s,c,key,base_interval)
    if not allowed then return false,reason end
    local g=gun(s,key)
    local chance=0
    if g.heat>=c.jam_min_heat then
        chance=c.jam_max_chance*g.heat*(0.5+0.5*s.stress/100)
    end
    if chance>0 and M.next_random(s)<chance then
        g.jammed=true;s.jams=s.jams+1
        return false,"new_jam"
    end
    return true
end
function M.shot_fired(s,c,key)
    local g=gun(s,key)
    g.heat=math.min(1,g.heat+c.jam_heat_per_shot)
    g.last_shot=s.elapsed;s.shots=s.shots+1
    s.stress=M.clamp(s.stress+c.stress_per_shot,0,100)
end
function M.begin_clear(s,c,key)
    local g=gun(s,key)
    if not g.jammed then return false end
    if not g.clear_at then g.clear_at=s.elapsed+c.jam_clear_seconds*(1+0.5*s.stress/100) end
    return true
end
function M.finish_clear(s,key)
    local g=gun(s,key)
    if not g.jammed or not g.clear_at or s.elapsed<g.clear_at then return false end
    g.jammed=false;g.clear_at=nil;g.heat=0.2
    return true
end
function M.is_jammed(s,key) return gun(s,key).jammed end
function M.gun_status(s,key)
    local g=gun(s,key)
    return {heat=g.heat,jammed=g.jammed,clear_remaining=g.clear_at and math.max(0,g.clear_at-s.elapsed) or nil}
end
function M.auto_save_category(category) return category==2 or (type(category)=="number" and category>=6 and category<=9) end
function M.light_allowed(s,kind) return (s[kind] or 0)>0 and not s.light_latched[kind] end
function M.keep_pickup(c,kind,stable_location)
    if not stable_location or stable_location=="" then return true end
    local chance=kind=="heal" and c.healing_keep_chance or (kind=="ink" and c.ink_keep_chance or 1)
    return M.roll_key(c.seed,c.run_id..":"..kind..":"..stable_location)<chance
end
function M.save_gate(s,c)
    if M.run_locked(s) then return false,"one_life_dead" end
    if s.saves>=c.max_manual_saves then return false,"quota" end
    if s.elapsed-s.last_save<c.save_cooldown_seconds then return false,"cooldown" end
    return true
end
-- One irreversible roll per consumed ribbon, not per frame/UI permission check.
function M.ink_attempt(s,c,ticket)
    local allow,reason=M.save_gate(s,c)
    if not allow then return false,reason end
    if ticket and s.ink_decisions[ticket]~=nil then
        return s.ink_decisions[ticket],s.ink_decisions[ticket] and "ok" or "spoiled"
    end
    local good=M.next_random(s)>=c.ink_failure_chance
    s.save_attempts=s.save_attempts+1
    if not good then s.spoiled_ink=s.spoiled_ink+1 end
    if ticket then s.ink_decisions[ticket]=good end
    return good,good and "ok" or "spoiled"
end
function M.saved(s)
    s.saves=s.saves+1;s.last_save=s.elapsed
end
function M.run_locked(s) return s.one_life==true and (s.dead==true or s.easy_pending==true) end
function M.easy_mode(s) return s.one_life==true and s.life_mode=="easy" end
function M.has_death_loot(s)
    for _,bag in ipairs(s.death_drops) do
        for _,item in ipairs(bag.items or {}) do if not item.claimed then return true end end
    end
    return false
end
function M.set_one_life(s,c,value,mode)
    if M.run_locked(s) then return false end
    mode=mode=="easy" and "easy" or "strict"
    if s.one_life==(value==true) and (not value or s.life_mode==mode) then return true end
    if M.has_death_loot(s) then return false,"easy_recover_first" end
    c.one_life=value==true;s.one_life=c.one_life
    c.one_life_mode=mode;s.life_mode=c.one_life_mode
    -- Arming a current campaign starts with no trusted resume slots. The next
    -- successful manual save establishes a slot belonging to this attempt.
    s.life_slots={}
    return true
end
function M.player_died(s)
    if not s.one_life or s.dead then return false end
    s.dead=true;s.death_elapsed=s.elapsed
    return true
end
function M.life_load_allowed(s,key)
    if not s.one_life then return true end
    if M.run_locked(s) then return false,s.easy_pending and "easy_pending_notice" or "one_life_dead" end
    if not key or s.life_slots[key]~=true then return false,"one_life_old_save" end
    return true
end
function M.new_campaign(s,c)
    local fresh=M.new_state(c)
    fresh.life_attempt=s.life_attempt+1
    fresh.await_new_player=true
    return fresh
end
function M.snapshot(s)
    local out={}
    for k,v in pairs(s) do if k~="guns" then out[k]=v end end
    return out
end
return M
