return function(T)
    local U,R=T.U,T.rules
    local function bind(key,typ,name,params,ret,pre,post)
        return U.hook(key,U.method(typ,name,params,ret),pre,post)
    end
    function T.scan_enemies(cm,ctx)
        T.near_enemy=false;T.enemy_hp_addrs={}
        local scan={sources={},listed=0,alive=0,near=0,dead=0,unpositioned=0,dormant_near=0}
        T.threat_scan=scan
        local seen={};local player_pos=U.position(ctx)
        local function inspect(e)
            local address=U.address(e)
            if not address or seen[address] then return end
            seen[address]=true;scan.listed=scan.listed+1
            local hp=U.get(e,"get_HitPoint","app.HitPoint")
            local health=U.call(hp,"get_CurrentHitPoint")
            local dead=U.get(e,"get_IsDead","System.Boolean")
            if dead==nil then dead=U.call(hp,"get_IsDead") end
            if dead==true or (type(health)=="number" and health<=0) then scan.dead=scan.dead+1;return end
            local go=U.get(e,"get_GameObject","via.GameObject")
            local spawned=U.get(e,"get_IsSpawn","System.Boolean")
            -- Suspended/ambush enemies can still be physically present threats.
            -- Reject despawned/pool contexts without a live object instead.
            if spawned~=true and not go then return end
            if U.get(e,"get_Valid","System.Boolean")==false then return end
            if go and (U.call(go,"get_Valid")==false or U.call(go,"get_Active")==false) then return end
            if type(health)~="number" and dead~=false then return end
            scan.alive=scan.alive+1
            local hp_address=U.address(hp)
            if hp_address and type(health)=="number" and health>0 then T.enemy_hp_addrs[hp_address]=true end
            local position=U.position(e)
            if not position or not player_pos then scan.unpositioned=scan.unpositioned+1;return end
            local distance=U.distance(player_pos,position)
            local kind=U.name(U.get(e,"get_KindID","app.CharacterKindID"))
            if not scan.nearest_distance or distance<scan.nearest_distance then
                scan.nearest_distance=distance;scan.nearest_kind=kind
            end
            if distance<=12 then
                scan.near=scan.near+1;T.near_enemy=true
                if U.get(e,"get_IsSuspended","System.Boolean")==true then scan.dormant_near=scan.dormant_near+1 end
            end
        end
        for _,getter in ipairs({"get_EnemyContextList","getSpawnedEnemyContextRefList","get_SpawnableContextList"}) do
            scan.sources[getter]=U.each(U.call(cm,getter),function(e)
                if getter~="get_SpawnableContextList" or U.is_a(e,"app.EnemyContext") then inspect(e) end
            end)
        end
        if T.near_enemy then T.mark("stress_near_enemy") end
        U.note("threat_scan",player_pos and "observed" or "missing",
            string.format("contexts=%d alive=%d near=%d missing_position=%d",scan.listed,scan.alive,scan.near,scan.unpositioned))
    end
    -- Do not apply scarcity to inventory transfers, crafting, shops or save restoration.
    -- Only world ItemCore objects, and only explicitly identified healing / ribbon IDs.
    local healing_ids={it00_00_000=true,it00_01_000=true,it40_20_000=true,it40_20_001=true,it40_30_000=true}
    local decisions={}
    function T.item_hidden(core)
        if not T.c.enabled or not core then return false end
        local id=U.name(U.call(core,"get_ItemID"))
        local kind=healing_ids[id] and "heal" or (id==T.ink_id_name and "ink" or nil)
        if not kind then return false end
        local cid=U.call(core,"get_ContextID")
        local location=U.name(cid)
        if not location or #location<8 or location=="app.ContextID" or location=="System.Guid" or location:find("userdata",1,true) or location:find("00000000%-0000%-0000%-0000%-000000000000") then
            local go=U.call(core,"get_GameObject");local xf=U.call(go,"get_Transform")
            local p=U.call(xf,"get_Position")
            if not p or not T.chapter or T.chapter=="" then return false end
            location=string.format("%s:%.2f:%.2f:%.2f",T.chapter,p.x,p.y,p.z)
        end
        local key=kind..":"..id..":"..location
        if decisions[key]==nil then decisions[key]=not R.keep_pickup(T.c,kind,id..":"..location) end
        return decisions[key]
    end
    bind("world_scarcity","app.ItemCore","updateGameObjectState",{"System.Boolean","System.Boolean"},"System.Void",function(args)
        if T.item_hidden(U.object(args[2])) then
            args[3]=sdk.to_ptr(false);args[4]=sdk.to_ptr(false);T.mark("hidden_world_item")
        end
    end)
    for _,spec in ipairs({{"canPickupTo","app.Inventory"},{"isInteractable","app.InteractTrigger"}}) do
        bind("scarcity_"..spec[1],"app.ItemCore",spec[1],{spec[2]},"System.Boolean",function(args,call)
            call.hidden=T.item_hidden(U.object(args[2]))
        end,function(ret,call) if call.hidden then return sdk.to_ptr(false) end;return ret end)
    end
    -- Enumeration names are engine identifiers, independent of UI language.
    local nonpause={InventoryTab=true,InventoryBg=true,InventoryItem=true,InventoryItemDescription=true,
        InventoryCraft=true,InventoryCraftV2=true,ItemBox=true,ItemBoxBg=true,ItemBoxTab=true}
    bind("inventory_live","app.GuiManager","setPause",{"app.GuiType","app.IGuiKey","System.Boolean"},"System.Void",function(args)
        if T.c.enabled and nonpause[U.name(U.object(args[3]))] and sdk.to_int64(args[5])~=0 then
            args[5]=sdk.to_ptr(false);T.mark("inventory_live")
        end
    end)
    bind("inventory_pause_unit","app.GuiInventoryController.Unit","setPause",{"System.Boolean"},"System.Void",function(args)
        if T.c.enabled and sdk.to_int64(args[3])~=0 then args[3]=sdk.to_ptr(false);T.mark("inventory_live") end
    end)
    for _,spec in ipairs({{"inventory","app.GuiInventoryController.Unit","app.GuiInventoryHandle"},
        {"itembox","app.GuiItemBoxController.Unit","app.GuiItemBoxHandle"}}) do
        bind(spec[1].."_open",spec[2],"onOpen",{},"System.Void",function()
            if T.c.enabled then T.open_panels[spec[1]]=true end
        end)
        bind(spec[1].."_close",spec[2],"onClose",{spec[3]},"System.Void",nil,function(ret)
            T.open_panels[spec[1]]=nil;return ret
        end)
    end
    bind("limited_light","app.FlashLightBlackboardUnit","get_UseFlashLight",{},"System.Boolean",function(args,call)
        call.mine=T.c.enabled and U.address(U.object(args[2]))==T.light_addr
    end,function(ret,call)
        if call.mine and T.light_kind and T.light_blocked[T.light_kind] then
            T.mark("light_depleted");return sdk.to_ptr(false)
        end
        return ret
    end)
    local light_overrides={}
    function T.restore_light()
        U.restore_properties(light_overrides)
        T.light_render_writes=0;T.light_control="native"
    end
    function T.enforce_light(controller)
        if not controller or U.address(controller)~=T.light_controller_addr then return end
        if not T.c.enabled or not T.light_kind or not T.light_blocked[T.light_kind] then
            T.restore_light();return
        end
        -- The UseFlashLight gate handles gameplay; reversible renderer flags
        -- handle the flame/beam. External switch requests can latch the light
        -- off after recharge, and setting intensity to zero can leave a black
        -- emitter on the next toggle. Neither is needed to extinguish it.
        T.light_control="recharge_lock"
        local writes=0
        -- These are the player's emitters, not the scene's general lighting.
        for _,field in ipairs({"_CurrentLight","_CurrentPointLight","_CurrentLightShaft","_CurrentLensflarePlayer"}) do
            local emitter=U.field(controller,field)
            if emitter then
                if U.override_property(light_overrides,emitter,"Enabled","System.Boolean",false,true) then writes=writes+1 end
            end
        end
        for _,getter in ipairs({"get_CurrentLightObject","get_CurrentPointLightObject","get_CurrentLightShaftObject"}) do
            local go=U.call(controller,getter)
            if U.override_property(light_overrides,go,"Draw","System.Boolean",false,true) then writes=writes+1 end
        end
        T.light_render_writes=writes
        if writes>0 then
            T.mark("light_render_forced_off")
            U.note("light_renderer","observed","Player light emitters disabled after native controller update")
        else U.note("light_renderer","missing","No compatible renderer setter on current emitters") end
    end
    for _,name in ipairs({"updateCore","lateUpdate"}) do
        local params=name=="updateCore" and {"System.Action"} or {}
        bind("light_renderer_"..name,"app.FlashLightController",name,params,"System.Void",function(args,call)
            call.controller=U.object(args[2])
        end,function(ret,call) T.enforce_light(call.controller);return ret end)
    end
end
