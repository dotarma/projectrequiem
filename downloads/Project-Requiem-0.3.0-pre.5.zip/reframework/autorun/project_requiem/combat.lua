return function(T)
    local U,R=T.U,T.rules
    local projectile_scopes={}
    local last_physical_frame={}
    local function fired(key)
        if R.is_jammed(T.s,key) then return end
        if last_physical_frame[key]==T.frame then return end
        last_physical_frame[key]=T.frame
        R.shot_fired(T.s,T.c,key);T.mark("shot")
        -- Roll once per physical shot, never per input/update frame.
        local _,reason=R.try_shot(T.s,T.c,key,0)
        if reason=="new_jam" then T.toast("jam_new");T.mark("jam") end
    end
    local function base_interval(eq)
        local interval=U.field(eq,"_CalcShotInterval")
        if type(interval)=="number" and interval>=0.005 and interval<=10 then return interval end
        local gun=U.call(eq,"getEquipWeapon")
        local param=U.call(U.call(gun,"get_EquipParam"),"get_WeaponEquipParam")
        if param then
            for _,field in ipairs(param:get_type_definition():get_fields()) do
                if field:get_type():get_full_name():find("WeaponStructureParam",1,true) then
                    local structure=U.field(param,field:get_name())
                    local list=U.field(structure,"TypeOfShootData")
                    local count=U.call(list,"get_Count") or 0
                    for i=0,math.min(count,16)-1 do
                        local data=U.call(list,"get_Item",i)
                        local value=U.field(data,"ShotInterval")
                        if U.field(data,"TypeOfShoot")==U.field(eq,"_EquipShotType") and type(value)=="number" and value>0 and value<=10 then return value end
                    end
                end
            end
        end
        U.note("fire_interval_fallback","observed","Native interval unavailable; minimum base interval 0.25 seconds")
        return 0.25
    end
    local function bind(key,typ,name,params,ret,pre,post)
        return U.hook(key,U.method(typ,name,params,ret),pre,post)
    end
    local factors={
        {"enemy_speed","getEnemyMoveFactor",function() return T.c.enemy_speed end},
        {"enemy_stagger","getEnemyWinceFactor",function() return T.c.enemy_stagger end},
    }
    for _,entry in ipairs(factors) do
        bind(entry[1],"app.RankManager",entry[2],{},"System.Single",nil,function(ret)
            if T.c.enabled then return sdk.float_to_ptr(sdk.to_float(ret)*entry[3]()) end
            return ret
        end)
    end
    for _,name in ipairs({"get_IsInfinityGun","get_IsInfinityRocketLauncher","get_IsInfinityAxe"}) do
        bind("ammo_"..name,"app.ItemManager",name,{},"System.Boolean",nil,function(ret)
            if T.c.enabled then return sdk.to_ptr(false) end
            return ret
        end)
    end
    for _,name in ipairs({"get_IsInfiniteLoader","get_IsZeroCostLoader"}) do
        bind("finite_panel_"..name,"app.Inventory.PanelState",name,{},"System.Boolean",function(args,call)
            call.mine=T.c.enabled and T.finite_panel_addrs and T.finite_panel_addrs[U.address(U.object(args[2]))]
        end,function(ret,call)
            if call.mine then return sdk.to_ptr(false) end
            return ret
        end)
    end
    -- Only modify item healing for the active player's HitPoint object.
    -- Some builds implement recoveryRate by calling recovery: scale the outer call once.
    local healing_depth={}
    for _,spec in ipairs({{"recovery","System.Int32"},{"recoveryRate","System.Single"}}) do
        bind("healing_"..spec[1],"app.HitPoint",spec[1],{spec[2],"app.HitPoint.RecoveryFactor"},"System.Void",function(args,call)
            if not T.c.enabled or not T.player_hp_addr then return end
            if U.address(U.object(args[2]))~=T.player_hp_addr or sdk.to_int64(args[4])~=0 then return end
            call.tid=thread.get_id();healing_depth[call.tid]=(healing_depth[call.tid] or 0)+1
            if healing_depth[call.tid]>1 then return end
            local factor=R.heal_factor(T.s,T.c)
            if spec[2]=="System.Single" then args[3]=sdk.float_to_ptr(sdk.to_float(args[3])*factor)
            else args[3]=sdk.to_ptr(math.max(0,math.floor(sdk.to_int64(args[3])*factor))) end
            T.mark("healing")
        end,function(ret,call)
            if call.tid then healing_depth[call.tid]=math.max(0,(healing_depth[call.tid] or 1)-1) end
            return ret
        end)
    end
    bind("stress_damage","app.HitPoint","addDamageHitPoint",{"System.Int32","System.Boolean","System.Boolean"},"System.Void",function(args,call)
        local address=U.address(U.object(args[2]))
        local amount=sdk.to_int64(args[3])
        if amount<=0 then return end
        if address==T.player_hp_addr and T.s.easy_pending then return sdk.PreHookResult.SKIP_ORIGINAL end
        if not T.active then
            local before=address==T.player_hp_addr and U.call(U.object(args[2]),"get_CurrentHitPoint")
            if before and before>0 and amount>=before and T.easy_begin_death and T.easy_begin_death() then
                return sdk.PreHookResult.SKIP_ORIGINAL
            end
            return
        end
        if T.enemy_hp_addrs and T.enemy_hp_addrs[address] then
            args[3]=sdk.to_ptr(math.max(1,math.floor(amount*T.c.weapon_damage/T.c.enemy_toughness)))
            T.mark("enemy_resistance");return
        end
        if address~=T.player_hp_addr then return end
        local before=U.call(U.object(args[2]),"get_CurrentHitPoint")
        local scaled=math.max(1,math.floor(amount*T.c.enemy_attack*(1+0.15*T.s.stress/100)))
        if before and before>0 and scaled>=before and T.easy_begin_death and T.easy_begin_death() then
            return sdk.PreHookResult.SKIP_ORIGINAL
        end
        args[3]=sdk.to_ptr(scaled)
        T.mark("enemy_attack")
        call.hp=U.object(args[2]);call.before=U.call(call.hp,"get_CurrentHitPoint")
    end,function(ret,call)
        if call.hp and call.before then
            local after=U.call(call.hp,"get_CurrentHitPoint")
            if after and after<call.before then
                R.hit(T.s,T.c,(call.before-after)/math.max(1,T.max_hp or 1));T.mark("stress_damage")
            end
        end
        return ret
    end)
    bind("fire_and_jam","app.PlayerEquipment","execFire",{},"System.Void",function(args,call)
        if R.run_locked(T.s) and U.address(U.object(args[2]))==T.equipment_addr then
            T.mark("one_life_fire_blocked");return sdk.PreHookResult.SKIP_ORIGINAL
        end
        if not T.active or U.address(U.object(args[2]))~=T.equipment_addr then return end
        local eq=U.object(args[2])
        if U.call(eq,"isEquipGun")~=true then return end
        local ammo=U.call(eq,"getLoadedAmmoCount")
        if not ammo or ammo<=0 or not T.weapon_key then return end
        local interval=base_interval(eq);T.native_shot_interval=interval
        local allowed=R.can_fire(T.s,T.c,T.weapon_key,interval)
        if not allowed then
            T.mark("blocked_fire_request")
            return sdk.PreHookResult.SKIP_ORIGINAL
        end
    end)
    -- Native firing can advance through motion events after execFire. Gate the input,
    -- projectile creation and ammo consumption too, so a jam cannot be bypassed.
    bind("jam_input_gate","app.PlayerEquipment","isEnableFire",{"System.Boolean"},"System.Boolean",function(args,call)
        call.block=U.address(U.object(args[2]))==T.equipment_addr and (R.run_locked(T.s)
            or (T.c.enabled and T.weapon_key and R.is_jammed(T.s,T.weapon_key)))
    end,function(ret,call)
        if call.block then T.mark("jam_block_input");return sdk.to_ptr(false) end
        return ret
    end)
    bind("jam_projectile_gate","app.PlayerGun","createShell",{},"System.Void",function(args,call)
        if R.run_locked(T.s) and U.address(U.object(args[2]))==T.gun_addr then
            T.mark("one_life_fire_blocked");return sdk.PreHookResult.SKIP_ORIGINAL
        end
        if T.c.enabled and T.weapon_key and U.address(U.object(args[2]))==T.gun_addr and R.is_jammed(T.s,T.weapon_key) then
            T.mark("jam_block_projectile");return sdk.PreHookResult.SKIP_ORIGINAL
        end
        if U.address(U.object(args[2]))==T.gun_addr then
            call.scope_tid=thread.get_id();call.previous=projectile_scopes[call.scope_tid]
            projectile_scopes[call.scope_tid]={request_deviated=false,requests={}}
        end
    end,function(ret,call)
        if call.scope_tid then projectile_scopes[call.scope_tid]=call.previous end
        return ret
    end)
    bind("physical_shot","app.PlayerGun","onFire",{},"System.Void",function(args,call)
        if T.active and T.weapon_key and U.address(U.object(args[2]))==T.gun_addr then call.key=T.weapon_key end
    end,function(ret,call) if call.key then fired(call.key) end;return ret end)
    bind("ammo_spent_shot","app.PlayerEquipment","consumeLoading",{"System.Int32"},"System.Void",function(args,call)
        if R.run_locked(T.s) and U.address(U.object(args[2]))==T.equipment_addr then
            T.mark("one_life_fire_blocked");return sdk.PreHookResult.SKIP_ORIGINAL
        end
        if T.c.enabled and T.weapon_key and U.address(U.object(args[2]))==T.equipment_addr and R.is_jammed(T.s,T.weapon_key) then
            T.mark("jam_block_ammo");return sdk.PreHookResult.SKIP_ORIGINAL
        end
        if T.active and T.weapon_key and U.address(U.object(args[2]))==T.equipment_addr and sdk.to_int64(args[3])>0 then
            call.key=T.weapon_key;call.eq=U.object(args[2]);call.before=U.call(call.eq,"getLoadedAmmoCount")
        end
    end,function(ret,call)
        local after=call.eq and U.call(call.eq,"getLoadedAmmoCount")
        if call.key and after and call.before and after<call.before then fired(call.key) end
        return ret
    end)
    bind("jam_reload","app.PlayerEquipment","startReload",{},"System.Void",function(args)
        if T.active and U.address(U.object(args[2]))==T.equipment_addr and T.weapon_key then
            if R.begin_clear(T.s,T.c,T.weapon_key) then T.toast("jam_clearing") end
        end
    end)
    -- Also catches the remapped reload action / gamepad even with a full magazine.
    bind("jam_reload_input","app.PlayerInputBlackboardUnit","get_IsReloadInput",{},"System.Boolean",nil,function(ret)
        if T.active and T.weapon_key and sdk.to_int64(ret)~=0 then R.begin_clear(T.s,T.c,T.weapon_key) end
        return ret
    end)
    bind("reload_duration","app.PlayerGun","get_ReloadSpeed",{},"System.Single",function(args,call)
        call.mine=T.c.enabled and U.address(U.object(args[2]))==T.gun_addr
    end,function(ret,call)
        if call.mine then
            T.mark("reload_duration")
            T.native_reload_speed=sdk.to_float(ret)
            -- Getter can be inlined in RE9; actual reload animation is slowed in the update loop.
        end
        return ret
    end)
    -- Slower recovery of accuracy is the physical effect of stress, in both views.
    bind("stress_accuracy","app.PlayerGun","addReticleFitPoint",{"System.Single"},"System.Void",function(args)
        if T.active and U.address(U.object(args[2]))==T.gun_addr then
            args[3]=sdk.float_to_ptr(sdk.to_float(args[3])*(1-0.55*T.s.stress/100))
        end
    end)
    local function panic_active()
        return T.c.enabled and T.active and T.panic_eligible and R.panic_active(T.s)
    end
    -- Reticle recovery can be inlined. Enforce its cached fit after update;
    -- physical deviation is applied at projectile creation below.
    bind("panic_reticle","app.PlayerGun","updateReticleFit",{"app.PlayerContext"},"System.Void",function(args,call)
        if panic_active() and U.address(U.object(args[2]))==T.gun_addr then call.gun=U.object(args[2]) end
    end,function(ret,call)
        if call.gun then
            local param=U.call(call.gun,"get_ReticleFitParam")
            local minimum=U.call(param,"get_Min") or 0.0
            call.gun:set_field("_CurrentReticleFitPoint",minimum)
            U.call(call.gun,"set_IsReticleFitting",false);T.mark("panic_reticle")
        end
        return ret
    end)
    -- createShell can overwrite the cached fire target and inline direction
    -- calculation. Modify the finalized request / shell transform instead.
    bind("panic_projectile_request","app.PlayerGun","calcAbility",{"app.PlayerStraightShellRequestInfo"},"System.Void",function(args,call)
        if panic_active() and U.address(U.object(args[2]))==T.gun_addr then call.request=U.object(args[3]) end
    end,function(ret,call)
        local request=call.request
        if not request then return ret end
        request:call("set_IsReticleFitted",false)
        request:call("set_ReticleFitPoint",0.0)
        request:call("set_IsReticleFitMoveShake",true)
        T.mark("panic_request_spread")
        local td=request:get_type_definition();local candidates={};local inventory={}
        while td do
            for _,f in ipairs(td:get_fields()) do
                if not f:is_static() then
                    local name,kind=f:get_name(),f:get_type():get_full_name()
                    inventory[#inventory+1]=name..":"..kind
                    if kind=="via.vec3" and (name=="_Direction" or name=="<Direction>k__BackingField" or name=="_FireDirection" or name=="_ShootDirection") then
                        candidates[#candidates+1]=name
                    end
                end
            end
            td=td:get_parent_type()
        end
        T.shell_request_fields=inventory
        local scope=projectile_scopes[thread.get_id()]
        for _,name in ipairs(candidates) do
            local direction=U.field(request,name)
            local previous=scope and scope.requests[U.address(request)..":"..name]
            if direction and previous and math.abs(direction.x-previous.x)+math.abs(direction.y-previous.y)+math.abs(direction.z-previous.z)<0.000001 then
                scope.request_deviated=true;break
            end
            local changed=direction and R.panic_target({x=0,y=0,z=0},direction,T.s.elapsed*6.7+T.s.shots*2.39996323,2.5)
            if changed then
                request:set_field(name,Vector3f.new(changed.x,changed.y,changed.z))
                if scope then
                    scope.request_deviated=true
                    scope.requests[U.address(request)..":"..name]=changed
                end
                T.mark("panic_request_direction");break
            end
        end
        return ret
    end)
    local shell_rotations={}
    bind("panic_shell_transform","app.PlayerGun","trySetupShellTransform",{"via.vec3","via.Quaternion"},"System.Void",function(args,call)
        if not panic_active() or U.address(U.object(args[2]))~=T.gun_addr then return end
        local scope=projectile_scopes[thread.get_id()]
        if scope and scope.request_deviated then return end
        local ptr=args[4];local key=tostring(ptr)
        if shell_rotations[key] then return end
        local td=U.type("via.Quaternion");if not td then return end
        local before={}
        for _,axis in ipairs({"x","y","z","w"}) do before[axis]=sdk.get_native_field(ptr,td,axis) end
        local phase=T.s.elapsed*6.7+T.s.shots*2.39996323
        local changed=R.rotation_offset(before,2.5*math.sin(phase),2.5*math.cos(phase),0)
        if not changed then return end
        call.rotation={ptr=ptr,td=td,key=key,before=before};shell_rotations[key]=true
        for axis,v in pairs(changed) do sdk.set_native_field(ptr,td,axis,v) end
        T.mark("panic_shell_rotation")
    end,function(ret,call)
        local rotation=call.rotation
        if rotation then
            for axis,v in pairs(rotation.before) do pcall(sdk.set_native_field,rotation.ptr,rotation.td,axis,v) end
            shell_rotations[rotation.key]=nil
        end
        return ret
    end)
    -- Reuse the shared native sick-state gate where this character has its own
    -- valid configuration. Never substitute Leon's animation/config on Grace.
    bind("panic_native_sick","app.PlayerUpdaterBase","isApplySickState",{},"System.Boolean",function(args,call)
        call.mine=panic_active() and T.native_sick_available and U.address(U.object(args[2]))==T.updater_addr
    end,function(ret,call)
        if call.mine then T.mark("panic_native_sick");return sdk.to_ptr(true) end
        return ret
    end)
    bind("panic_native_fear","app.PlayerContextUnit_Common","getFearLevelRate",{},"System.Single",function(args,call)
        call.mine=panic_active() and U.address(U.object(args[2]))==T.common_addr
    end,function(ret,call)
        if call.mine then T.mark("panic_native_fear");return sdk.float_to_ptr(1.0) end
        return ret
    end)
    local function quaternion(q) return Quaternion.new(q.w,q.x,q.y,q.z) end
    local function close_rotation(a,b)
        if not a or not b then return false end
        return math.abs(a.x-b.x)+math.abs(a.y-b.y)+math.abs(a.z-b.z)+math.abs(a.w-b.w)<0.00001
    end
    function T.restore_panic_camera()
        local entry=T.panic_camera;T.panic_camera=nil
        if entry then
            pcall(function()
                if close_rotation(U.call(entry.transform,"get_Rotation"),entry.applied) then
                    entry.transform:call("set_Rotation",quaternion(entry.base))
                end
            end)
        end
    end
    function T.update_panic_camera()
        T.restore_panic_camera()
        if not panic_active() then return end
        local camera=sdk.get_primary_camera()
        local transform=U.call(camera,"get_Transform")
        local original=U.call(transform,"get_Rotation")
        if not original then U.note("panic_camera","missing","Primary camera transform unavailable");return end
        local time=T.s.elapsed
        local changed=R.rotation_offset(original,0.6*math.sin(time*1.35),0.7*math.cos(time*1.1),1.5*math.sin(time*1.05))
        if not changed then return end
        local base={x=original.x,y=original.y,z=original.z,w=original.w}
        transform:call("set_Rotation",quaternion(changed))
        T.panic_camera={transform=transform,base=base,applied=changed}
        T.mark("panic_camera_sway");U.note("panic_camera","observed","Bounded local camera sway; restored before simulation")
    end
    function T.draw_panic()
        if not panic_active() then return end
        local ok,size=pcall(imgui.get_display_size)
        if not ok or not size or size.x<=0 or size.y<=0 then return end
        local w,h=size.x,size.y
        local pulse=0.5+0.5*math.sin(T.s.elapsed*2.2)
        -- A slow haze and breathing tunnel vision supplement the native effect.
        -- This is our overlay, not a claim of a pixel-identical Leon postprocess.
        draw.filled_rect(0,0,w,h,(math.floor(22+12*pulse)<<24)|0x009D9BA5)
        for i=0,11 do
            local alpha=math.floor((1-i/12)*(90+40*pulse))
            local color=alpha<<24
            local dx,dy=w*0.012,h*0.012
            draw.filled_rect(i*dx,0,dx,h,color);draw.filled_rect(w-(i+1)*dx,0,dx,h,color)
            draw.filled_rect(0,i*dy,w,dy,color);draw.filled_rect(0,h-(i+1)*dy,w,dy,color)
        end
        T.mark("panic_overlay")
    end
    function T.restore_reload()
        local entry=T.reload_layer
        if entry then
            pcall(function()
                if not sdk.is_managed_object(entry.layer) then return end
                local speed=U.call(entry.layer,"get_Speed")
                if type(speed)=="number" and math.abs(speed-entry.applied)<0.00001 then
                    entry.layer:call("set_Speed",entry.base)
                end
            end)
        end
        T.reload_layer=nil
    end
    function T.update_reload(ctx)
        local common=U.call(ctx,"get_Common")
        if U.call(common,"get_IsReloading")~=true then T.restore_reload();return end
        -- Release the previous locomotion factor before capturing reload speed.
        if T.restore_stamina then T.restore_stamina() end
        local go=U.call(ctx,"get_GameObject")
        local motion=U.call(go,"getComponent(System.Type)",sdk.typeof("via.motion.Motion"))
        local layer=U.call(motion,"getLayer",0)
        if not layer then U.note("reload_animation","missing","No player motion layer");return end
        local speed=U.call(layer,"get_Speed")
        if type(speed)~="number" or speed<=0 then return end
        local entry=T.reload_layer
        if not entry or U.address(entry.layer)~=U.address(layer) then
            T.restore_reload();entry={layer=layer,base=speed};T.reload_layer=entry
        elseif math.abs(speed-(entry.applied or speed))>0.00001 then entry.base=speed end
        local desired=entry.base/(T.c.reload_duration*(1+0.25*T.s.stress/100))
        local ok=pcall(layer.call,layer,"set_Speed",desired)
        if ok then
            entry.applied=desired;T.mark("reload_animation")
            U.note("reload_animation","observed","Scaled active reload motion; native animation events preserved")
        end
    end
end
