local U={ status={}, type_cache={}, method_cache={}, owned={} }
function U.type(name)
    if U.type_cache[name]~=nil then return U.type_cache[name] or nil end
    local ok,td=pcall(sdk.find_type_definition,name)
    U.type_cache[name]=(ok and td) or false
    return U.type_cache[name] or nil
end
function U.call(obj,name,...)
    if not obj then return nil end
    local ok,v=pcall(obj.call,obj,name,...)
    if ok then return v end
    return nil
end
function U.field(obj,name)
    if not obj then return nil end
    local ok,v=pcall(obj.get_field,obj,name)
    if ok then return v end
    return nil
end
function U.singleton(name)
    local ok,v=pcall(sdk.get_managed_singleton,name)
    if ok then return v end
    return nil
end
function U.address(obj)
    if not obj then return nil end
    local ok,v=pcall(obj.get_address,obj)
    if ok then return tostring(v) end
end
function U.name(obj)
    if not obj then return nil end
    local result=U.call(obj,"get_Name") or U.call(obj,"ToString")
    if result then return tostring(result) end
end
function U.static(type_name,field_name)
    local td=U.type(type_name);local f=td and td:get_field(field_name)
    if not f or not f:is_static() then return nil end
    local ok,value=pcall(f.get_data,f,nil)
    if ok then return value end
end
function U.object(ptr)
    if not ptr then return nil end
    local ok,v=pcall(sdk.to_managed_object,ptr)
    if ok then return v end
end
function U.method(type_name,name,param_types,return_type)
    local key=type_name..":"..name..":"..table.concat(param_types,",")..":"..(return_type or "")
    if U.method_cache[key]~=nil then return U.method_cache[key] or nil end
    local td=U.type(type_name)
    if not td then U.method_cache[key]=false;return nil end
    while td do
    for _,m in ipairs(td:get_methods()) do
        if m:get_name()==name then
            local types=m:get_param_types(); local match=#types==#param_types
            for i,t in ipairs(types) do if t:get_full_name()~=param_types[i] then match=false end end
            if return_type and m:get_return_type():get_full_name()~=return_type then match=false end
            if match then U.method_cache[key]=m;return m end
        end
    end
    td=td:get_parent_type()
    end
    U.method_cache[key]=false
end
function U.note(key,state,detail)
    local row=U.status[key] or {calls=0,errors=0}
    row.state=state;row.detail=detail;U.status[key]=row
    return row
end
-- Hook-local storage is safe across recursive calls and engine threads.
function U.hook(key,method,pre,post)
    if not method then U.note(key,"missing","API signature unavailable");return false end
    if not thread or not thread.get_hook_storage then
        U.note(key,"missing","REFramework thread.get_hook_storage required");return false
    end
    local row=U.note(key,"installed",method:get_declaring_type():get_full_name().."."..method:get_name())
    local ok,err=pcall(sdk.hook,method,function(args)
        local storage=thread.get_hook_storage();storage.project_requiem={}
        local call=storage.project_requiem
        row.calls=row.calls+1
        if pre then
            local good,result=pcall(pre,args,call)
            if good then return result end
            row.errors=row.errors+1;row.last_error=tostring(result)
            if row.errors==1 then log.error("[PROJECT REQUIEM] "..key..": "..tostring(result)) end
        end
        return sdk.PreHookResult.CALL_ORIGINAL
    end,function(retval)
        local storage=thread.get_hook_storage();local call=storage.project_requiem or {}
        if post then
            local good,result=pcall(post,retval,call)
            if good and result~=nil then return result end
            if not good then
                row.errors=row.errors+1;row.last_error=tostring(result)
                if row.errors==1 then log.error("[PROJECT REQUIEM] "..key..": "..tostring(result)) end
            end
        end
        return retval
    end)
    if not ok then U.note(key,"error",tostring(err));return false end
    return true
end
function U.own_field(obj,name,value)
    if not obj then return false end
    local td=obj:get_type_definition();local f=td:get_field(name)
    if not f then return false end
    local addr=U.address(obj);local key=addr..":"..name
    local before=U.field(obj,name)
    if before==nil then return false end
    if before==value then return true end
    if not U.owned[key] then U.owned[key]={object=obj,name=name,before=before,value=value} end
    local ok=pcall(obj.set_field,obj,name,value)
    if not ok then U.owned[key]=nil end
    return ok
end
function U.restore()
    for _,entry in pairs(U.owned) do
        pcall(function()
            if sdk.is_managed_object(entry.object) and U.field(entry.object,entry.name)==entry.value then
                entry.object:set_field(entry.name,entry.before)
            end
        end)
    end
    U.owned={}
end
-- Reversible overrides for the actual light renderer, separate from bonus flags.
function U.override_property(bucket,obj,property,kind,value,refresh_native)
    if not obj then return false end
    local type_name=obj:get_type_definition():get_full_name()
    local get=U.method(type_name,"get_"..property,{},kind)
    local set=U.method(type_name,"set_"..property,{kind},"System.Void")
    if not get or not set then return false end
    local key=U.address(obj)..":"..property
    local before=U.call(obj,"get_"..property)
    if before==nil then return false end
    if not bucket[key] then bucket[key]={object=obj,property=property,before=before,value=value} end
    -- A live controller can write a fresh state between our overrides. Keep
    -- that state for release instead of restoring an obsolete first snapshot.
    if refresh_native and before~=value then bucket[key].before=before end
    return pcall(obj.call,obj,"set_"..property,value)
end
function U.restore_properties(bucket)
    for key,entry in pairs(bucket) do
        pcall(function()
            if not sdk.is_managed_object(entry.object) then return end
            local current=U.call(entry.object,"get_"..entry.property)
            local matches=current==entry.value
            if type(current)=="number" and type(entry.value)=="number" then matches=math.abs(current-entry.value)<0.00001 end
            if matches then entry.object:call("set_"..entry.property,entry.before) end
        end)
        bucket[key]=nil
    end
end
function U.position(context)
    local transform=U.get(context,"get_Transform","via.Transform")
        or U.call(U.get(context,"get_GameObject","via.GameObject"),"get_Transform")
    -- Render transforms follow a Licker on the wall/ceiling; stored context
    -- positions may lag behind it or remain at a spawn marker.
    local p=U.call(transform,"get_Position") or U.get(context,"get_Position","via.vec3")
        or U.get(context,"get_PosturePosition","via.vec3")
    local ok,value=pcall(function()
        if not p then return end
        local coordinates={p.x,p.y,p.z}
        for i=1,3 do
            local v=coordinates[i]
            if type(v)~="number" or v~=v or math.abs(v)==math.huge then return end
        end
        return {x=p.x,y=p.y,z=p.z}
    end)
    if ok then return value end
end
-- Explicit inherited getter lookup when the object's short-name call fails.
function U.get(obj,name,return_type)
    local result=U.call(obj,name)
    if result~=nil or not obj then return result end
    local ok,value=pcall(function()
        local method=U.method(obj:get_type_definition():get_full_name(),name,{},return_type)
        if method then return method:call(obj) end
    end)
    if ok then return value end
end
function U.is_a(obj,type_name)
    if not obj then return false end
    local ok,result=pcall(function()
        local td=obj:get_type_definition()
        while td do
            if td:get_full_name()==type_name then return true end
            td=td:get_parent_type()
        end
        return false
    end)
    return ok and result or false
end
function U.each(list,visit,limit)
    if not list then return 0 end
    local count=U.call(list,"get_Count") or U.field(list,"_size")
    local visited=0;limit=limit or 256
    if type(count)=="number" then
        for i=0,math.min(count,limit)-1 do
            local item=U.call(list,"get_Item(System.Int32)",i) or U.call(list,"get_Item",i)
            if item then visit(item);visited=visited+1 end
        end
    else
        local iterator=U.call(list,"GetEnumerator")
        while visited<limit and U.call(iterator,"MoveNext")==true do
            local item=U.call(iterator,"get_Current")
            if item then visit(item) end
            visited=visited+1
        end
        U.call(iterator,"Dispose")
    end
    return visited
end
function U.distance(a,b)
    if not a or not b then return math.huge end
    return math.sqrt((a.x-b.x)^2+(a.y-b.y)^2+(a.z-b.z)^2)
end
return U
