-- One Life (Easy): soft death / in-session Continue / persistent positional loot caches.
-- No native save load or world rewind is used. Unsupported inventory data fails closed.
return function(T)
    local U,R=T.U,T.rules
    local C=require("project_requiem.loot_codec")
    local function native(typ,obj,name,params,returns,...)
        return assert(U.method(typ,name,params,returns),"Missing API: "..typ.."."..name):call(obj,...)
    end
    local function inventory()
        return assert(native("app.GuiUtil",nil,"getInventory",{},"app.Inventory"),"Player inventory unavailable")
    end
    local function array(list)
        assert(list and list.get_size,"Inventory array unavailable")
        local count=list:get_size();assert(count<=256,"Inventory array exceeds limits")
        local out={};for i=0,count-1 do out[#out+1]=list:get_element(i) end;return out
    end
    local function equal(a,b)
        if type(a)~=type(b) then return false end
        if type(a)~="table" then return a==b end
        for k,v in pairs(a) do if not equal(v,b[k]) then return false end end
        for k in pairs(b) do if a[k]==nil then return false end end
        return true
    end
    local function key_of(panel)
        local key=assert(U.call(panel,"get_Key"),"Panel key unavailable")
        local raw=U.field(key,"_RawKey");assert(type(raw)=="number","Panel identity unavailable")
        return key,raw
    end
    local function save() return T.persist and T.persist()==true end
    local function fail(err)
        T.s.easy_error=tostring(err):sub(1,512)
        U.note("easy_life","error",T.s.easy_error);T.toast("easy_error");T.flush_soon=true
    end
    local function identity(ctx)
        local owner=U.name(U.call(ctx,"get_KindID"));local area=U.call(ctx,"get_ResumeAreaID")
        assert(owner and type(area)=="number","Player/area identity unavailable")
        return owner,area
    end
    local function panel_data(panel)
        local data=assert(native("app.Inventory.PanelState",panel,"deployAmountData",{},"app.ItemAmountData"),"Item deployment failed"):add_ref()
        local encoded=C.encode(U,data)
        assert(equal(encoded,C.encode(U,C.decode(U,encoded))),"Item data did not survive a complete round trip")
        return encoded
    end
    local function snapshot(inv)
        local panels=array(native("app.Inventory",inv,"getAllPanelStates",{},"app.Inventory.PanelState[]"))
        local known,removals,items={},{},{}
        for _,p in ipairs(panels) do
            local _,raw=key_of(p);assert(not known[raw],"Duplicate inventory panel identity");known[raw]=p
        end
        for _,p in ipairs(panels) do
            local _,raw=key_of(p);local data=panel_data(p)
            local parent=U.field(U.call(p,"get_AttachTargetKey"),"_RawKey")
            removals[#removals+1]={key=raw,data=data}
            -- Native deployment carries an attached item's data inside its parent.
            -- Do not also deposit a second loose copy of the same attachment.
            if not parent or not known[parent] then items[#items+1]={data=data,claimed=false} end
        end
        local archives=array(native("app.Inventory",inv,"getArchiveStates",{},"app.Inventory.ArchiveItemState[]"))
        for _,p in ipairs(archives) do
            local typ=p:get_type_definition():get_full_name()
            local id=native(typ,p,"get_ItemID",{},"app.ItemID")
            local stock=native(typ,p,"get_Stock",{},"System.Int32")
            assert(id and type(stock)=="number" and stock>=0,"Archive item unavailable")
            if stock>0 then
                local data=assert(sdk.create_instance("app.ItemStockData")):add_ref()
                native("app.ItemAmountData",data,"set_ItemID",{"app.ItemID"},"System.Void",id)
                data:set_field("_Stock",stock)
                local encoded=C.encode(U,data)
                assert(equal(encoded,C.encode(U,C.decode(U,encoded))),"Archive round trip failed")
                items[#items+1]={data=encoded,claimed=false}
                removals[#removals+1]={archive=U.name(id),stock=stock,data=encoded}
            end
        end
        return items,removals
    end
    local function remove_remaining(inv,bag)
        local event=assert(U.static("app.ItemStockChangedEventType","Default"),"Item change event unavailable")
        local panels={}
        for _,p in ipairs(array(native("app.Inventory",inv,"getAllPanelStates",{},"app.Inventory.PanelState[]"))) do
            local _,raw=key_of(p);panels[raw]=p
        end
        for _,source in ipairs(bag.removals) do
            if source.key then
                local p=panels[source.key]
                if p then
                    p=native("app.Inventory",inv,"getPanelState",{"app.Inventory.PanelKey"},"app.Inventory.PanelState",key_of(p))
                end
                if p then
                    assert(equal(panel_data(p),source.data),"Prepared death inventory no longer matches")
                    local key=key_of(p)
                    local name=U.call(p,"get_IsPreferentialPanel")==true and "removePreferentialPanel" or "removePanel"
                    assert(native("app.Inventory",inv,name,{"app.Inventory.PanelKey","app.ItemStockChangedEventType"},"System.Boolean",key,event)==true,"Cannot remove carried item")
                end
            else
                local data=C.decode(U,source.data);local id=U.call(data,"get_ItemID")
                local count=native("app.Inventory",inv,"countArchive",{"app.ItemID"},"System.Int32",id)
                assert(count==0 or count==source.stock,"Prepared archive no longer matches")
                if count>0 then
                    assert(native("app.Inventory",inv,"consumeArchiveStock",{"app.ItemID","System.Int32","app.ItemStockChangedEventType"},"System.Boolean",id,count,event)==true,"Cannot remove archive item")
                end
            end
        end
        assert(#array(native("app.Inventory",inv,"getAllPanelStates",{},"app.Inventory.PanelState[]"))==0,"Some carried items remain")
    end
    local function health(updater,ctx,hp)
        local maximum=assert(U.call(hp,"get_CurrentMaximumHitPoint"))
        native("app.HitPoint",hp,"resetHitPoint",{"System.Int32"},"System.Void",math.max(1,math.floor(maximum*0.5)))
        assert(U.call(hp,"get_IsDead")~=true and U.call(ctx,"get_IsDead")~=true,"Native death cannot be reversed safely")
        native("app.PlayerUpdaterBase",updater,"applyInventoryStatus",{"System.Boolean"},"System.Void",true)
    end
    function T.easy_available()
        return T.active==true and T.easy_anchor~=nil and not R.run_locked(T.s)
    end
    function T.easy_begin_death()
        if not R.easy_mode(T.s) then return false end
        if T.s.easy_pending then return true end
        if T.s.dead then return false end
        local bag,inv,backup
        local old_slots=T.s.life_slots
        local old_deaths=T.s.easy_deaths
        local ok,err=pcall(function()
            assert(T.easy_anchor and T.easy_ctx and T.easy_updater,"No live safe point is available")
            assert(U.call(T.easy_ctx,"get_IsDead")~=true,"Native death already occurred")
            local owner,area=identity(T.easy_ctx);local pos=assert(U.position(T.easy_ctx),"Death position unavailable")
            assert(owner==T.easy_anchor.owner and area==T.easy_anchor.area,"Safe point is in another player/area")
            local retained={}
            for _,old in ipairs(T.s.death_drops) do
                for _,item in ipairs(old.items or {}) do
                    if not item.claimed then retained[#retained+1]=old;break end
                end
            end
            T.s.death_drops=retained
            assert(#T.s.death_drops<128,"Death-cache limit reached")
            inv=inventory();local items,removals=snapshot(inv)
            backup=assert(native("app.Inventory",inv,"storeTo",{},"app.Inventory.SaveData")):add_ref()
            bag={id=T.s.easy_deaths+1,owner=owner,area=area,position=pos,resume=T.easy_anchor.position,
                items=items,removals=removals,status="prepared"}
            T.s.death_drops[#T.s.death_drops+1]=bag;T.s.easy_pending=true;T.s.life_slots={}
            assert(save(),"Cannot persist loot before removing inventory")
            remove_remaining(inv,bag)
            bag.status="dropped";T.s.easy_deaths=bag.id;T.s.easy_error=nil
            assert(save(),"Cannot persist completed death transfer")
            T.pending_manual_save=false;T.save_tx=nil
            T.active=false;T.mark("easy_death_drop");T.toast("easy_pending_notice");save()
        end)
        if not ok then
            local rolled_back=true
            if backup and inv then
                local good,result=pcall(native,"app.Inventory",inv,"restoreFrom",{"app.Inventory.SaveData"},"System.Boolean",backup)
                rolled_back=good and result==true
            end
            if bag and rolled_back then
                if T.s.death_drops[#T.s.death_drops]==bag then table.remove(T.s.death_drops) end
                T.s.easy_pending=false;T.s.life_slots=old_slots;T.s.easy_deaths=old_deaths
            end
            fail(err);save()
            -- If rollback itself failed, freeze this transfer for reconciliation.
            return not rolled_back
        end
        return true
    end
    function T.easy_continue()
        if not T.s.easy_pending or T.s.dead then return false end
        local bag=T.s.death_drops[#T.s.death_drops]
        local ok,err=pcall(function()
            assert(bag and bag.status=="dropped" and T.easy_ctx and T.easy_updater,"Death transfer is not complete")
            local owner,area=identity(T.easy_ctx)
            assert(owner==bag.owner and area==bag.area,"Continue point is in a different area")
            assert(U.call(T.easy_ctx,"get_IsDead")~=true,"Native death bypassed the soft-death guard")
            local rot=assert(U.call(T.easy_ctx,"get_Rotation"),"Player rotation unavailable")
            local p=bag.resume
            native("app.PlayerUpdaterBase",T.easy_updater,"procPlayerWarp",{"via.vec3","via.Quaternion"},"System.Void",Vector3f.new(p.x,p.y,p.z),rot)
            health(T.easy_updater,T.easy_ctx,assert(U.call(T.easy_ctx,"get_HitPoint")))
            T.s.easy_pending=false;T.s.easy_error=nil
            if not save() then T.s.easy_pending=true;error("Cannot persist Continue") end
            T.mark("easy_continue");T.toast("easy_continued")
        end)
        if not ok then fail(err);return false end
        return true
    end
    local function remaining(bag)
        local count=0;for _,item in ipairs(bag.items) do if not item.claimed then count=count+1 end end;return count
    end
    local function nearest(ctx)
        local owner,area=identity(ctx);local pos=U.position(ctx);local result,distance
        for _,bag in ipairs(T.s.death_drops) do
            if bag.status=="dropped" and bag.owner==owner and bag.area==area and remaining(bag)>0 then
                local d=pos and U.distance(pos,bag.position)
                if d and (not distance or d<distance) then result,distance=bag,d end
            end
        end
        return result,distance
    end
    local function count(inv,id)
        return native("app.Inventory",inv,"countStock",{"app.ItemID"},"System.Int32",id)
    end
    function T.easy_recover()
        if not T.active or R.run_locked(T.s) or not T.easy_ctx then return false end
        local ok,err=pcall(function()
            local bag,d=nearest(T.easy_ctx);assert(bag and d<=2,"Return within 2 m of the death cache")
            local inv=inventory();local event=assert(U.static("app.ItemStockChangedEventType","Default"))
            local options=assert(U.static("app.Inventory.AcquireItemOptions","Default"))
            for _,item in ipairs(bag.items) do
                if not item.claimed then
                    local data=C.decode(U,item.data);local id=assert(U.call(data,"get_ItemID"))
                    local stock=U.call(data,"get_Stock") or 1;local before=count(inv,id)
                    assert(type(stock)=="number" and stock>0,"Unknown item amount")
                    if item.claim then
                        -- A journaled, completed native addition is acknowledged once.
                        assert(before==item.claim.before or before==item.claim.before+stock,"Ambiguous interrupted pickup")
                        if before==item.claim.before+stock then item.claimed=true;item.claim=nil;assert(save()) end
                    end
                    if not item.claimed then
                        local fit=native("app.Inventory",inv,"canMergeOrAdd",{"app.ItemAmountData","System.Boolean"},"System.Boolean",data,false)
                        if not fit then T.toast("easy_inventory_full");break end
                        local backup=assert(native("app.Inventory",inv,"storeTo",{},"app.Inventory.SaveData")):add_ref()
                        item.claim={before=before};assert(save(),"Cannot persist pickup journal")
                        local added,why=pcall(function()
                            native("app.Inventory",inv,"mergeOrAdd",{"app.ItemAmountData","System.Boolean","app.Inventory.AcquireItemOptions","app.ItemStockChangedEventType"},"app.Inventory.MergeOrAddResult",data,false,options,event)
                            assert(count(inv,id)==before+stock,"Native pickup did not add the complete item")
                            item.claimed=true;item.claim=nil;assert(save(),"Cannot persist completed pickup")
                        end)
                        if not added then
                            item.claimed=false;item.claim={before=before}
                            local restored=native("app.Inventory",inv,"restoreFrom",{"app.Inventory.SaveData"},"System.Boolean",backup)
                            if restored then item.claim=nil end
                            save();error(why)
                        end
                        T.mark("easy_loot_recovered")
                    end
                end
            end
            native("app.PlayerUpdaterBase",T.easy_updater,"applyInventoryStatus",{"System.Boolean"},"System.Void",true)
            if remaining(bag)==0 then T.toast("easy_loot_complete") end
        end)
        if not ok then fail(err);return false end
        return true
    end
    function T.update_easy(ctx,updater)
        T.easy_ctx=ctx;T.easy_updater=updater
        local good,owner,area=pcall(identity,ctx)
        if not good then T.easy_anchor=nil;return end
        local pos=U.position(ctx)
        if T.active and pos and T.locomotion_safe and not T.near_enemy and not R.run_locked(T.s) then
            T.easy_anchor={owner=owner,area=area,position=pos}
        end
        if T.easy_anchor and (T.easy_anchor.owner~=owner or T.easy_anchor.area~=area) then T.easy_anchor=nil end
        if T.s.easy_pending then
            local bag=T.s.death_drops[#T.s.death_drops]
            if bag and bag.status=="prepared" then
                local ok,err=pcall(remove_remaining,inventory(),bag)
                if ok then bag.status="dropped";T.s.easy_deaths=math.max(T.s.easy_deaths,bag.id);save() else fail(err) end
            end
        end
        local requested=T.easy_request;T.easy_request=nil
        if requested then
            local paused=U.field(U.singleton("app.PauseManager"),"_CurrentPauseTypeBits")
            if paused~=0 then T.toast("easy_unpause")
            elseif requested=="arm" then
                local ok,err=pcall(function()
                    assert(T.easy_available(),"No live Continue point")
                    -- Validate and round-trip the CURRENT inventory on the game
                    -- update thread, before enabling a mode that removes items.
                    snapshot(inventory())
                    assert(U.method("app.PlayerUpdaterBase","procPlayerWarp",{"via.vec3","via.Quaternion"},"System.Void"),"Warp API unavailable")
                    assert(U.method("app.HitPoint","resetHitPoint",{"System.Int32"},"System.Void"),"HP reset API unavailable")
                    local allowed,reason=R.set_one_life(T.s,T.c,true,"easy")
                    if not allowed then T.toast(reason or "easy_need_live");return end
                    assert(T.save_config and T.save_config(),"Cannot persist Easy configuration")
                    assert(save(),"Cannot persist Easy activation")
                    T.s.easy_error=nil;T.toast("easy_enabled");U.note("easy_preflight","observed","Current inventory round trip passed")
                end)
                if not ok then fail(err) end
            elseif requested=="continue" then T.easy_continue()
            elseif requested=="recover" then T.easy_recover() end
        end
    end
    local keys={}
    function T.draw_easy()
        local pending=T.s.easy_pending
        for code,action in pairs({[0x75]="continue",[0x76]="recover"}) do
            local down=reframework:is_key_down(code)
            local available=action=="continue" and pending or (action=="recover" and T.active and R.has_death_loot(T.s))
            if down and not keys[code] and available then T.easy_request=action end
            keys[code]=down
        end
        if pending then return end
        if not T.easy_ctx or not T.active then return end
        local bag,d=nearest(T.easy_ctx)
        if bag then
            local p=bag.position
            draw.world_text(T.tr("easy_loot_marker",bag.id,d),Vector3f.new(p.x,p.y+0.35,p.z),0xFF77BBFF)
            draw.text(T.tr("easy_loot_distance",d,remaining(bag)),T.c.hud_x,T.c.hud_y+250,0xFF77BBFF)
        end
    end
    U.hook("easy_force_death",U.method("app.CharacterContext","forceDead",{},"System.Void"),function(args)
        if U.address(U.object(args[2]))==T.player_ctx_addr and T.easy_begin_death() then return sdk.PreHookResult.SKIP_ORIGINAL end
    end)
end
