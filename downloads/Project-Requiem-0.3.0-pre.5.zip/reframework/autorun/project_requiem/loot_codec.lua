-- Persist owned ItemAmountData trees, including stock, loaded rounds and attachments.
-- No offsets, executable payloads, arbitrary constructors or shared game objects.
local M={}
local function fields(td)
    local out={}
    while td do
        for _,f in ipairs(td:get_fields()) do
            if not f:is_static() and f:get_name()~="_ItemIDCache" then out[f:get_name()]=f end
        end
        td=td:get_parent_type()
    end
    return out
end
local function derives(td,expected)
    while td do
        if td:get_full_name()==expected then return true end
        td=td:get_parent_type()
    end
    return false
end
local function scalar(v)
    local t=type(v)
    return t=="boolean" or (t=="string" and #v<=4096) or
        (t=="number" and v==v and math.abs(v)<1e15)
end
function M.encode(U,value)
    local seen,nodes={},0
    local function encode(v,declared,depth)
        nodes=nodes+1;assert(nodes<=8192 and depth<=16,"Item data exceeds serialization limits")
        if v==nil then return {kind="null"} end
        if scalar(v) then return {kind="scalar",value=v} end
        local td=v:get_type_definition();local name=td:get_full_name()
        local identity=U.address(v) or tostring(v)
        assert(not seen[identity],"Cyclic item data is unsupported");seen[identity]=true
        local row
        if declared and declared:sub(-2)=="[]" then
            local count=v:get_size();assert(count>=0 and count<=256,"Item array exceeds limits")
            row={kind="array",type=declared,items={}}
            for i=0,count-1 do row.items[i+1]=encode(v:get_element(i),declared:sub(1,-3),depth+1) end
        else
            local label=U.name(v)
            local catalog=label and U.static(name,label)
            if catalog and U.address(catalog)==U.address(v) then
                row={kind="catalog",type=name,name=label}
            else
                local available=fields(td)
                local boxed=available.value__ or (name:match("^System%.") and available.m_value)
                assert(boxed or (name:match("^app%.") and name:find("Data",1,true)),"Unsupported owned item type: "..name)
                row={kind=boxed and "boxed" or "object",type=name,fields={}}
                local count=0
                for key,f in pairs(available) do
                    count=count+1;assert(count<=128,"Too many item fields")
                    row.fields[key]=encode(f:get_data(v),f:get_type():get_full_name(),depth+1)
                end
                assert(count>0,"Unrecognized empty item type: "..name)
            end
        end
        seen[identity]=nil;return row
    end
    assert(U.is_a(value,"app.ItemAmountData"),"Expected ItemAmountData")
    return encode(value,"app.ItemAmountData",0)
end
function M.decode(U,row)
    local nodes=0
    local function decode(r,expected,depth)
        nodes=nodes+1;assert(nodes<=8192 and depth<=16 and type(r)=="table","Invalid item tree")
        if r.kind=="null" then return nil end
        if r.kind=="scalar" then assert(scalar(r.value),"Invalid item scalar");return r.value end
        assert(type(r.type)=="string" and #r.type<=192,"Invalid item type")
        if r.kind=="array" then
            assert(r.type==expected and expected:sub(-2)=="[]" and type(r.items)=="table" and #r.items<=256,"Invalid item array")
            local array=sdk.create_managed_array(expected:sub(1,-3),#r.items):add_ref()
            for i,v in ipairs(r.items) do
                local element=decode(v,expected:sub(1,-3),depth+1)
                -- System.Array.SetValue is used through the documented managed call API.
                array:call("SetValue(System.Object, System.Int32)",element,i-1)
            end
            return array
        end
        local td=assert(U.type(r.type),"Missing item type: "..r.type)
        assert(derives(td,expected),"Item type does not match its declared field")
        if r.kind=="catalog" then
            assert(type(r.name)=="string" and #r.name<=128,"Invalid catalog name")
            return assert(U.static(r.type,r.name),"Unknown catalog item: "..r.name)
        end
        local available=fields(td)
        local boxed=available.value__ or (r.type:match("^System%.") and available.m_value)
        assert((r.kind=="object" and r.type:match("^app%.") and r.type:find("Data",1,true))
            or (r.kind=="boxed" and boxed),"Unsupported item object")
        assert(type(r.fields)=="table","Invalid item fields")
        local obj=assert(sdk.create_instance(r.type,true),"Cannot allocate item data"):add_ref()
        local count=0
        for key,v in pairs(r.fields) do
            count=count+1;assert(count<=128 and available[key],"Unknown item field")
            obj:set_field(key,decode(v,available[key]:get_type():get_full_name(),depth+1))
        end
        return obj
    end
    return decode(row,"app.ItemAmountData",0)
end
return M
