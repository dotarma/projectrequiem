-- PROJECT REQUIEM: Beyond Insanity, for Resident Evil Requiem / REFramework.
-- Compatibility is checked against reflected signatures, never fixed memory offsets.
local R=require("project_requiem.core")
local U=require("project_requiem.sdk_util")
local I=require("project_requiem.locale")
local function read(path)
    local ok,value=pcall(json.load_file,path)
    if ok and type(value)=="table" then return value end
end
local c=R.config(read("project_requiem/config.json") or read("khuc_cau_hon/config.json") or read("ultradead/config.json"))
local state_path="project_requiem/"..c.run_id..".json"
local T={c=c,s=R.new_state(c,read(state_path) or read("khuc_cau_hon/"..c.run_id..".json") or read("ultradead/"..c.run_id..".json")),U=U,rules=R,active=false,
    events={},open_panels={},light_blocked={},dirty=false,flush_soon=false,frame=0}
T.light_blocked=T.s.light_latched
local message_key,message_args,message_until="welcome",{},0
local function write(path,value)
    local ok,result=pcall(json.dump_file,path,value)
    if not ok or result~=true then log.error("[PROJECT REQUIEM] Cannot persist "..path..": "..tostring(result)) end
    return ok and result==true
end
function T.mark(event)
    T.events[event]=(T.events[event] or 0)+1;T.dirty=true
end
function T.tr(key,...) return I.text(c.language,key,...) end
function T.toast(key,...) message_key=key;message_args={...};message_until=T.frame+360 end
local ui_font
do
    -- Load during script initialization, before drawing. Font ID zero is valid.
    local ok,font=pcall(imgui.load_font,"project_requiem/NotoSans-Regular.ttf",16,
        {0x0020,0x024F,0x0300,0x036F,0x1EA0,0x1EF9,0x2000,0x206F,0})
    if ok and type(font)=="number" and font>=0 then
        ui_font=font;U.note("ui_font","loaded","Noto Sans / English and Vietnamese glyph ranges")
    else U.note("ui_font","missing","Could not load bundled font; using REFramework default") end
end
local function with_ui_font(render)
    if ui_font~=nil then imgui.push_font(ui_font) end
    local ok,err=pcall(render)
    if ui_font~=nil then imgui.pop_font() end
    if not ok then U.note("ui_render","error",tostring(err)) end
end
local function persist()
    if write(state_path,R.snapshot(T.s)) then T.dirty=false;T.flush_soon=false;return true end
    return false
end
T.persist=persist
function T.save_config() return write("project_requiem/config.json",c) end
local delta_method=U.method("via.Application","get_FrameTimeMillisecond",{},"System.Single")
local focus_method=U.method("via.Application","get_HasFocus",{},"System.Boolean")
local min_method=U.method("via.Application","get_Minimized",{},"System.Boolean")
local scan_timer,flush_timer=0.25,0
local function get_player()
    local cm=U.singleton("app.CharacterManager")
    local ctx=U.call(cm,"getPlayerContextRef")
    if not ctx or U.call(cm,"get_PlayerInitialized")~=true or U.call(ctx,"get_Valid")~=true then return nil,cm end
    return ctx,cm
end
local function update()
    if T.restore_panic_camera then T.restore_panic_camera() end
    T.active=false
    T.inactive_reason="disabled"
    if not c.enabled and not T.s.one_life then return end
    local ctx,cm=get_player()
    if not ctx then
        if T.restore_reload then T.restore_reload() end
        if T.restore_light then T.restore_light() end
        if T.restore_stamina then T.restore_stamina() end
        T.inactive_reason="no_initialized_player"
        T.player_hp_addr=nil;T.equipment_addr=nil;T.gun_addr=nil;T.light_addr=nil;T.light_controller_addr=nil
        T.updater_addr=nil;T.common_addr=nil;T.player_ctx_addr=nil;T.input_addr=nil;T.common=nil;T.panic_eligible=false
        T.near_enemy=false;T.enemy_hp_addrs={};T.threat_scan=nil;scan_timer=0.25
        T.open_panels={};T.s.guns={};T.easy_ctx=nil;T.easy_updater=nil;T.easy_anchor=nil;T.easy_request=nil;return
    end
    local hp=U.call(ctx,"get_HitPoint");local updater=U.call(ctx,"get_Updater")
    local eq=U.call(updater,"get_Equipment");local gun=U.call(eq,"getEquipWeapon")
    local common=U.call(ctx,"get_Common")
    T.updater_addr=U.address(updater);T.common_addr=U.address(common)
    if T.prepare_survival then T.prepare_survival(ctx,updater,common) end
    local kind=U.name(U.call(ctx,"get_KindID"))
    T.player_kind=kind
    T.panic_eligible=U.call(ctx,"get_IsCp_A0Character")==true or U.call(ctx,"get_IsCp_A1Character")==true
        or (type(kind)=="string" and kind:match("^cp_A[01]%d*$")~=nil)
    local configuration=U.call(updater,"get_Configuration")
    T.native_sick_available=U.call(configuration,"get_SickSeizureConfiguration")~=nil
    local light=U.call(updater,"get_FlashLightUnit")
    local controller=U.call(U.call(updater,"get_FlashLightDriver"),"get_FlashLightController")
    T.light_controller_addr=U.address(controller)
    T.player_hp_addr=U.address(hp);T.equipment_addr=U.address(eq);T.gun_addr=U.address(gun);T.light_addr=U.address(light)
    T.finite_panel_addrs={}
    if c.enabled then
    for _,field in ipairs({"_EquipMeleePanelState","_CharacterEquipPanelState","_EquipPanelState"}) do
        local panel=U.field(eq,field)
        if panel and U.call(panel,"get_IsLoader")==true then
            T.finite_panel_addrs[U.address(panel)]=true
            for _,flag in ipairs({"<IsInfiniteLoader>k__BackingField","<IsZeroCostLoader>k__BackingField"}) do
                if U.field(panel,flag)==true then T.mark("finite_durability_enforced") end
                U.own_field(panel,flag,false)
            end
        end
    end
    end
    local weapon_id=U.name(U.call(eq,"get_InventoryEquipWepon")) or U.name(U.call(eq,"get_EquipWeaponID"))
    local player_kind=U.name(U.call(ctx,"get_KindID")) or "player"
    T.weapon_key=weapon_id and (player_kind..":"..weapon_id) or nil
    T.max_hp=U.call(hp,"get_CurrentMaximumHitPoint");T.hp=U.call(hp,"get_CurrentHitPoint")
    if T.s.await_new_player and T.hp and T.hp>0 and U.call(ctx,"get_IsDead")~=true
        and U.call(ctx,"get_IsSuspended")~=true and U.call(ctx,"get_CutSceneInvalidated")~=true then
        T.s.await_new_player=false;T.dirty=true
    end
    -- Death must be latched even on a paused game-over frame or with the general
    -- mod checkbox off. HP is only a fallback for native onDead callbacks.
    if U.call(ctx,"get_IsDead")==true or (type(T.hp)=="number" and T.hp<=0
        and U.call(ctx,"get_IsSuspended")~=true and U.call(ctx,"get_CutSceneInvalidated")~=true) then
        if T.player_died then T.player_died() end
    end
    if R.run_locked(T.s) then
        if T.s.easy_pending then
            T.inactive_reason="easy_continue_pending"
            if T.update_easy then T.update_easy(ctx,updater) end
            return
        end
        T.inactive_reason="one_life_dead"
        if T.hp and T.hp>0 and U.call(cm,"get_IsGameOvered")==false and U.call(cm,"get_RequestedGameOver")==false then
            U.call(cm,"requestGameOver",false);T.mark("one_life_checkpoint_blocked")
        end
        return
    end
    if not c.enabled then
        if T.update_easy then T.update_easy(ctx,updater) end
        return
    end
    local paused=U.field(U.singleton("app.PauseManager"),"_CurrentPauseTypeBits")
    T.paused_bits=paused
    if paused==nil then U.note("live_clock","missing","Pause state not available");T.inactive_reason="pause_unavailable";return end
    if paused~=0 then T.inactive_reason="game_paused";return end
    if not T.hp or T.hp<=0 or U.call(ctx,"get_IsSuspended")==true or U.call(ctx,"get_CutSceneInvalidated")==true then T.inactive_reason="player_inactive";return end
    if focus_method and not focus_method:call(nil) then T.inactive_reason="unfocused";return end
    if min_method and min_method:call(nil) then T.inactive_reason="minimized";return end
    local milliseconds=delta_method and delta_method:call(nil)
    T.native_frame_ms=milliseconds
    local dt=type(milliseconds)=="number" and milliseconds/1000 or nil
    if not dt or dt<=0 or dt>0.5 then T.inactive_reason="frame_time_unavailable";return end
    T.active=true
    T.inactive_reason=nil
    U.note("live_clock","observed","Using game frame milliseconds and pause state")
    if T.update_reload then T.update_reload(ctx) end
    local lkind=U.name(U.call(light,"getCurrentLightEntityNo"))
    T.light_kind=(lkind=="Lighter") and "lighter" or ((lkind=="FlashLight" or lkind=="BodyLight") and "flashlight" or nil)
    R.update_light_latches(T.s,c)
    if T.enforce_light then T.enforce_light(controller) end
    local light_on=U.call(light,"get_UseFlashLight")==true
    scan_timer=scan_timer+dt
    if scan_timer>=0.25 then
        scan_timer=0;T.scan_enemies(cm,ctx)
        T.chapter=U.call(U.singleton("app.LevelFlowManager"),"getDyingProgressName")
        if T.refresh_ink then T.refresh_ink() end
    end
    local was_exhausted=T.s.exhausted
    local light_was_blocked={flashlight=T.light_blocked.flashlight,lighter=T.light_blocked.lighter}
    R.tick(T.s,c,dt,{active=true,sprinting=T.sprinting,moving=T.moving,near_enemy=T.near_enemy,low_hp=T.max_hp and T.hp/T.max_hp<0.3,
        dark=T.near_enemy and T.light_kind~=nil and not light_on,
        flashlight_on=T.light_kind=="flashlight" and light_on,lighter_on=T.light_kind=="lighter" and light_on})
    if T.s.exhausted and not was_exhausted then T.toast("stamina_empty");T.mark("stamina_exhausted") end
    if not T.s.exhausted and was_exhausted then T.toast("stamina_ready");T.mark("stamina_recovered") end
    for _,kind in ipairs({"flashlight","lighter"}) do
        if light_was_blocked[kind] and not T.light_blocked[kind] then
            T.toast("light_ready");T.mark("light_recharged")
        end
    end
    if T.enforce_light then T.enforce_light(controller) end
    local panic=R.panic_active(T.s)
    if panic and not T.was_panic then T.toast("panic_started");T.mark("panic_started") end
    if not panic and T.was_panic then T.mark("panic_recovered") end
    T.was_panic=panic
    if T.weapon_key then
        -- Keyboard fallback also works when the full-magazine reload action is refused by the game.
        if reframework:is_key_down(0x52) then R.begin_clear(T.s,c,T.weapon_key) end
        if R.finish_clear(T.s,T.weapon_key) then T.toast("jam_cleared");T.mark("jam_cleared") end
    end
    -- Keep direct field readers consistent with the infinity getter hooks.
    T.dirty=true;flush_timer=flush_timer+dt
    if flush_timer>=15 then flush_timer=0;T.flush_soon=true end
    if T.update_easy then T.update_easy(ctx,updater) end
end
require("project_requiem.combat")(T)
require("project_requiem.world")(T)
require("project_requiem.saves")(T)
require("project_requiem.survival")(T)
require("project_requiem.easy_life")(T)
if T.refresh_ink then pcall(T.refresh_ink) end
re.on_pre_application_entry("UpdateBehavior",function()
    local ok,err=pcall(update)
    if not ok then
        T.active=false;U.note("update","error",tostring(err))
        if T.last_error~=tostring(err) then T.last_error=tostring(err);log.error("[PROJECT REQUIEM] "..tostring(err)) end
    end
end)
re.on_pre_application_entry("LateUpdateBehavior",function()
    local ok,err=pcall(function()
        local ctx=get_player()
        if ctx and T.update_stamina_motion then T.update_stamina_motion(ctx)
        elseif T.restore_stamina then T.restore_stamina() end
    end)
    if not ok then U.note("stamina_late_update","error",tostring(err)) end
end)
re.on_application_entry("LateUpdateBehavior",function()
    if T.update_panic_camera then
        local ok,err=pcall(T.update_panic_camera)
        if not ok then U.note("panic_camera","error",tostring(err)) end
    end
end)
local function report()
    return {project=R.TITLE,version=R.VERSION,language=c.language,tdb=sdk.get_tdb_version(),run_id=c.run_id,active=T.active,
        hooks=U.status,events=T.events,stress=T.s.stress,manual_saves=T.s.saves,inactive_reason=T.inactive_reason,paused_bits=T.paused_bits,frame_ms=T.native_frame_ms,
        spoiled_ink=T.s.spoiled_ink,ink_item=T.ink_id_name,shot_interval=T.native_shot_interval,reload_speed=T.native_reload_speed,
        player_hp=T.hp,player_max_hp=T.max_hp,weapon=T.weapon_key,player_kind=T.player_kind,panic_eligible=T.panic_eligible,light_kind=T.light_kind,
        flashlight=T.s.flashlight,lighter=T.s.lighter,light_blocked=T.light_blocked,light_render_writes=T.light_render_writes,
        gun=T.weapon_key and R.gun_status(T.s,T.weapon_key),autosaves="forbidden",bonus_flags=T.bonus_flags,
        last_blocked_save_category=T.last_blocked_save_category,threat_scan=T.threat_scan,near_enemy=T.near_enemy,
        panic=R.panic_active(T.s),native_sick_available=T.native_sick_available,errors=T.last_error,
        stamina=T.s.stamina,exhausted=T.s.exhausted,sprinting=T.sprinting,moving=T.moving,
        one_life=T.s.one_life,one_life_dead=R.run_locked(T.s),life_attempt=T.s.life_attempt,life_slots=T.s.life_slots,
        await_new_player=T.s.await_new_player,life_mode=T.s.life_mode,easy_pending=T.s.easy_pending,
        easy_deaths=T.s.easy_deaths,easy_error=T.s.easy_error,death_drop_count=#T.s.death_drops,
        shell_request_fields=T.shell_request_fields,panic_camera_active=T.panic_camera~=nil,
        light_control=T.light_control,stamina_motion=T.stamina_layer and {base=T.stamina_layer.base,applied=T.stamina_layer.applied}}
end
re.on_frame(function()
    T.frame=T.frame+1
    if c.enabled then
        local items=U.singleton("app.ItemManager")
        T.bonus_flags={}
        for _,flag in ipairs({"_InfinityGun","_InfinityRocketLauncher","_InfinityAxe"}) do
            U.own_field(items,flag,false);T.bonus_flags[flag]=U.field(items,flag)
        end
    end
    if T.flush_soon then persist() end
    if T.frame==120 or T.frame%1800==0 then write("project_requiem/status.json",report()) end
    if T.draw_panic then
        local ok,err=pcall(T.draw_panic)
        if not ok then U.note("panic_overlay","error",tostring(err)) end
    end
    if T.draw_easy then with_ui_font(T.draw_easy) end
    if R.run_locked(T.s) then
        with_ui_font(function()
            draw.filled_rect(c.hud_x-8,c.hud_y-6,540,74,0xE815151C)
            draw.text(T.tr(T.s.easy_pending and "easy_pending_notice" or "one_life_dead"),c.hud_x,c.hud_y,0xFF5555FF)
        end)
        return
    end
    if not c.hud or not c.enabled or not T.player_hp_addr then return end
    with_ui_font(function()
    local x,y=c.hud_x,c.hud_y
    local color=T.s.stress>=75 and 0xFF5555EE or (T.s.stress>=45 and 0xFF44BBEE or 0xFF99DD99)
    draw.filled_rect(x-8,y-6,520,246,0xB815151C)
    draw.text(T.tr("hud_title",math.floor(T.s.stress)),x,y,0xFFFFFFFF)
    draw.filled_rect(x,y+22,278,8,0xFF35353D)
    draw.filled_rect(x,y+22,278*T.s.stress/100,8,color)
    draw.text(T.tr("stamina_meter",math.floor(T.s.stamina))..(T.s.exhausted and T.tr("stamina_exhausted") or ""),x,y+37,T.s.exhausted and 0xFF5555FF or 0xFFDDDDDD)
    draw.filled_rect(x,y+59,278,8,0xFF35353D)
    draw.filled_rect(x,y+59,278*T.s.stamina/100,8,T.s.exhausted and 0xFF5555FF or 0xFFDDCC77)
    draw.text(T.tr("resources",T.s.flashlight,T.s.lighter,T.s.saves,c.max_manual_saves),x,y+75,0xFFDDDDDD)
    draw.text(T.tr("restrictions"),x,y+117,0xFFAAAADD)
    if T.weapon_key and R.is_jammed(T.s,T.weapon_key) then
        draw.text(T.tr("jam_hint"),x,y+96,0xFF5555FF)
    elseif T.s.stress>=75 then draw.text(T.tr("panic_hint"),x,y+96,color) end
    if T.near_enemy and T.threat_scan and T.threat_scan.nearest_distance then
        local name=T.threat_scan.nearest_kind=="cp_B600" and "Licker" or T.tr("enemy")
        draw.text(T.tr("threat",name,T.threat_scan.nearest_distance,c.stress_gain_near),x,y+138,0xFFDDDDDD)
    end
    if T.s.one_life then draw.text(T.tr(R.easy_mode(T.s) and "easy_active" or "one_life_active",T.s.life_attempt),x,y+159,0xFF88BBFF) end
    if T.frame<message_until then draw.text(T.tr(message_key,table.unpack(message_args)),x,y+182,0xFFFFFFFF) end
    if T.light_kind and T.light_blocked[T.light_kind] then
        local kind=T.light_kind
        draw.text(T.tr("light_recharging",T.s[kind],c[kind.."_seconds"]*0.15),x,y+219,0xFF77BBFF)
    end
    end)
end)
re.on_draw_ui(function()
    with_ui_font(function()
    if not imgui.tree_node("Project Requiem [0.3 PRE-RELEASE]") then return end
    imgui.text(T.tr("release_note"))
    imgui.text(T.tr("run_summary",c.run_id,T.s.stress,T.s.saves,c.max_manual_saves))
    -- REFramework returns the selected Lua table key, rather than an ImGui ordinal.
    local changed,index=imgui.combo(T.tr("language").."###project_requiem_language",c.language=="vi" and 2 or 1,{"English","Tiếng Việt"})
    if changed and (index==1 or index==2) then
        c.language=index==2 and "vi" or "en";write("project_requiem/config.json",c)
    end
    local changed,value=imgui.checkbox(T.tr("enabled").."###project_requiem_enabled",c.enabled)
    if changed then
        c.enabled=value;if not value then T.active=false;if T.restore_reload then T.restore_reload() end;if T.restore_light then T.restore_light() end;if T.restore_stamina then T.restore_stamina() end;if T.restore_panic_camera then T.restore_panic_camera() end;U.restore() end
        write("project_requiem/config.json",c)
    end
    changed,value=imgui.checkbox(T.tr("show_hud").."###project_requiem_hud",c.hud)
    if changed then c.hud=value;write("project_requiem/config.json",c) end
    imgui.text(T.tr("stamina_summary",T.s.stamina,c.stamina_recover_threshold))
    if R.run_locked(T.s) then
        imgui.text(T.tr(T.s.easy_pending and "easy_pending_notice" or "one_life_dead"))
        if T.s.easy_pending and imgui.button(T.tr("easy_continue").."###project_requiem_easy_continue") then T.easy_request="continue" end
    else
        if T.s.one_life then imgui.text(T.tr(R.easy_mode(T.s) and "easy_active" or "one_life_active",T.s.life_attempt)) end
        local key=T.s.one_life and "one_life_disable" or "one_life_enable"
        if imgui.button(T.tr(key).."###project_requiem_one_life") then
            if T.hp and T.hp<=0 then T.toast("one_life_need_alive")
            else
                local allowed,reason=R.set_one_life(T.s,c,not T.s.one_life)
                if allowed then
                    write("project_requiem/config.json",c);persist()
                    T.toast(T.s.one_life and "one_life_armed" or "one_life_off")
                elseif reason then T.toast(reason) end
            end
        end
        if imgui.button(T.tr("easy_enable").."###project_requiem_one_life_easy") then
            if not T.easy_available or not T.easy_available() then T.toast("easy_need_live")
            else T.easy_request="arm" end
        end
    end
    imgui.text(T.tr("one_life_help"))
    imgui.text(T.tr("easy_help"))
    if R.has_death_loot(T.s) and not R.run_locked(T.s) then
        if imgui.button(T.tr("easy_recover").."###project_requiem_easy_recover") then T.easy_request="recover" end
    end
    if T.s.easy_error then imgui.text(T.tr("easy_error").." "..T.s.easy_error) end
    if imgui.button(T.tr("export_report").."###project_requiem_report") then
        persist();write("project_requiem/status.json",report());T.toast("report_exported")
    end
    if imgui.tree_node(T.tr("api_status").."###project_requiem_api") then
        local keys={};for k in pairs(U.status) do keys[#keys+1]=k end;table.sort(keys)
        for _,k in ipairs(keys) do
            local v=U.status[k]
            imgui.text(T.tr("api_row",k,T.tr("state_"..v.state),v.calls or 0,v.errors or 0))
        end
        imgui.tree_pop()
    end
    imgui.text(T.tr("new_campaign"))
    imgui.text(T.tr("config_path"))
    imgui.text(T.tr("report_path"))
    imgui.tree_pop()
    end)
end)
re.on_config_save(function() write("project_requiem/config.json",c);persist() end)
re.on_script_reset(function() persist();if T.restore_reload then T.restore_reload() end;if T.restore_light then T.restore_light() end;if T.restore_stamina then T.restore_stamina() end;if T.restore_panic_camera then T.restore_panic_camera() end;U.restore() end)
write("project_requiem/config.json",c)
log.info("[PROJECT REQUIEM] "..R.VERSION.." loaded. Inspect API status before playing.")
