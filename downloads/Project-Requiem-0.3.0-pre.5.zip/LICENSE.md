# Project Requiem licenses and third-party notices

This file covers Project Requiem 0.3.0-pre.5 and records software, assets,
development tools and reference material used for the project. License
inspection date: 16 October 2026.

Project Requiem code uses MIT. The bundled Noto font retains OFL-1.1.
Separately installed runtimes, development tools and reference projects
retain their own terms. Their attribution here does not relicense them.

The sections distinguish what ships in the mod ZIP from external inputs.
Upstream license documents remain authoritative for their components.
Copied notices below preserve their wording; only whitespace is reflowed.

## Project Requiem code

The following MIT license applies to Project Requiem's original Lua code,
installer, build scripts and original documentation. Third-party assets
and upstream reference material are covered by their respective notices.

```text
MIT License

Copyright (c) 2026 Project Requiem contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Bundled asset

### Noto Sans Regular

- License: SIL Open Font License 1.1, SPDX `OFL-1.1`.
- File: `reframework/fonts/project_requiem/NotoSans-Regular.ttf`.
- Copyright: 2018 The Noto Project Authors.
- Source: [Noto font repository][noto].
- Upstream terms: [Noto OFL notice][noto-license].

The font is distributed unchanged. Its original notice also ships in
[OFL.txt](reframework/fonts/project_requiem/OFL.txt). The complete notice
is reproduced below.

```text
Copyright 2018 The Noto Project Authors (github.com/googlei18n/noto-fonts)

This Font Software is licensed under the SIL Open Font License,
Version 1.1.

This license is copied below, and is also available with a FAQ at:
http://scripts.sil.org/OFL

-----------------------------------------------------------
SIL OPEN FONT LICENSE Version 1.1 - 26 February 2007
-----------------------------------------------------------

PREAMBLE
The goals of the Open Font License (OFL) are to stimulate worldwide
development of collaborative font projects, to support the font
creation efforts of academic and linguistic communities, and to
provide a free and open framework in which fonts may be shared and
improved in partnership with others.

The OFL allows the licensed fonts to be used, studied, modified and
redistributed freely as long as they are not sold by themselves. The
fonts, including any derivative works, can be bundled, embedded,
redistributed and/or sold with any software provided that any reserved
names are not used by derivative works. The fonts and derivatives,
however, cannot be released under any other type of license. The
requirement for fonts to remain under this license does not apply to
any document created using the fonts or their derivatives.

DEFINITIONS
"Font Software" refers to the set of files released by the Copyright
Holder(s) under this license and clearly marked as such. This may
include source files, build scripts and documentation.

"Reserved Font Name" refers to any names specified as such after the
copyright statement(s).

"Original Version" refers to the collection of Font Software
components as distributed by the Copyright Holder(s).

"Modified Version" refers to any derivative made by adding to,
deleting, or substituting -- in part or in whole -- any of the
components of the Original Version, by changing formats or by porting
the Font Software to a new environment.

"Author" refers to any designer, engineer, programmer, technical
writer or other person who contributed to the Font Software.

PERMISSION & CONDITIONS
Permission is hereby granted, free of charge, to any person obtaining
a copy of the Font Software, to use, study, copy, merge, embed,
modify, redistribute, and sell modified and unmodified copies of the
Font Software, subject to the following conditions:

1) Neither the Font Software nor any of its individual components, in
Original or Modified Versions, may be sold by itself.

2) Original or Modified Versions of the Font Software may be bundled,
redistributed and/or sold with any software, provided that each copy
contains the above copyright notice and this license. These can be
included either as stand-alone text files, human-readable headers or
in the appropriate machine-readable metadata fields within text or
binary files as long as those fields can be easily viewed by the user.

3) No Modified Version of the Font Software may use the Reserved Font
Name(s) unless explicit written permission is granted by the
corresponding Copyright Holder. This restriction only applies to the
primary font name as presented to the users.

4) The name(s) of the Copyright Holder(s) or the Author(s) of the Font
Software shall not be used to promote, endorse or advertise any
Modified Version, except to acknowledge the contribution(s) of the
Copyright Holder(s) and the Author(s) or with their explicit written
permission.

5) The Font Software, modified or unmodified, in part or in whole,
must be distributed entirely under this license, and must not be
distributed under any other license. The requirement for fonts to
remain under this license does not apply to any document created using
the Font Software.

TERMINATION
This license becomes null and void if any of the above conditions are
not met.

DISCLAIMER
THE FONT SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT
OF COPYRIGHT, PATENT, TRADEMARK, OR OTHER RIGHT. IN NO EVENT SHALL THE
COPYRIGHT HOLDER BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
INCLUDING ANY GENERAL, SPECIAL, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF THE USE OR INABILITY TO USE THE FONT SOFTWARE OR FROM
OTHER DEALINGS IN THE FONT SOFTWARE.
```

## Runtime supplied separately

The mod uses the REFramework Lua SDK. REFramework's DLL and its embedded
libraries are installed separately and are not included in the mod ZIP.
The notices below describe the captured development runtime; later
framework builds can carry different versions and additional notices.

Captured REFramework revision:

```text
c4b1314820d20255febf7834903e8cedb669b49c
```

### REFramework

- License: MIT.
- Copyright: 2019 praydog.
- Use: Lua SDK, managed reflection, hooks and application callbacks.
- Source and license: [captured REFramework license][reframework-license].

```text
MIT License

Copyright (c) 2019 praydog

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### Lua embedded in REFramework

- Version: 5.4.3 in the captured framework tree.
- License: MIT.
- Copyright: 1994-2021 Lua.org, PUC-Rio.
- Use: runtime for the mod's Lua scripts.
- Source: `dependencies/lua/src/lua.h` in the
  [captured REFramework tree][reframework-tree].
- General upstream reference: [Lua licensing][lua-license].

```text
Copyright (C) 1994-2021 Lua.org, PUC-Rio.

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
```

### Dear ImGui

- License: MIT.
- Copyright: 2014-2025 Omar Cornut in the pinned framework submodule.
- Use: REFramework-provided UI controls and font rendering.
- Source and terms: [pinned Dear ImGui license][imgui-license].

Captured submodule revision:

```text
85b2fe8486190fa9326565a2fb5fccb6caea4396
```

```text
The MIT License (MIT)

Copyright (c) 2014-2025 Omar Cornut

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Reference material

These projects were consulted for API names, behavior and documentation
style. Their source files are not included in the mod ZIP. Audit revisions
below identify the inspected notices, not necessarily the exact historical
revision originally consulted.

### RELit

- Notice: MIT embedded in `RELit.lua`.
- Authors: Frans 'Otis_Inf' Bouma and Nicolás 'originalnicodr' Uriel Navall.
- Use: renderer enable/intensity API references.
- Source: [RELit Lua header][relit-license].
- Audit revision: `11231ea44ffc92225e7fcf92fd7e9efb64b5f921`.

The upstream [README][relit-readme] also contains a no-rehosting statement.
Project Requiem distributes neither the RELit mod nor its source. The
original inline license notice is copied below.

```text
MIT License
Copyright (c) 2023 Frans 'Otis_Inf' Bouma & Nicolás 'originalnicodr' Uriel
Navall

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### Namsku's RE Engine trainer

- Author/maintainer attribution: namsku / Namsku.
- Use: infinity flags, rank factors, weapon data and motion-layer API names.
- References: `re9/requiem_trainer/features.lua` and related hooks.
- Source: [audited trainer tree][trainer-tree].
- Audit revision: `1ffee4852f4f354507ef5e7e1bdb3c0e1c50347e`.

No applicable license grant was located for the referenced trainer
features/hooks in the inspected repository. MIT notices inside separate
`emv_engine` directories do not establish a license for those files.
No license is assigned to the referenced files by this document.

### RE9 Randomiser

- Author/maintainer attribution: KyroGeorge2.
- Use: recognized healing IDs and world/inventory API references.
- Source: [audited randomiser tree][randomiser-tree].
- Audit revision: `b09481423fcdcd91f51037520ddd4b745841f002`.

No license file or inline license grant was located in the inspected
repository tree, README or referenced Lua. No license is assigned to that
project by this document.

### Markdown skill

- Project: RedondoK/claude-md-skill, Markdown skill version 1.2.1.
- License: MIT for `markdown/LICENSE`.
- Copyright: 2025 Keith R. Gendler in that skill-specific notice.
- Use: Markdown structure, formatting and validation instructions.
- Source and terms: [skill-specific license][skill-license].
- Audit revision: `8cc1415849f17dd9bdcd43e41e52d8526441fb0d`.

The repository-root notice names 2025-2026; the copy below is the 2025
notice accompanying the Markdown skill itself.

```text
MIT License

Copyright (c) 2025 Keith R. Gendler

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Development tools

The following tools were used to test Lua, build release archives or
validate documentation. Their executables, packages and `.tools` directory
are not distributed in the mod ZIP. Their upstream distributions retain
their own complete license files and bundled third-party notices.

### Python 3.14.0

- Main license: Python Software Foundation License Version 2, `PSF-2.0`.
- Notice: Copyright (c) 2001 Python Software Foundation; All Rights Reserved.
- Use: Lua test orchestration and ZIP/manifest generation.
- Main upstream terms: [Python 3.14.0 license][python-license].

The Windows Python distribution also contains historical Python notices,
documentation-example terms and third-party component licenses. The
complete `LICENSE.txt` accompanies the [Windows embeddable archive][python-win].
The main CPython license is linked above; its PSF agreement is copied here.

```text
PYTHON SOFTWARE FOUNDATION LICENSE VERSION 2
--------------------------------------------

1. This LICENSE AGREEMENT is between the Python Software Foundation
("PSF"), and the Individual or Organization ("Licensee") accessing and
otherwise using this software ("Python") in source or binary form and
its associated documentation.

2. Subject to the terms and conditions of this License Agreement, PSF hereby
grants Licensee a nonexclusive, royalty-free, world-wide license to reproduce,
analyze, test, perform and/or display publicly, prepare derivative works,
distribute, and otherwise use Python alone or in any derivative version,
provided, however, that PSF's License Agreement and PSF's notice of copyright,
i.e., "Copyright (c) 2001 Python Software Foundation; All Rights Reserved"
are retained in Python alone or in any derivative version prepared by
Licensee.

3. In the event Licensee prepares a derivative work that is based on
or incorporates Python or any part thereof, and wants to make
the derivative work available to others as provided herein, then
Licensee hereby agrees to include in any such work a brief summary of
the changes made to Python.

4. PSF is making Python available to Licensee on an "AS IS"
basis.  PSF MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR
IMPLIED.  BY WAY OF EXAMPLE, BUT NOT LIMITATION, PSF MAKES NO AND
DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS
FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF PYTHON WILL NOT
INFRINGE ANY THIRD PARTY RIGHTS.

5. PSF SHALL NOT BE LIABLE TO LICENSEE OR ANY OTHER USERS OF PYTHON
FOR ANY INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES OR LOSS AS
A RESULT OF MODIFYING, DISTRIBUTING, OR OTHERWISE USING PYTHON,
OR ANY DERIVATIVE THEREOF, EVEN IF ADVISED OF THE POSSIBILITY THEREOF.

6. This License Agreement will automatically terminate upon a material
breach of its terms and conditions.

7. Nothing in this License Agreement shall be deemed to create any
relationship of agency, partnership, or joint venture between PSF and
Licensee.  This License Agreement does not grant permission to use PSF
trademarks or trade name in a trademark sense to endorse or promote
products or services of Licensee, or any third party.

8. By copying, installing or otherwise using Python, Licensee
agrees to be bound by the terms and conditions of this License
Agreement.
```

### Lupa 2.8 and its Lua notice

- License: MIT.
- Lupa copyright: 2010-2017 Stefan Behnel; All rights reserved.
- Included Lua notice: 1994-2017 Lua.org, PUC-Rio.
- Use: the `lupa.lua54` backend for the Lua 5.4 checks.
- Source and terms: [Lupa license][lupa-license].

The installed wheel contains optional LuaJIT backends that were not used
by these checks. LuaJIT has [separate notices][luajit-license]; those
backends and their binaries are not part of the mod release. The exact
Lupa wheel notice is copied below.

```text
License
=======

Lupa
----

Copyright (c) 2010-2017 Stefan Behnel.  All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

Lua
---

(See https://www.lua.org/license.html)

Copyright © 1994–2017 Lua.org, PUC-Rio.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

### Node.js 22.23.3

- Project license: MIT.
- Copyright: Node.js contributors. All rights reserved.
- Use: running Markdown validation and local documentation checks.
- Full distribution notices: [Node.js 22.23.3 license][node-license].

Node's complete file also includes Joyent and bundled third-party notices.
The main Node.js project notice is reproduced below; the linked complete
file governs the separately installed distribution.

```text
Copyright Node.js contributors. All rights reserved.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.
```

### npm 10.9.9

- Application license: Artistic License 2.0, `Artistic-2.0`.
- Copyright: npm, Inc. and Contributors.
- Use: installing the local Markdown validation packages.
- Source and full terms: [npm 10.9.9 license][npm-license].

npm dependencies retain their respective licenses. npm's application
notice is not a replacement for each dependency's terms. The exact local
npm application license/notice file is reproduced below.

```text
The npm application
Copyright (c) npm, Inc. and Contributors
Licensed on the terms of The Artistic License 2.0

Node package dependencies of the npm application
Copyright (c) their respective copyright owners
Licensed on their respective license terms

The npm public registry at https://registry.npmjs.org
and the npm website at https://www.npmjs.com
Operated by npm, Inc.
Use governed by terms published on https://www.npmjs.com

"Node.js"
Trademark Joyent, Inc., https://joyent.com
Neither npm nor npm, Inc. are affiliated with Joyent, Inc.

The Node.js application
Project of Node Foundation, https://nodejs.org

The npm Logo
Copyright (c) Mathias Pettersson and Brian Hammond

"Gubblebum Blocky" typeface
Copyright (c) Tjarda Koster, https://jelloween.deviantart.com
Used with permission


--------


The Artistic License 2.0

Copyright (c) 2000-2006, The Perl Foundation.

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble

This license establishes the terms under which a given free software
Package may be copied, modified, distributed, and/or redistributed.
The intent is that the Copyright Holder maintains some artistic
control over the development of that Package while still keeping the
Package available as open source and free software.

You are always permitted to make arrangements wholly outside of this
license directly with the Copyright Holder of a given Package.  If the
terms of this license do not permit the full use that you propose to
make of the Package, you should contact the Copyright Holder and seek
a different licensing arrangement.

Definitions

    "Copyright Holder" means the individual(s) or organization(s)
    named in the copyright notice for the entire Package.

    "Contributor" means any party that has contributed code or other
    material to the Package, in accordance with the Copyright Holder's
    procedures.

    "You" and "your" means any person who would like to copy,
    distribute, or modify the Package.

    "Package" means the collection of files distributed by the
    Copyright Holder, and derivatives of that collection and/or of
    those files. A given Package may consist of either the Standard
    Version, or a Modified Version.

    "Distribute" means providing a copy of the Package or making it
    accessible to anyone else, or in the case of a company or
    organization, to others outside of your company or organization.

    "Distributor Fee" means any fee that you charge for Distributing
    this Package or providing support for this Package to another
    party.  It does not mean licensing fees.

    "Standard Version" refers to the Package if it has not been
    modified, or has been modified only in ways explicitly requested
    by the Copyright Holder.

    "Modified Version" means the Package, if it has been changed, and
    such changes were not explicitly requested by the Copyright
    Holder.

    "Original License" means this Artistic License as Distributed with
    the Standard Version of the Package, in its current version or as
    it may be modified by The Perl Foundation in the future.

    "Source" form means the source code, documentation source, and
    configuration files for the Package.

    "Compiled" form means the compiled bytecode, object code, binary,
    or any other form resulting from mechanical transformation or
    translation of the Source form.


Permission for Use and Modification Without Distribution

(1)  You are permitted to use the Standard Version and create and use
Modified Versions for any purpose without restriction, provided that
you do not Distribute the Modified Version.


Permissions for Redistribution of the Standard Version

(2)  You may Distribute verbatim copies of the Source form of the
Standard Version of this Package in any medium without restriction,
either gratis or for a Distributor Fee, provided that you duplicate
all of the original copyright notices and associated disclaimers.  At
your discretion, such verbatim copies may or may not include a
Compiled form of the Package.

(3)  You may apply any bug fixes, portability changes, and other
modifications made available from the Copyright Holder.  The resulting
Package will still be considered the Standard Version, and as such
will be subject to the Original License.


Distribution of Modified Versions of the Package as Source

(4)  You may Distribute your Modified Version as Source (either gratis
or for a Distributor Fee, and with or without a Compiled form of the
Modified Version) provided that you clearly document how it differs
from the Standard Version, including, but not limited to, documenting
any non-standard features, executables, or modules, and provided that
you do at least ONE of the following:

    (a)  make the Modified Version available to the Copyright Holder
    of the Standard Version, under the Original License, so that the
    Copyright Holder may include your modifications in the Standard
    Version.

    (b)  ensure that installation of your Modified Version does not
    prevent the user installing or running the Standard Version. In
    addition, the Modified Version must bear a name that is different
    from the name of the Standard Version.

    (c)  allow anyone who receives a copy of the Modified Version to
    make the Source form of the Modified Version available to others
    under

        (i)  the Original License or

        (ii)  a license that permits the licensee to freely copy,
        modify and redistribute the Modified Version using the same
        licensing terms that apply to the copy that the licensee
        received, and requires that the Source form of the Modified
        Version, and of any works derived from it, be made freely
        available in that license fees are prohibited but Distributor
        Fees are allowed.


Distribution of Compiled Forms of the Standard Version
or Modified Versions without the Source

(5)  You may Distribute Compiled forms of the Standard Version without
the Source, provided that you include complete instructions on how to
get the Source of the Standard Version.  Such instructions must be
valid at the time of your distribution.  If these instructions, at any
time while you are carrying out such distribution, become invalid, you
must provide new instructions on demand or cease further distribution.
If you provide valid instructions or cease distribution within thirty
days after you become aware that the instructions are invalid, then
you do not forfeit any of your rights under this license.

(6)  You may Distribute a Modified Version in Compiled form without
the Source, provided that you comply with Section 4 with respect to
the Source of the Modified Version.


Aggregating or Linking the Package

(7)  You may aggregate the Package (either the Standard Version or
Modified Version) with other packages and Distribute the resulting
aggregation provided that you do not charge a licensing fee for the
Package.  Distributor Fees are permitted, and licensing fees for other
components in the aggregation are permitted. The terms of this license
apply to the use and Distribution of the Standard or Modified Versions
as included in the aggregation.

(8) You are permitted to link Modified and Standard Versions with
other works, to embed the Package in a larger work of your own, or to
build stand-alone binary or bytecode versions of applications that
include the Package, and Distribute the result without restriction,
provided the result does not expose a direct interface to the Package.


Items That are Not Considered Part of a Modified Version

(9) Works (including, but not limited to, modules and scripts) that
merely extend or make use of the Package, do not, by themselves, cause
the Package to be a Modified Version.  In addition, such works are not
considered parts of the Package itself, and are not subject to the
terms of this license.


General Provisions

(10)  Any use, modification, and distribution of the Standard or
Modified Versions is governed by this Artistic License. By using,
modifying or distributing the Package, you accept this license. Do not
use, modify, or distribute the Package, if you do not accept this
license.

(11)  If your Modified Version has been derived from a Modified
Version made by someone other than you, you are nevertheless required
to ensure that your Modified Version complies with the requirements of
this license.

(12)  This license does not grant you the right to use any trademark,
service mark, tradename, or logo of the Copyright Holder.

(13)  This license includes the non-exclusive, worldwide,
free-of-charge patent license to make, have made, use, offer to sell,
sell, import and otherwise transfer the Package with respect to any
patent claims licensable by the Copyright Holder that are necessarily
infringed by the Package. If you institute patent litigation
(including a cross-claim or counterclaim) against any party alleging
that the Package constitutes direct or contributory patent
infringement, then this Artistic License to you shall terminate on the
date that such litigation is filed.

(14)  Disclaimer of Warranty:
THE PACKAGE IS PROVIDED BY THE COPYRIGHT HOLDER AND CONTRIBUTORS "AS
IS' AND WITHOUT ANY EXPRESS OR IMPLIED WARRANTIES. THE IMPLIED
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR
NON-INFRINGEMENT ARE DISCLAIMED TO THE EXTENT PERMITTED BY YOUR LOCAL
LAW. UNLESS REQUIRED BY LAW, NO COPYRIGHT HOLDER OR CONTRIBUTOR WILL
BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES ARISING IN ANY WAY OUT OF THE USE OF THE PACKAGE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


--------
```

### markdownlint-cli2 0.23.3

- License: MIT.
- Copyright (c) David Anson
- Source and terms: [markdownlint-cli2 license][markdownlint-cli2-license].

```text
MIT License

Copyright (c) David Anson

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

### markdownlint 0.41.1

- License: MIT.
- Copyright (c) David Anson
- Source and terms: [markdownlint license][markdownlint-license].

```text
The MIT License (MIT)

Copyright (c) David Anson

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

### markdown-it 15.0.1

- License: MIT.
- Copyright (c) 2014 Vitaly Puzrin, Alex Kocharin.
- Source and terms: [markdown-it license][markdown-it-license].

```text
Copyright (c) 2014 Vitaly Puzrin, Alex Kocharin.

Permission is hereby granted, free of charge, to any person
obtaining a copy of this software and associated documentation
files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use,
copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following
conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.
```

### Windows PowerShell

Windows PowerShell 5.1 was used to run installer and packaging commands.
It is supplied by the Windows installation and remains subject to its
Microsoft terms. No PowerShell or Windows binaries ship with this mod.
This entry records the host tool; it assigns no license to Microsoft code.

## Installed development package inventory

These catalogs record exact installed npm package versions and their
declared license identifiers. They describe development tooling, not mod
runtime dependencies or permissions for Project Requiem code.

The corresponding package's license files and source notices govern its
terms. Package metadata can be found through the [npm registry][registry].
Presence in an installed tree does not mean every optional code path ran.

### Markdown validation packages

The local validation tree contains 87 package/version pairs: the CLI and
86 dependencies. Standalone license files were present for all 87.

| Package and version | Declared license |
| --- | --- |
| `@nodelib/fs.scandir@2.1.5` | MIT |
| `@nodelib/fs.stat@2.0.5` | MIT |
| `@nodelib/fs.walk@1.2.8` | MIT |
| `@sindresorhus/merge-streams@4.0.0` | MIT |
| `@types/debug@4.1.13` | MIT |
| `@types/katex@0.16.8` | MIT |
| `@types/ms@2.1.0` | MIT |
| `@types/unist@2.0.11` | MIT |
| `ansi-regex@6.4.0` | MIT |
| `argparse@2.0.1` | Python-2.0 |
| `argparse@3.0.3` | PSF-2.0 |
| `braces@3.0.3` | MIT |
| `character-entities@2.0.2` | MIT |
| `character-entities-legacy@3.0.0` | MIT |
| `character-reference-invalid@2.0.1` | MIT |
| `commander@8.3.0` | MIT |
| `debug@4.4.3` | MIT |
| `decode-named-character-reference@1.3.0` | MIT |
| `dequal@2.0.3` | MIT |
| `devlop@1.1.0` | MIT |
| `entities@8.1.0` | BSD-2-Clause |
| `fast-glob@3.3.3` | MIT |
| `fastq@1.20.3` | ISC |
| `fill-range@7.1.1` | MIT |
| `get-east-asian-width@1.7.0` | MIT |
| `glob-parent@5.1.2` | ISC |
| `globby@16.2.4` | MIT |
| `ignore@7.0.12` | MIT |
| `is-alphabetical@2.0.1` | MIT |
| `is-alphanumerical@2.0.1` | MIT |
| `is-decimal@2.0.1` | MIT |
| `is-extglob@2.1.1` | MIT |
| `is-glob@4.0.3` | MIT |
| `is-hexadecimal@2.0.1` | MIT |
| `is-number@7.0.0` | MIT |
| `is-path-inside@4.0.0` | MIT |
| `js-yaml@5.4.1` | MIT |
| `jsonc-parser@3.3.1` | MIT |
| `jsonpointer@5.0.1` | MIT |
| `katex@0.16.47` | MIT |
| `linkify-it@6.1.0` | MIT |
| `markdown-it@15.0.1` | MIT |
| `markdownlint@0.41.1` | MIT |
| `markdownlint-cli2@0.23.3` | MIT |
| `markdownlint-cli2-formatter-default@0.0.6` | MIT |
| `mdurl@2.1.0` | MIT |
| `merge2@1.4.1` | MIT |
| `micromark@4.0.2` | MIT |
| `micromark-core-commonmark@2.0.3` | MIT |
| `micromark-extension-directive@4.0.0` | MIT |
| `micromark-extension-gfm-autolink-literal@2.1.0` | MIT |
| `micromark-extension-gfm-footnote@2.1.0` | MIT |
| `micromark-extension-gfm-table@2.1.1` | MIT |
| `micromark-extension-math@3.1.0` | MIT |
| `micromark-factory-destination@2.0.1` | MIT |
| `micromark-factory-label@2.0.1` | MIT |
| `micromark-factory-space@2.1.0` | MIT |
| `micromark-factory-title@2.0.1` | MIT |
| `micromark-factory-whitespace@2.0.1` | MIT |
| `micromark-util-character@2.1.1` | MIT |
| `micromark-util-chunked@2.0.1` | MIT |
| `micromark-util-classify-character@2.0.1` | MIT |
| `micromark-util-combine-extensions@2.0.1` | MIT |
| `micromark-util-decode-numeric-character-reference@2.0.2` | MIT |
| `micromark-util-encode@2.0.1` | MIT |
| `micromark-util-html-tag-name@2.0.1` | MIT |
| `micromark-util-normalize-identifier@2.0.1` | MIT |
| `micromark-util-resolve-all@2.0.1` | MIT |
| `micromark-util-sanitize-uri@2.0.1` | MIT |
| `micromark-util-subtokenize@2.1.0` | MIT |
| `micromark-util-symbol@2.0.1` | MIT |
| `micromark-util-types@2.0.2` | MIT |
| `micromatch@4.0.8` | MIT |
| `ms@2.1.3` | MIT |
| `parse-entities@4.0.2` | MIT |
| `picomatch@2.3.2` | MIT |
| `punycode.js@2.3.1` | MIT |
| `queue-microtask@1.2.3` | MIT |
| `reusify@1.1.0` | MIT |
| `run-parallel@1.2.0` | MIT |
| `slash@5.1.0` | MIT |
| `smol-toml@1.8.0` | BSD-3-Clause |
| `string-width@8.2.1` | MIT |
| `strip-ansi@7.2.0` | MIT |
| `to-regex-range@5.0.1` | MIT |
| `uc.micro@3.0.0` | MIT |
| `unicorn-magic@0.4.1` | MIT |

### npm application and installed dependencies

The npm tree contains 196 installed instances, representing 185 distinct
package/version pairs including npm itself. Duplicated versions are listed
once below. This catalog is separate from Node's bundled native notices.

| Package and version | Declared license |
| --- | --- |
| `@isaacs/cliui@8.0.2` | ISC |
| `@isaacs/fs-minipass@4.0.1` | ISC |
| `@isaacs/string-locale-compare@1.1.0` | ISC |
| `@npmcli/agent@3.0.0` | ISC |
| `@npmcli/arborist@8.0.5` | ISC |
| `@npmcli/config@9.0.0` | ISC |
| `@npmcli/fs@4.0.0` | ISC |
| `@npmcli/git@6.0.3` | ISC |
| `@npmcli/installed-package-contents@3.0.0` | ISC |
| `@npmcli/map-workspaces@4.0.2` | ISC |
| `@npmcli/metavuln-calculator@8.0.1` | ISC |
| `@npmcli/name-from-folder@3.0.0` | ISC |
| `@npmcli/node-gyp@4.0.0` | ISC |
| `@npmcli/package-json@6.2.0` | ISC |
| `@npmcli/promise-spawn@8.0.3` | ISC |
| `@npmcli/query@4.0.1` | ISC |
| `@npmcli/redact@3.2.2` | ISC |
| `@npmcli/run-script@9.1.0` | ISC |
| `@pkgjs/parseargs@0.11.0` | MIT |
| `@sigstore/bundle@3.1.0` | Apache-2.0 |
| `@sigstore/core@2.0.0` | Apache-2.0 |
| `@sigstore/protobuf-specs@0.4.3` | Apache-2.0 |
| `@sigstore/sign@3.1.0` | Apache-2.0 |
| `@sigstore/tuf@3.1.1` | Apache-2.0 |
| `@sigstore/verify@2.1.1` | Apache-2.0 |
| `@tufjs/canonical-json@2.0.0` | MIT |
| `@tufjs/models@3.0.1` | MIT |
| `abbrev@3.0.1` | ISC |
| `agent-base@7.1.4` | MIT |
| `ansi-regex@5.0.1` | MIT |
| `ansi-regex@6.2.2` | MIT |
| `ansi-styles@4.3.0` | MIT |
| `ansi-styles@6.2.3` | MIT |
| `aproba@2.1.0` | ISC |
| `archy@1.0.0` | MIT |
| `balanced-match@1.0.2` | MIT |
| `bin-links@5.0.0` | ISC |
| `binary-extensions@2.3.0` | MIT |
| `brace-expansion@2.0.2` | MIT |
| `cacache@19.0.1` | ISC |
| `chalk@5.6.2` | MIT |
| `chownr@3.0.0` | BlueOak-1.0.0 |
| `ci-info@4.4.0` | MIT |
| `cidr-regex@4.1.3` | BSD-2-Clause |
| `cli-columns@4.0.0` | MIT |
| `cmd-shim@7.0.0` | ISC |
| `color-convert@2.0.1` | MIT |
| `color-name@1.1.4` | MIT |
| `common-ancestor-path@1.0.1` | ISC |
| `cross-spawn@7.0.6` | MIT |
| `cssesc@3.0.0` | MIT |
| `debug@4.4.3` | MIT |
| `diff@5.2.2` | BSD-3-Clause |
| `eastasianwidth@0.2.0` | MIT |
| `emoji-regex@8.0.0` | MIT |
| `emoji-regex@9.2.2` | MIT |
| `encoding@0.1.13` | MIT |
| `env-paths@2.2.1` | MIT |
| `err-code@2.0.3` | MIT |
| `exponential-backoff@3.1.3` | Apache-2.0 |
| `fastest-levenshtein@1.0.16` | MIT |
| `fdir@6.5.0` | MIT |
| `foreground-child@3.3.1` | ISC |
| `fs-minipass@3.0.3` | ISC |
| `glob@10.5.0` | ISC |
| `graceful-fs@4.2.11` | ISC |
| `hosted-git-info@8.1.0` | ISC |
| `http-cache-semantics@4.2.0` | BSD-2-Clause |
| `http-proxy-agent@7.0.2` | MIT |
| `https-proxy-agent@7.0.6` | MIT |
| `iconv-lite@0.6.3` | MIT |
| `ignore-walk@7.0.0` | ISC |
| `imurmurhash@0.1.4` | MIT |
| `ini@5.0.0` | ISC |
| `init-package-json@7.0.2` | ISC |
| `ip-address@10.1.0` | MIT |
| `ip-regex@5.0.0` | MIT |
| `is-cidr@5.1.1` | BSD-2-Clause |
| `is-fullwidth-code-point@3.0.0` | MIT |
| `isexe@2.0.0` | ISC |
| `isexe@3.1.5` | BlueOak-1.0.0 |
| `jackspeak@3.4.3` | BlueOak-1.0.0 |
| `json-parse-even-better-errors@4.0.0` | MIT |
| `json-stringify-nice@1.1.4` | ISC |
| `jsonparse@1.3.1` | MIT |
| `just-diff@6.0.2` | MIT |
| `just-diff-apply@5.5.0` | MIT |
| `libnpmaccess@9.0.0` | ISC |
| `libnpmdiff@7.0.5` | ISC |
| `libnpmexec@9.0.5` | ISC |
| `libnpmfund@6.0.5` | ISC |
| `libnpmhook@11.0.0` | ISC |
| `libnpmorg@7.0.0` | ISC |
| `libnpmpack@8.0.5` | ISC |
| `libnpmpublish@10.0.2` | ISC |
| `libnpmsearch@8.0.0` | ISC |
| `libnpmteam@7.0.0` | ISC |
| `libnpmversion@7.0.0` | ISC |
| `lru-cache@10.4.3` | ISC |
| `make-fetch-happen@14.0.3` | ISC |
| `minimatch@9.0.9` | ISC |
| `minipass@3.3.6` | ISC |
| `minipass@7.1.3` | BlueOak-1.0.0 |
| `minipass-collect@2.0.1` | ISC |
| `minipass-fetch@4.0.1` | MIT |
| `minipass-flush@1.0.5` | ISC |
| `minipass-pipeline@1.2.4` | ISC |
| `minipass-sized@1.0.3` | ISC |
| `minizlib@3.1.0` | MIT |
| `ms@2.1.3` | MIT |
| `mute-stream@2.0.0` | ISC |
| `negotiator@1.0.0` | MIT |
| `node-gyp@11.5.0` | MIT |
| `nopt@8.1.0` | ISC |
| `normalize-package-data@7.0.1` | BSD-2-Clause |
| `npm@10.9.9` | Artistic-2.0 |
| `npm-audit-report@6.0.0` | ISC |
| `npm-bundled@4.0.0` | ISC |
| `npm-install-checks@7.1.2` | BSD-2-Clause |
| `npm-normalize-package-bin@4.0.0` | ISC |
| `npm-package-arg@12.0.2` | ISC |
| `npm-packlist@9.0.0` | ISC |
| `npm-pick-manifest@10.0.0` | ISC |
| `npm-profile@11.0.1` | ISC |
| `npm-registry-fetch@18.0.2` | ISC |
| `npm-user-validate@3.0.0` | BSD-2-Clause |
| `p-map@7.0.4` | MIT |
| `package-json-from-dist@1.0.1` | BlueOak-1.0.0 |
| `pacote@19.0.2` | ISC |
| `pacote@20.0.1` | ISC |
| `parse-conflict-json@4.0.0` | ISC |
| `path-key@3.1.1` | MIT |
| `path-scurry@1.11.1` | BlueOak-1.0.0 |
| `picomatch@4.0.3` | MIT |
| `postcss-selector-parser@7.1.1` | MIT |
| `proc-log@5.0.0` | ISC |
| `proggy@3.0.0` | ISC |
| `promise-all-reject-late@1.0.1` | ISC |
| `promise-call-limit@3.0.2` | ISC |
| `promise-retry@2.0.1` | MIT |
| `promzard@2.0.0` | ISC |
| `qrcode-terminal@0.12.0` | Apache-2.0 |
| `read@4.1.0` | ISC |
| `read-cmd-shim@5.0.0` | ISC |
| `read-package-json-fast@4.0.0` | ISC |
| `retry@0.12.0` | MIT |
| `safer-buffer@2.1.2` | MIT |
| `semver@7.7.4` | ISC |
| `shebang-command@2.0.0` | MIT |
| `shebang-regex@3.0.0` | MIT |
| `signal-exit@4.1.0` | ISC |
| `sigstore@3.1.0` | Apache-2.0 |
| `smart-buffer@4.2.0` | MIT |
| `socks@2.8.7` | MIT |
| `socks-proxy-agent@8.0.5` | MIT |
| `spdx-correct@3.2.0` | Apache-2.0 |
| `spdx-exceptions@2.5.0` | CC-BY-3.0 |
| `spdx-expression-parse@3.0.1` | MIT |
| `spdx-expression-parse@4.0.0` | MIT |
| `spdx-license-ids@3.0.23` | CC0-1.0 |
| `ssri@12.0.0` | ISC |
| `string-width@4.2.3` | MIT |
| `string-width@5.1.2` | MIT |
| `strip-ansi@6.0.1` | MIT |
| `strip-ansi@7.2.0` | MIT |
| `supports-color@9.4.0` | MIT |
| `tar@7.5.22` | BlueOak-1.0.0 |
| `text-table@0.2.0` | MIT |
| `tiny-relative-date@1.3.0` | MIT |
| `tinyglobby@0.2.15` | MIT |
| `treeverse@3.0.0` | ISC |
| `tuf-js@3.1.0` | MIT |
| `unique-filename@4.0.0` | ISC |
| `unique-slug@5.0.0` | ISC |
| `util-deprecate@1.0.2` | MIT |
| `validate-npm-package-license@3.0.4` | Apache-2.0 |
| `validate-npm-package-name@6.0.2` | ISC |
| `walk-up-path@3.0.1` | ISC |
| `which@2.0.2` | ISC |
| `which@5.0.0` | ISC |
| `wrap-ansi@7.0.0` | MIT |
| `wrap-ansi@8.1.0` | MIT |
| `write-file-atomic@6.0.0` | ISC |
| `yallist@4.0.0` | ISC |
| `yallist@5.0.0` | BlueOak-1.0.0 |

Seven npm package/version entries lacked a standalone license file at
the installed package root:

- `@npmcli/agent@3.0.0`
- `@sigstore/verify@2.1.1`
- `eastasianwidth@0.2.0`
- `err-code@2.0.3`
- `imurmurhash@0.1.4`
- `spdx-exceptions@2.5.0`
- `spdx-license-ids@3.0.23`

Their catalog entries use declared package metadata; an Apache source
header was also found for `@sigstore/verify`. The catalog does not invent
missing copyright notices or substitute metadata for full license terms.

## Game and trademark attribution

Resident Evil Requiem and its game assets belong to their respective
rights holders. No Capcom executable, DLL or game assets are distributed.
Project names and trademarks in this notice identify referenced software
and do not imply endorsement.

[noto]: https://github.com/notofonts/noto-fonts
[noto-license]: https://github.com/notofonts/noto-fonts/blob/main/LICENSE
[reframework-license]:
  https://github.com/praydog/REFramework/blob/c4b1314820d2/LICENSE
[reframework-tree]: https://github.com/praydog/REFramework/tree/c4b1314820d2
[lua-license]: https://www.lua.org/license.html
[imgui-license]: https://github.com/ocornut/imgui/blob/85b2fe848619/LICENSE.txt
[relit-license]:
  https://github.com/originalnicodr/RELit/blob/11231ea44ffc/RELit.lua
[relit-readme]:
  https://github.com/originalnicodr/RELit/blob/11231ea44ffc/README.md
[trainer-tree]: https://github.com/Namsku/re-engine-trainer/tree/1ffee4852f4f
[randomiser-tree]:
  https://github.com/KyroGeorge2/RE9-Randomiser/tree/b09481423fcd
[skill-license]:
  https://github.com/RedondoK/claude-md-skill/blob/8cc1415/markdown/LICENSE
[python-license]: https://github.com/python/cpython/blob/v3.14.0/LICENSE
[python-win]:
  https://www.python.org/ftp/python/3.14.0/python-3.14.0-embed-amd64.zip
[lupa-license]: https://github.com/scoder/lupa/blob/lupa-2.8/LICENSE.txt
[luajit-license]: https://github.com/LuaJIT/LuaJIT/blob/v2.1/COPYRIGHT
[node-license]: https://github.com/nodejs/node/blob/v22.23.3/LICENSE
[npm-license]: https://github.com/npm/cli/blob/v10.9.9/LICENSE
[markdownlint-cli2-license]:
  https://github.com/DavidAnson/markdownlint-cli2/blob/v0.23.3/LICENSE
[markdownlint-license]:
  https://github.com/DavidAnson/markdownlint/blob/v0.41.1/LICENSE
[markdown-it-license]:
  https://github.com/markdown-it/markdown-it/blob/15.0.1/LICENSE
[registry]: https://registry.npmjs.org/
