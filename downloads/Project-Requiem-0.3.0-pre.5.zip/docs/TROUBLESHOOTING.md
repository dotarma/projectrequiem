# Troubleshooting and compatibility

Use the complete **0.3.0-pre.5** package. Fully restart after upgrading so
the old Lua state and any old light-control latch are released. Automated
checks do not replace native gameplay verification; see [testing](TESTING.md).

## Mod menu is missing

1. Confirm the RE9-compatible REFramework `dinput8.dll` is beside `re9.exe`.
1. Check `reframework/autorun/project_requiem.lua` and all nine modules in
   `reframework/autorun/project_requiem/`.
1. Restart the game and inspect `re2_framework_log.txt` for Lua errors.

Do not run `khuc_cau_hon.lua` or `ultradead.lua` beside the new entrypoint.
The installer checks ownership, backs up recognized files and migrates
those previous namespaces.

## Language will not switch

Open **Insert > Script Generated UI > Project Requiem > Language** and
choose **English** or **Tiếng Việt**. The preference saves immediately and
survives script reload without resetting the run. It affects only the mod.
In JSON, supported values are `en` and `vi`; others fall back to English.

If Vietnamese leaves English selected, upgrade to pre.5. Earlier builds
used zero-based indices for a combo returning Lua table keys. The corrected
keys are English = 1 and Vietnamese = 2. Switching in both directions,
persistence and reload pass automated checks; native UI verification is
pending.

For missing/boxed Vietnamese characters, check the `ui_font` report row and
`reframework/fonts/project_requiem/NotoSans-Regular.ttf`. Reinstall the full
package to restore the font. Its codepoint coverage is checked, but native
visual rendering remains a separate verification step.

## Empty stamina still allows running

At zero, exhaustion should block sprint until at least **25 stamina**.
Recovery begins after **2 live seconds**: **12/second** at rest or
**6/second** while moving. Pause/loading does not count.

Pre.4 forces walk after native input and scales the active locomotion layer.
The old translation hook recorded events without visibly stopping sprint.
Inspect these report fields/events:

- `stamina`, `exhausted` and `stamina_after_input`.
- `stamina_walk_forced` and `stamina_motion_scaled`.
- `stamina_motion` base/applied speed values.

Terrain actions, riding, damage and reloads are excluded. FPS/TPS, stairs,
crouching and both characters still need native verification. Playback
scaling is not proof of the resulting spatial movement speed.

## One Life blocks Continue or Load

In Strict mode, death intentionally locks the attempt. Choose native
**New Game** from the title screen. Script reset, restart and general mod
disable do not revive it; native save files remain intact.

While alive, only successful manual saves made after arming One Life in the
current attempt are trusted. Existing slots are not adopted. Autosaves,
earlier-attempt and unresolved slots are denied; resolved system/profile
loads remain available.

Inspect `one_life`, `one_life_dead`, `life_attempt`, `life_slots`,
`one_life_load_*`, `one_life_new_game` and `one_life_slot_identity`. Failed
JSON writes are logged and can compromise persistence. Movement/death,
New Game, native slot ABI and all checkpoint paths still need direct
validation; successful mocked hooks do not prove complete coverage.

## One Life Easy actions fail

Activate Easy in a calm live area. Close Esc pause before F6/F7 or menu
actions. **F6** is the mod's custom Continue; native Continue/Load still
obeys slot restrictions. For **F7**, return within **2 m** of the marked
cache with the same character/area identity. A full inventory leaves
unclaimed entries in place.

Inspect these report fields and events:

- `life_mode`, `easy_pending`, `easy_deaths` and `death_drop_count`.
- `easy_error`, `easy_preflight`, `easy_force_death` and `easy_*` events.

Unsupported item data refuses activation/transfer. Scripted deaths can
bypass the guards and end the attempt; New Game remains available. After
Continue, make a successful manual save before quitting for a valid resume
slot. The cache ledger does not preserve the entire live world.

Keep failed transactions and their ledger intact: deleting them discards
recorded recovery data. No complete Easy recovery cycle has native
verification. See [Easy limits](FEATURES.md#one-life-easy).

## Stress does not rise near a Licker

Check `active` and `inactive_reason`, then the `threat_scan` fields:

- Source-list counts, `alive`, `near`, `dormant_near` and `unpositioned`.
- `nearest_kind` and `nearest_distance`.

A recognized living, present threat must be within **12 m**. The scanner
includes present dormant/suspended enemies and prefers rendered transforms.
Missing native context/position data can still prevent identification.

Timers require an initialized player and recognized live, focused gameplay.
Menus, loading, death and unfocus can stop them. A configured source gain of
zero also prevents that source's increase. The darkness gain requires a
nearby threat and recognized player light off, not low ambient brightness.

## Panic or accuracy differs between characters

Panic begins at Stress **100** and clears at **90**. Pre.4 adds Grace/Leon
kind-ID fallback, bounded camera sway, stronger overlay and final projectile
request/rotation deviation. The old cached target could be overwritten.

Inspect these report fields/events:

- `player_kind`, `panic_eligible` and `panic_camera_sway`.
- `panic_request_spread`, `panic_request_direction`, `panic_shell_rotation`
  and `shell_request_fields`.

Native sick/fear hooks are supplementary and had zero calls in the collected
report. Grace's exact native match to Leon's postprocess, every weapon's
trajectory and special scripted scenes remain unverified. A counter alone
does not prove a visible effect or changed trajectory.

## Saves are blocked

Gameplay autosaves are intentionally denied while the mod is enabled.
Manual saving can fail because of quota, cooldown, missing finite ink,
spoiled ink or bypassing the typewriter flow.

- Spoiled ink consumes one ribbon and prevents refund.
- Quota/cooldown failures retain the native refund path.
- Only successful manual writes increment quota/start the cooldown.
- Spoilage applies only where native saving already needs ribbons.
- Profile/settings writes remain allowed; existing saves are not deleted.

Some chapter/checkpoint logic may retry or report failure when autosaves are
denied. Full-campaign behavior is unverified. Loading an older save does not
refund quota because the ledger belongs to `run_id`. Use a distinct ID for
a separate campaign.

## Jams are rare or do not clear

Cold, slow shots should not jam. Heat must reach **0.40**, then a probability
roll decides each registered shot. Use Reload/**R** and wait **3-4.5 live
seconds**; clearing also works with a full magazine. Changing weapons does
not clear a session jam. Resetting Lua or losing the player context can.

## Recharged lights remain off

After depletion, a light remains locked until **15%** recharge:

| Source | Unlock energy | Default time from empty |
| --- | --- | --- |
| Flashlight / BodyLight | 27 seconds | 180 live seconds |
| Lighter | 13.5 seconds | 90 live seconds |

Pause/loading/unfocus does not count. A positive energy value below the
threshold is still locked. The HUD shows energy versus threshold and a
ready notification.

Pre.4 avoids external off requests and zero intensity that could keep a
recovered light off. Fully restart after upgrading to clear an older
runtime's possible external latch, then use the normal light toggle.
Inspect `light_blocked`, `light_control`, `light_render_writes` and
`light_recharged`. Unknown emitters or changed APIs can still cause a visual
mismatch.

## Pickups do not match the expected scarcity

Scarcity makes stable decisions for recognized world IDs, not inventory
items. Percentages describe many locations, not each room. Reloading an
area may be needed for spawn visibility changes. Unknown IDs, missing
stable location identity and key/story items are retained.

## Export a runtime report

Choose **Export compatibility / runtime report** in the mod menu. Reports
also export after 120 frames and every 1,800 frames. Relevant files are:

- `reframework/data/project_requiem/status.json`.
- `re2_framework_log.txt`.

| Report value | Meaning |
| --- | --- |
| `installed` | Hook attached |
| `calls` | Game called the hooked method |
| `events` | A guard/rule path applied |
| `missing` | Expected signature unavailable |
| `error` | Signature/callback problem |

A nonzero counter does not prove a visible effect. Reports are not uploaded
automatically.

## Conflicting mods and game updates

Avoid combining other difficulty, infinite ammo/durability/item, no-reload,
rapid-fire and save-flow mods. External trainers may bypass guarded paths.
Preserving unrelated files during installation is not compatibility
certification.

The captured API baseline is **TDB83**. Game/REFramework updates may change
signatures or inline methods. The mod uses reflection, not fixed memory
offsets. See [verification and remaining gaps](TESTING.md).
