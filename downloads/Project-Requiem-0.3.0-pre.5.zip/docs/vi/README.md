# Project Requiem

Mod tăng độ khó cho **Resident Evil Requiem PC**, chạy bằng REFramework.
Phiên bản **0.3.0-pre.5**. Tài liệu cập nhật ngày **16/10/2026**.

Project Requiem tăng áp lực chiến đấu, tài nguyên và lưu tiến độ. Preset
được thiết kế để chơi trên một lượt **Insanity/Madness** mới. Mod nhân
thêm các hệ số của độ khó đang chọn; không tự đổi độ khó trong game.

**Đây là bản pre-release.** Có 121 kiểm tra Lua và chín tình huống bộ cài
đã qua. Các bản sửa thể lực, choáng, lệch đạn, hồi đèn và chọn ngôn ngữ
chưa được xác minh lại trong game. Chu trình One Life (Easy) và toàn bộ
chiến dịch cũng chưa được kiểm chứng trực tiếp.

## Ngôn ngữ

**Tiếng Anh là mặc định.** Để chuyển sang tiếng Việt có dấu:

1. Nhấn **Insert** để mở REFramework.
1. Mở **Script Generated UI → Project Requiem**.
1. Chọn **Language → Tiếng Việt**.

Lựa chọn được áp dụng, lưu ngay và giữ sau khi nạp lại script. Việc đổi
ngôn ngữ không đặt lại tài nguyên, trạng thái chết hay lượt Một mạng.
Tài liệu mặc định bằng tiếng Anh: [README](../../README.md).

## Tính năng chính

- Quái chịu đòn tốt hơn, đánh mạnh hơn; vũ khí gây ít sát thương hơn.
- Ép tắt vô hạn đạn và vô hạn độ bền dao/rìu tích hợp của game.
- Ít vật phẩm hồi máu và mực hơn; hồi máu kém hiệu quả hơn.
- Stress tăng gần quái, kể cả Licker phục kích. Stress 100 kích hoạt
  hoảng loạn, lệch đạn, rung/nghiêng camera và tối viền.
- Thể lực cạn sẽ ép đi bộ và giảm tốc; phải hồi đủ ngưỡng mới chạy lại.
- Bắn/nạp chậm hơn. Bắn nóng súng có thể kẹt đạn, cần gỡ bằng Reload.
- Đèn pin/bật lửa có năng lượng riêng, hồi chậm khi tắt.
- Mở túi và hòm đồ đã nhận diện không tạm dừng thế giới.
- Cấm autosave tiến độ. Save thủ công có hạn mức, thời gian chờ và nguy
  cơ hỏng mực.
- Tùy chọn **One Life** khóa lượt khi chết; **One Life (Easy)** cho
  Continue trong phiên hiện tại và để lại đống đồ ở vị trí chết.

Thông số, luật và giới hạn: [Toàn bộ tính năng](FEATURES.md).

## Cài đặt

Cần bản PC của game và bản RE9 từ [REFramework chính thức][reframework].
Gói mod không chứa DLL REFramework hoặc tài sản game. Không cần bật
Loose File Loader cho các script Lua này.

1. Đóng game và sao lưu save trước khi dùng bản pre-release.
1. Giải nén gói Project Requiem.
1. Chạy lệnh dưới đây từ thư mục vừa giải nén.
1. Mở game và kiểm tra menu **Project Requiem** trong REFramework.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1 `
  -GamePath 'C:\Games\Resident Evil Requiem'
```

Cài mới cũng có thể chép thư mục `reframework` cạnh `re9.exe`. Khi nâng
cấp, dùng bộ cài để giữ cấu hình, ledger và xử lý tên mod cũ.

Khởi động lại game đầy đủ sau nâng cấp. Bản sửa ánh sáng cần bỏ trạng
thái khóa mà runtime cũ có thể còn giữ. Vật phẩm khan hiếm áp dụng lúc
spawn; cần load lại khu vực/save để thấy thay đổi ở đồ đã spawn trước đó.

Hướng dẫn đầy đủ bằng tiếng Anh: [Installation](../INSTALLATION.md).

## Nâng cấp từ bản cũ

`Install.ps1` sao lưu các file mod bị thay thế, chuyển cấu hình/ledger từ
ULTRADEAD hoặc Khúc Cầu Hồn / Requiem sang namespace `project_requiem`,
và bỏ entrypoint cũ. Không chạy hai bộ hook cùng lúc.

Bộ cài giữ thiết lập và dữ liệu run hiện có. Bản sao nằm trong thư mục
`reframework/data/project_requiem/install-backups/`. Báo cáo cũ không
được chuyển thành bằng chứng hoạt động của bản mới.

## Sử dụng

Menu **Insert → Script Generated UI → Project Requiem** có các nút bật
mod, ẩn/hiện HUD, đổi ngôn ngữ, chọn Một mạng và xuất báo cáo.

HUD hiện Stress, thể lực, năng lượng đèn, hạn mức save, trạng thái kẹt
đạn/hoảng loạn và quái gần nhất đã nhận diện. Ẩn HUD không tắt luật
gameplay hoặc hiệu ứng hoảng loạn.

### One Life

Mặc định tắt. Nút **Enable One Life / Bật chế độ Một mạng** bật luật
nghiêm ngặt: chết sẽ khóa Continue/Load đến khi thực sự bắt đầu New Game.
Khi còn sống, chỉ tải được slot thủ công lưu thành công trong lượt đó.
Nếu bật giữa chiến dịch, cần lưu mới trước khi thoát để có slot tiếp tục.

### One Life (Easy)

Bật bằng nút riêng tại điểm yên ổn. Đòn chí mạng được hỗ trợ sẽ hiện
thông báo gục. **F6 / Continue (Easy)** đưa về điểm yên ổn ghi gần nhất
trong cùng nhân vật/khu vực với 50% HP, giữ thế giới hiện tại, không tải
save. Đồ mang theo, kể cả key item, nằm trong đống đồ có dấu tại chỗ chết.
Quay lại trong **2 m**, nhấn **F7** để lấy; túi đầy thì đồ dư vẫn ở đó.

Sau Continue cần save thủ công thành công trước khi thoát nếu muốn có
slot tiếp tục lần sau. Hạn mức, mực hỏng và cấm autosave vẫn áp dụng.
Đọc [luật và giới hạn Một mạng](FEATURES.md#chế-độ-một-mạng) trước khi bật.

## Cấu hình và dữ liệu run

Đóng game trước khi sửa `reframework/data/project_requiem/config.json`.
REFramework có thể ghi đè thay đổi nếu chỉnh trong lúc game đang chạy.
Danh sách khóa và khoảng giá trị: [Configuration](../CONFIGURATION.md).

Dữ liệu phụ nằm trong `reframework/data/project_requiem/<run_id>.json`.
Load save cũ không hoàn lại Stress, thể lực, năng lượng hoặc quota của
run. New Game đặt lại lượt trong ID hiện tại. Dùng `run_id` khác để tách
chiến dịch, ví dụ `grace-leon-02`.

Ledger không lưu toàn bộ thế giới và không phải hệ thống chống gian lận.
Xóa/sửa nó có thể vượt luật; crash có thể mất trạng thái chưa kịp ghi.

## Tương thích và chẩn đoán

Không chạy cùng mod sửa độ khó, vô hạn đạn/đồ/độ bền, no reload, rapid
fire hoặc luồng save. Bộ cài giữ mod khác; điều này không chứng nhận
tương thích với mọi phiên bản của các mod đó.

Trong menu mod, chọn **Xuất báo cáo tương thích / hoạt động**. Báo cáo ở
`reframework/data/project_requiem/status.json`; log chung nằm trong
`re2_framework_log.txt`.

- `installed`: hook đã gắn.
- `calls`: game đã gọi hook.
- `events`: luật đã tác động trên đường xử lý đó.
- `missing` hoặc `error`: cơ chế cần được kiểm tra trước khi tin kết quả.

Các bộ đếm không chứng minh kết quả hình ảnh hoặc gameplay. Xem
[Kiểm thử](TESTING.md) và [Troubleshooting](../TROUBLESHOOTING.md).

## Gỡ mod

Đóng game và chạy bộ cài với cùng đường dẫn:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1 `
  -GamePath 'C:\Games\Resident Evil Requiem' -Uninstall
```

Bộ cài giữ cấu hình, ledger, file đã bị chỉnh sửa và mod khác. Có thể gỡ
thủ công bằng cách xóa entrypoint `project_requiem.lua` cùng các file Lua
trong `reframework/autorun/project_requiem/` và phông/giấy phép riêng
trong `reframework/fonts/project_requiem/`. Giữ DLL REFramework nếu vẫn
dùng các mod khác.

## Tài liệu và giấy phép

- [Tính năng](FEATURES.md): thông số mặc định và giới hạn.
- [Kiểm thử](TESTING.md): bằng chứng và ma trận xác minh tương lai.
- [Changelog](../../CHANGELOG.md): thay đổi theo phiên bản.
- [Sources](../SOURCES.md): nguồn API và chữ ký tham khảo.

Mã nguồn dùng giấy phép MIT. Phông Noto Sans đi kèm dùng giấy phép OFL
riêng và chỉ áp dụng cho giao diện mod.

Giấy phép, bản quyền và nguồn của các thành phần được ghi trong
[LICENSE.md](../../LICENSE.md), gồm cả công cụ phát triển và nguồn tham khảo.

[reframework]: https://github.com/praydog/REFramework-nightly/releases
