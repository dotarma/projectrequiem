# Kiểm thử Project Requiem

Phiên bản **0.3.0-pre.5**, cập nhật **16/10/2026**. Tài liệu mặc định:
[Testing](../TESTING.md).

**121 kiểm tra Lua và chín tình huống bộ cài đã qua.** Đây là kiểm thử
luật, SDK/UI giả lập và file. Chúng không chứng minh toàn bộ animation,
hướng đạn, hình ảnh, ValueType ABI hoặc giao dịch save của game thật.

Các bản sửa thể lực, choáng, lệch đạn, hồi đèn và chọn ngôn ngữ chưa được
xác minh lại trong game. One Life và chu trình Easy cũng chưa có lượt
xác minh đầy đủ. Release vẫn là **pre-release**.

## Phạm vi tự động

| Nhóm | Số kiểm tra |
| --- | --- |
| Luật core | 26 |
| Thể lực và One Life | 11 |
| Easy và giao dịch đồ | 25 |
| Runtime/API fixture | 44 |
| Locale | 4 |
| UI và chuyển dữ liệu | 11 |
| Tổng Lua | 121 |
| Bộ cài | 9 |

Mười file Lua phân phối biên dịch được trên Lua 5.4. Chữ ký hook đối
chiếu fixture metadata RE9 TDB83; fixture không mô phỏng toàn engine.

### Chiến đấu, Stress và tài nguyên

- Hệ số sát thương/hồi máu, bonus hữu hạn, vật phẩm khan hiếm và pause.
- Bắn/nhiệt/kẹt, chặn đạn tiếp theo và gỡ kẹt theo input.
- Quái phục kích, mốc hoảng loạn, nhận diện Grace/Leon bằng mã nhân vật.
- Hướng request đạn, góc shell tạm thời, chống áp hai lần và khôi phục.
- Camera có giới hạn, không trôi; khôi phục khi pause/tắt/hồi phục.
- Thể lực, chờ hồi, hồi nửa tốc khi đi, giữ kiệt sức tới ngưỡng.
- Ép lại input sau game update, khôi phục force-walk và tốc độ motion
  không nhân chồng; chuyển giữa đi/chạy và nạp đạn.
- Hai nguồn đèn qua nhiều lần cạn/hồi/bật, đúng ngưỡng 15%, lưu latch,
  chuyển ledger cũ, giữ cường độ, không gửi lệnh tắt ngoài và hiện thông báo.
- Save thủ công/tự động, mực hỏng, quota và callback thành công.

Field hướng ở parent request chưa được capture là fixture tổng hợp,
không phải bằng chứng về layout thật. Góc shell/camera được kiểm tra qua
SDK giả lập, không chứng minh ABI hoặc hình ảnh trong game.

### One Life và Easy

- Ghi ngay tử vong người chơi hiện tại; khóa qua reset/config/restart.
- Xác nhận slot thủ công thuộc lượt, từ chối slot cũ/chưa biết/chết.
- Cho phép system load và reset lượt bằng New Game thực sự.
- Chặn hồi sinh checkpoint trong RAM qua đường di chuyển/bắn/save đã biết.
- Kiểm tra inventory trước khi bật Easy, chặn chí mạng/force-death.
- Continue cùng phiên, đúng nhân vật/khu vực, không gọi Save/Load.
- Vị trí cache đúng, dữ liệu owned có kiểu, phụ kiện không nhân bản,
  chuyển archive/key item, kiểm tra khoảng cách/sức chứa.
- Giữ đồ mới và đồ dư, rollback khi lỗi, đối soát nhật ký gián đoạn,
  hạn chế đổi chế độ và slot sau tử vong.

Đồ súng/phụ kiện/đạn/boxed-data trong kiểm thử serializer là đồ thị tổng
hợp, không phải layout vũ khí native đã capture. Chữ ký hàm sửa inventory
đối chiếu TDB83; getter đọc archive được kiểm tra bằng reflection runtime.

### Ngôn ngữ, bộ cài và gói phát hành

- Tiếng Anh mặc định, chọn tiếng Việt, bộ khóa/format tương ứng và fallback.
- Combo dùng khóa bảng Lua 1/2, mô phỏng fallback về khóa đầu khi sai.
- Đổi hai chiều, lưu ngay, nạp lại tiếng Việt không reset tài nguyên,
  trạng thái chết hay lượt; widget ID và push/pop phông cân bằng.
- Chín tình huống cài mới, hai namespace cũ, giữ cấu hình/ledger/backup,
  cài lại, gỡ an toàn với file chỉnh sửa, từ chối đầu vào hỏng/chưa biết.
- Ký tự/range phông cho UI; ZIP kiểm tra CRC và manifest SHA-256.

## Bằng chứng từ game và giới hạn

Báo cáo cũ ghi đồng hồ gameplay chạy, đường chặn kẹt/tiêu đạn, ép renderer
đèn, bonus hữu hạn và từ chối autosave, không có lỗi callback đã thu thập.
Đó là bằng chứng lời gọi/guard, chưa phải xác nhận hình ảnh hoặc luật
hoạt động đúng trong mọi tình huống.

Lỗi Stress gần Licker dẫn tới sửa bộ quét context suspend, vị trí và
nguồn danh sách. Nguyên nhân chính xác trong game chưa được kết luận.
Getter độ chính xác không được gọi cũng dẫn tới bổ sung đường reticle/
request tạo đạn.

Báo cáo pre.3 có sáu lần cạn/hồi thể lực, 2.176 event giảm chuyển động và
2.371 event chặn sprint, nhưng người dùng vẫn chạy được khi cạn. Báo cáo
cũng có getter sprint/sick/fear và `calcFireDirection` bằng không, cùng
nhiều lần ép tắt renderer. Các bộ đếm cũ không chứng minh gameplay thành
công. Hook Easy `forceDead` gắn nhưng chưa có lời gọi/chu trình quan sát.

Người dùng báo Grace không choáng, đạn không lệch và đèn không bật lại.
Năng lượng đèn pin trong báo cáo là 16,049, dưới ngưỡng 27; HUD cũ chưa
giải thích ngưỡng. Pre.4 thay input/motion, camera/projectile và bỏ lệnh
có thể giữ đèn tắt, đồng thời bổ sung trạng thái chờ hồi trên HUD.

Pre.5 sửa lỗi EN → VI do combo dùng chỉ số 0 thay vì khóa Lua 1/2. Kiểm
thử UI đã sửa mô hình combo, thêm lưu ngay và nạp lại lựa chọn.

**Các sửa này chưa được kiểm tra lại trực tiếp.** Chưa xác minh đầy đủ
Grace/Leon, mọi vũ khí, đèn cạn, checkpoint/chuyển chương, kiểu slot và
chu trình Easy với đồ thật. Tài liệu không coi hook đã gắn là xác nhận.

## Chạy kiểm tra mã nguồn

Cần Python có wheel Lupa tương thích. Từ thư mục project:

```powershell
python -m pip install --target .tools/python lupa
python tools/test.py
powershell -NoProfile -ExecutionPolicy Bypass -File .\tests\installer_spec.ps1
python tools/package.py
```

Workspace phát triển có `.tools/python314/python.exe` để chạy Lua checks.
Runtime portable, dump nghiên cứu và ledger cá nhân không vào ZIP.

## Ma trận xác minh trong game

Danh sách dưới đây dành cho lần xác minh tương lai khi có điều kiện,
**không yêu cầu người dùng hiện tại thử thêm**. Dùng bản sao save/slot thử.
Xuất báo cáo trong UI sau tình huống cần quan sát; `status.json` cũng tự
xuất sau 120 frame và mỗi 1.800 frame.

### Khởi động và giao diện

| Tình huống | Kết quả cần quan sát |
| --- | --- |
| Menu/load/quay lại menu | Không lỗi khởi tạo |
| Loading/Esc/cutscene/alt-tab | Đồng hồ không trừ tài nguyên sai |
| EN → VI → EN, reload/restart | Đổi ngay và giữ lựa chọn, không reset run |
| HUD/menu/thông báo tiếng Việt | Đủ dấu, không ô vuông, chỉ đổi phông mod |
| Grace/Leon, FPS/TPS | Nhận đúng nhân vật, HUD/luật áp dụng đúng |

### Thể lực và Stress

| Tình huống | Kết quả cần quan sát |
| --- | --- |
| Chạy cạn, tiếp tục giữ sprint | Mất 16/giây, cạn ép đi bộ/giảm tốc |
| Nghỉ hoặc đi sau cạn | Chờ 2 giây; hồi 12/giây hoặc 6/giây |
| Thể lực lên 24 rồi 25 | Còn kiệt sức tại 24, chạy lại tại 25 |
| Reset/restart khi kiệt sức | Giữ thể lực, kiệt sức, chờ hồi |
| Địa hình/aim/crouch/trúng đòn/ride | Hành động loại trừ không bị giảm sai |
| Licker ngủ/sống trong 12 m | Stress tăng, scan/marker không đếm trùng |
| Xác quái/despawn/ngoài 12 m | Không cộng Stress từ context đó |
| Stress đạt 100, về 99 rồi 90 | Bật hoảng loạn, giữ ở 99, hết tại 90 |
| Hoảng loạn và ẩn HUD | Lệch đạn/camera/overlay vẫn có |
| Pause/tắt mod/hồi Stress | Camera khôi phục, không trôi |
| Sick-state Grace và Leon | Ghi riêng kết quả, không suy từ counter |

### Chiến đấu và inventory

| Tình huống | Kết quả cần quan sát |
| --- | --- |
| Bật bonus đạn/dao/rìu vô hạn | Đạn và độ bền vẫn tiêu hao |
| Bắn nguội rồi nóng | Nguội không kẹt; nóng có thể kẹt |
| Bắn tiếp khi kẹt | Không tạo đạn/tiêu đạn |
| Reload/R khi đầy, đổi súng | Gỡ theo timer; đổi súng không tự gỡ |
| Nhiều súng/upgrade/reload | Chậm hơn, không nhân chồng mãi |
| Hồi máu ở Stress thấp/cao | Đúng hệ số, không giảm hai lần/max HP |
| Load lại cùng khu vực | Khan hiếm ổn định, key item còn |
| Chuyển herb giữa túi/hòm | Không áp lại khan hiếm |
| Balo/hòm/crafting/dialog con | World chạy ở panel hỗ trợ; Esc vẫn pause |

### Đèn và lưu tiến độ

| Tình huống | Kết quả cần quan sát |
| --- | --- |
| Cạn cả hai đèn, lặp nhiều chu kỳ | Tắt nguồn sáng, hồi đúng pool |
| Hồi dưới ngưỡng 15% | Vẫn khóa, HUD hiện ngưỡng rõ |
| Đèn pin 27 / lửa 13,5 năng lượng | Báo sẵn sàng, bật lại bình thường |
| Save thủ công thành công | Quota tăng đúng một lần |
| Cooldown/hết quota | Từ chối, không mất mực do luật hỏng |
| Ép tỉ lệ hỏng mực trên config thử | Mất một ribbon, không ghi/hoàn mực |
| Sau save lỗi | Save cũ còn đọc được, quota không tăng |
| Autosave/checkpoint/chuyển chương | Ghi bị chặn, ghi nhận phản ứng retry |
| System/profile save | Vẫn ghi được, không tiêu quota |
| Cùng `run_id`, load slot cũ | Không hoàn lại tài nguyên/quota |

### One Life Strict

| Tình huống | Kết quả cần quan sát |
| --- | --- |
| Bật, lưu thủ công, thoát/tải | Chỉ slot được xác nhận trong lượt |
| Chết, Continue/Load/reset/restart | Lượt vẫn khóa, file save còn nguyên |
| Ẩn HUD hoặc tắt mod khi đã chết | Thông báo/khóa Một mạng còn hiệu lực |
| Retry checkpoint trong RAM | Game over, chặn đường di chuyển/bắn |
| Mở rồi hủy New Game | Không mở khóa |
| Thực sự khởi tạo New Game | Reset lượt; slot cũ chưa được tin cậy |

### One Life Easy

| Tình huống | Kết quả cần quan sát |
| --- | --- |
| Bật với súng/đạn/phụ kiện/key item | Preflight trước bật, không mất đồ |
| Chí mạng/force-death được hỗ trợ | Gục tùy biến, đúng một cache tại chỗ chết |
| F6 / Continue (Easy) | Điểm yên ổn cùng khu vực, 50% HP |
| Sau Continue | Giữ world/tài nguyên, không Save/Load |
| Tới cache, F7 trong 2 m | Đúng nhân vật/khu vực, metadata giữ đủ |
| Túi đầy/đã nhặt đồ mới | Giữ đồ mới; phần dư còn trong cache |
| Chết tiếp/reset script | Cache cũ giữ, nhật ký đối soát một lần |
| Giao dịch lỗi/khôi phục lỗi | Giữ bản ghi, không tự bỏ đồ mơ hồ |
| Xử tử/ngã/cutscene death | Ghi đường vượt guard, không giả định hỗ trợ |
| Thoát sau Continue | Cần save thủ công mới để có slot tiếp tục |
| Đổi/tắt mode khi còn đồ/gục | Bị từ chối |

### Cài đặt và gỡ

| Tình huống | Kết quả cần quan sát |
| --- | --- |
| Nâng cấp/cài lại | Một namespace, giữ thiết lập/tài nguyên |
| Gỡ mod | Giữ file đã sửa, ledger, REFramework và mod khác |
| Load bản sao save sau gỡ | Game gốc đọc được save |

Nếu tình huống không đạt, lưu báo cáo và ghi nhân vật, súng, cảnh và thao
tác. Không ghi đè save chính để kiểm tra luồng save pre-release.
