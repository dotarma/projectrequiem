# Tính năng Project Requiem

Phiên bản **0.3.0-pre.5**, cập nhật **16/10/2026**. Nền tảng:
**Resident Evil Requiem PC + REFramework**.

Các giá trị dưới đây là mặc định trong mã nguồn và cấu hình đi kèm.
Preset nhân thêm độ khó đang chọn, hướng tới một lượt Insanity/Madness
mới; mod không tự chuyển độ khó của game.

**Tiếng Anh là mặc định.** Chọn **Language → Tiếng Việt** trong menu
Project Requiem để dùng tiếng Việt có dấu. Tài liệu mặc định:
[Features](../FEATURES.md).

**Phạm vi kiểm chứng:** 121 kiểm tra Lua và chín tình huống bộ cài đã qua.
Các bản sửa thể lực, choáng, lệch đạn, hồi đèn và ngôn ngữ chưa được xác
minh lại trong game. One Life, chu trình Easy và toàn chiến dịch vẫn cần
xác minh trực tiếp. Chi tiết bằng chứng: [Kiểm thử](TESTING.md).

## Quái trâu và nguy hiểm hơn

| Cơ chế | Mặc định |
| --- | --- |
| Sức chịu đòn tương đương | ×1,80 |
| Sát thương lên người chơi | ×1,45 |
| Stress tăng sát thương nhận vào | Tối đa thêm 15% |
| Tốc độ quái | ×1,10, hook thử nghiệm |
| Stagger nhận vào | ×0,65, hook thử nghiệm |

Độ trâu được tạo bằng cách giảm sát thương vào HP của quái đã nhận diện.
Mod không sửa HP gốc hoặc trực tiếp đổi ngưỡng chuyển phase boss. Melee,
chất nổ và môi trường cũng có thể bị ảnh hưởng nếu đi qua cùng hàm HP.
Không thêm loại quái hay AI mới.

Ở Stress 100, sát thương nhận vào đạt ×1,6675. Hai hook rank tốc độ và
stagger có thể không tác động nếu game inline hàm; chưa có bằng chứng
trực tiếp xác nhận kết quả trên mọi loại quái.

## Vũ khí yếu hơn, bắn và nạp chậm hơn

| Cơ chế | Mặc định |
| --- | --- |
| Sát thương người chơi | ×0,70 |
| Giãn cách tối thiểu giữa hai phát | ×1,35 |
| Thời gian animation nạp đạn | ×1,50 |
| Stress tăng giãn cách giữa các phát | Tối đa thêm 30% |
| Stress tăng thời gian nạp | Tối đa thêm 25% |

Sát thương ×0,70 kết hợp sức chịu đòn ×1,80 còn khoảng **38,9%** so với
cùng độ khó trước mod, trước sai số làm tròn HP. Ở Stress 100,
giãn cách giữa các phát đạt ×1,755 và thời gian nạp đạt ×1,875.

Giãn cách dựa trên thông số gốc đọc được. Nếu chưa đọc được, dùng nền
**0,25 giây** rồi áp hệ số. Animation nạp chậm bằng tốc độ chuyển
động, giữ luồng sự kiện nạp của game. Hệ số không nhân chồng mỗi frame;
khôi phục khi hết nạp hoặc tắt mod. Từng súng/animation vẫn cần xác minh.

## Ép tắt vô hạn đạn và độ bền

- Tắt bonus vô hạn đạn súng và rocket launcher tích hợp của game.
- Tắt bonus vô hạn độ bền dùng chung cho dao/rìu.
- Tắt cờ vô hạn/không tiêu hao trên panel vũ khí đang trang bị có loader,
  gồm đường xử lý độ bền liên quan.
- Kết hợp chặn getter và ép cờ boolean để tác động cả đường đọc field.

Khi tắt/reset script, mod khôi phục giá trị đã quản lý nếu đối tượng còn
hợp lệ và giá trị chưa bị thay bởi thành phần khác. Không bảo đảm cưỡng
chế được mọi trainer hoặc mod sửa trực tiếp hàm tiêu hao.

## Vật phẩm hồi máu khan hiếm và kém hiệu quả

| Cơ chế | Mặc định |
| --- | --- |
| Giữ đồ hồi máu ngoài thế giới | Khoảng 40% vị trí spawn đã nhận diện |
| Hồi máu ở Stress 0 | 45% lượng hồi gốc |
| Hồi máu ở Stress 100 | 33,75% lượng hồi gốc |
| Giữ mực ngoài thế giới | Khoảng 45% vị trí ribbon đã nhận diện |

Quyết định giữ/ẩn cố định theo `seed`, `run_id`, ID và vị trí nhận diện.
Quay lại hoặc load cùng khu vực không roll lại nếu cùng cấu hình. Tỉ lệ
là trên nhiều vị trí, không bảo đảm mỗi phòng giữ đúng 40% hoặc 45% đồ.
Nếu thiếu định danh/vị trí ổn định, mod giữ vật phẩm.

Chỉ áp dụng cho đồ ngoài thế giới trong danh sách ID đã biết. Key item,
đồ nhiệm vụ và ID ngoài danh sách hồi máu/mực được giữ. Không áp lại khan
hiếm khi chuyển đồ giữa túi/hòm, craft, mua hoặc khôi phục inventory.

Giảm hồi máu chỉ áp dụng cho vật phẩm của người chơi hiện tại, không
giảm HP tối đa. Nếu game gọi lồng hai hàm hồi máu, chỉ giảm một lần.

## Stress Meter

Thanh **Stress từ 0 đến 100** thể hiện mức căng thẳng. Các nguồn tăng có
thể cộng dồn; khi không có nguồn tăng liên tục, Stress giảm dần.

### Nguồn tăng và giảm

| Tình huống | Mặc định |
| --- | --- |
| Quái sống đang hiện diện trong 12 m | +1,8/giây |
| HP dưới 30% tối đa | +0,9/giây |
| Quái gần và đèn đã nhận diện đang tắt | Thêm +0,35/giây |
| Bị đánh | +8, thêm tối đa 15 theo phần HP mất |
| Một phát bắn được ghi nhận | +0,7 |
| Không có nguồn tăng liên tục | −0,65/giây |

Quái trong phạm vi gồm Licker ngủ/đợi phục kích vẫn hiện diện. Bộ quét
dùng nhiều danh sách enemy/context, bỏ trùng và ưu tiên vị trí transform
thực tế, kể cả quái trên tường/trần. Context bị suspend vẫn có thể được
tính nếu còn sống và hiện diện.

Xác chết, object đã tắt, context despawn không có object và vị trí không
đọc được bị loại. Báo cáo ghi nguồn quét và số context thiếu vị trí. Quét
bắt đầu khi có người chơi rồi cập nhật khoảng **0,25 giây**. HUD hiện
quái gần nhất trong vùng, khoảng cách và mức Stress tăng do ở gần.

Điều kiện đèn chỉ kiểm tra nguồn sáng người chơi đã nhận diện đang tắt;
**không đo độ tối hay ánh sáng thực tế của môi trường**.

### Ảnh hưởng theo mức Stress

| Hiệu ứng | Stress 0 | Stress 100 |
| --- | --- | --- |
| Sát thương nhận vào | ×1,45 | ×1,6675 |
| Hiệu quả hồi máu | 45% | 33,75% |
| Giãn cách giữa các phát | ×1,35 | ×1,755 |
| Thời gian nạp | ×1,50 | ×1,875 |
| Hồi độ chính xác qua reticle | ×1,00 | ×0,45 |
| Kẹt khi nhiệt tối đa | 8%/phát | 16%/phát |
| Thời gian gỡ kẹt | 3 giây | 4,5 giây |

Hệ số thay đổi liên tục giữa hai đầu bảng. HUD đổi màu tại **45** và
**75**, cảnh báo Stress cao từ 75 trở lên. Hoảng loạn chỉ bắt đầu ở 100.

### Hoảng loạn ở Stress 100

Áp dụng cho Grace/Leon đang điều khiển. Khi Stress đạt **100**, trạng
thái được giữ tới **90 hoặc thấp hơn**, tránh bật/tắt quanh mốc 100.

- Ép tâm ngắm mất hội tụ, hạ điểm ổn định về mức tối thiểu sau game update.
- Làm lệch trường hướng hợp lệ trong request tạo đạn theo nón **2,5°**,
  giữ độ dài vector. Nếu không có trường hướng, lệch pitch/yaw khoảng
  **2,5°** tại bước tạo shell. Không áp cả hai đường lên cùng một phát.
- Không phụ thuộc điểm ngắm cache có thể bị game tính lại khi tạo đạn.
- Camera rung/nghiêng tối đa **0,6° pitch, 0,7° yaw, 1,5° roll**. Góc
  được khôi phục trước gameplay update, khi hồi phục hoặc tắt/reset mod;
  không cộng dồn thành trôi camera.
- Lớp haze/tối viền co giãn chậm tạo cảm giác choáng, vẫn hiện khi ẩn HUD.
  Đây là overlay riêng, chưa phải bản sao postprocess của Leon.
- Nhận diện bằng mã Grace/Leon khi thiếu cờ nhân vật của game.
- Có hook fear/sick-state gốc. Sick-state chỉ bị ép nếu nhân vật có
  `SickSeizureConfiguration` hợp lệ; không ghép cấu hình/animation Leon
  sang Grace. Caller có thể inline hoặc không dùng các getter này.

Hiệu ứng tạm ngưng khi pause/không có gameplay hợp lệ, dừng khi hồi phục
hoặc tắt mod. Trạng thái hoảng loạn lưu cùng Stress trong ledger. Lệch
đạn không dùng RNG của kẹt đạn/mực, nên cập nhật ngắm không đổi lượt roll.

Kết quả đạn/camera và hình ảnh sick-state của từng nhân vật còn cần xác
minh trong game. Không suy ra Grace choáng giống Leon từ việc hook đã gắn.

## Nhiệt súng và kẹt đạn

| Cơ chế | Mặc định |
| --- | --- |
| Nhiệt mỗi phát được ghi nhận | +0,18, tối đa 1,00 |
| Nguội mỗi giây chơi | −0,14 |
| Ngưỡng bắt đầu roll kẹt | 0,40 nhiệt |
| Xác suất tối đa | 16%/phát ở nhiệt 1,00 và Stress 100 |
| Thời gian gỡ kẹt | 3–4,5 giây tùy Stress |
| Nhiệt sau gỡ | 0,20 |

Xác suất mỗi phát đủ ngưỡng là:

```text
0,16 × nhiệt × (0,5 + 0,5 × Stress / 100)
```

Súng nguội không roll kẹt. Roll theo sự kiện phát bắn đã ghi nhận, không
theo frame hoặc mỗi lần giữ nút. Khi đã kẹt, mod chặn bắn, tạo projectile
và tiêu hao đạn của các phát tiếp theo. Sự kiện đến trễ không tạo phát
bắn ảo hoặc roll lại.

Nhấn **Reload** theo phím/nút tay cầm đã gán, hoặc **R** dự phòng, rồi
chờ gỡ. Có đường bắt input khi băng đầy. Đổi súng không tự gỡ kẹt.

Nhiệt/kẹt được theo dõi riêng theo nhân vật và súng trong phiên Lua;
không lưu ledger. Reset script, khởi động lại hoặc loading mất context
sẽ xóa chúng. Tổng bộ đếm phát bắn/kẹt vẫn được lưu theo run.

## Thể lực

| Cơ chế | Mặc định |
| --- | --- |
| Dung lượng | 100 điểm |
| Chạy tiêu hao | 16/giây, khoảng 6,25 giây từ đầy |
| Chờ sau khi dừng chạy | 2 giây |
| Hồi khi nghỉ | 12/giây |
| Hồi khi di chuyển | 6/giây |
| Hết kiệt sức | Hồi đủ 25 điểm |
| Tốc độ phát lớp chuyển động đi bộ khi kiệt sức | 60% |
| Tốc độ phát lớp chuyển động chuyển tiếp chạy | 40% |

Đi bộ không tốn thể lực. Cạn sẽ hủy sprint, ép đi bộ sau xử lý input và
giảm tốc lớp chuyển động. Giữ nút chạy khi kiệt sức vẫn hồi được.
Các hệ số là tốc độ phát chuyển động; chưa đo vận tốc thực tế trong game.

Hệ số không cộng dồn, được khôi phục khi hồi đủ hoặc chuyển sang nạp.
Không làm chậm camera hay thời gian toàn game. Thao tác địa hình, phản
ứng trúng đòn, lái xe và nạp đạn được loại khỏi giảm tốc do kiệt sức.
Thể lực, kiệt sức và chờ hồi lưu trong ledger; pause/loading không tiến.

## Chế độ Một mạng

**One Life mặc định tắt**, chính sách mặc định là **Strict**. Menu có nút
bật Strict và Easy riêng. Ledger đã bật từ bản cũ nhưng thiếu chính sách
vẫn dùng Strict; chỉ sửa config không chuyển một lượt đã bật sang Easy.

Cả hai chế độ giữ luật save/quota/mực và cấm autosave. Nếu bật giữa chiến
dịch, cần save thủ công thành công mới trước khi thoát để có slot tiếp tục.

### One Life Strict

Bật bằng **Enable One Life / Bật chế độ Một mạng**. Có thể tắt qua menu
khi còn sống. Chết sẽ khóa lượt và ghi trạng thái ngay.

- Continue/Load không hồi sinh được lượt đã chết. Reset script, khởi
  động lại hoặc tắt checkbox mod chung không mở khóa.
- Khi sống, chỉ tải slot thủ công đã lưu thành công trong lượt hiện tại.
  Autosave, slot cũ/chưa xác định bị chặn; system/profile được nhận diện
  vẫn tải được.
- Thông báo lượt kết thúc vẫn hiện khi ẩn HUD. Nếu checkpoint trong RAM
  hồi sinh nhân vật, mod yêu cầu game over và chặn đường di chuyển/bắn
  đã nhận diện.
- Thực sự bắt đầu **New Game** mới đặt lại lượt và tăng số lần thử. Chỉ
  mở rồi hủy New Game không mở khóa.
- New Game đặt lại tài nguyên, Stress, thể lực, quota/cooldown, RNG/mực và
  slot được tải. Slot lượt trước bị chặn tới khi lượt mới ghi thành công
  chính slot đó.

File save gốc được giữ, không bị xóa hoặc làm hỏng. Thứ tự tử vong,
New Game, kiểu dữ liệu slot và mọi checkpoint chưa được xác minh đầy đủ.

### One Life Easy

Bật **Enable One Life (Easy) / Bật One Life (Easy)** tại vùng yên ổn.
Mod kiểm tra chuyển đổi toàn bộ dữ liệu inventory hiện tại trước khi
bật. Dữ liệu chưa hỗ trợ sẽ khiến việc bật bị từ chối, giữ nguyên đồ.

Đòn chí mạng qua đường HP/force-death được hỗ trợ bị chặn tử vong gốc,
hiện gục. **F6 / Continue (Easy)** đưa tới điểm yên ổn đã ghi gần nhất
cho cùng nhân vật/khu vực, hồi **50% HP**. Không tải save hoặc tua lại
thế giới. Stress, thể lực, năng lượng, quota và cooldown giữ nguyên.
Trong lúc gục, thế giới có thể tiếp tục nhưng đồng hồ tài nguyên mod dừng.

#### Đồ rớt và thu hồi

- Mọi panel mang theo và đồ archive trong inventory, **kể cả key item**,
  chuyển vào đống đồ tại vị trí chết.
- Dữ liệu deploy giữ số lượng, đạn đang nạp và phụ kiện. Panel phụ kiện
  đã gắn không được gửi thêm lần nữa thành bản rời.
- Đống đồ có marker và khoảng cách trong thế giới, không spawn model đồ
  rời. Đồ trong hòm, file inventory và tiền ví riêng không thuộc phạm vi
  inventory mang theo được chuyển.
- Quay lại trong **2 m**, đúng nhân vật/khu vực, nhấn **F7** hoặc nút nhặt
  trong menu. Túi đầy thì đồ dư vẫn ở đó; đồ nhặt mới sau Continue được giữ.
- Chết tiếp không xóa đống chưa nhặt. Tối đa **128 đống còn đồ**.
- Phải thu hồi hết đồ và giải quyết trạng thái gục trước khi đổi/tắt chế
  độ qua menu. New Game đặt lại lượt và danh sách đống đồ.

#### Giao dịch và lưu tiến độ

Nhật ký được ghi trước khi xóa inventory. Snapshot gốc cho phép khôi
phục nếu lỗi xóa/lưu và API còn hoạt động. Nhặt đồ kiểm tra sức chứa,
ghi nhật ký và xác nhận đủ số lượng tăng trước khi đánh dấu đã nhận.

Dữ liệu vòng lặp, quá lớn, chưa hỗ trợ hoặc claim bị gián đoạn mơ hồ sẽ
bị chặn. Nếu khôi phục thất bại, bản ghi đồ/lỗi được giữ để đối soát thay
vì bỏ đồ âm thầm. Đây là bảo vệ cục bộ, không bảo đảm giao dịch nguyên
tử chống crash giữa bộ nhớ game và JSON.

Continue chỉ dùng trong **phiên game hiện tại**. Ledger không lưu cả thế
giới. Chết hủy quyền tải slot trước đó để hạn chế nhân đồ; sau Continue
cần save thủ công thành công trước khi thoát nếu muốn tiếp tục lần sau.
Nhật ký gục/cache tồn tại qua reset Lua nhưng không thay thế save game.

#### Giới hạn chưa kiểm chứng

Chưa quan sát chu trình inventory/chuyển đổi/di chuyển/nhặt hoàn chỉnh
trong game. Xử tử, ngã, cutscene hoặc đường chết vượt guard có thể gây
tử vong gốc không đảo ngược và kết thúc lượt.

Điểm yên ổn không phải checkpoint hoặc vị trí navmesh đã được game xác
nhận. Đường một chiều, streaming, chuyển nhân vật và tiến độ cốt truyện
có thể khiến vị trí hồi sinh/đống đồ khó tới hoặc không còn tới được.

## Đèn pin và bật lửa

| Nguồn | Dung lượng | Ngưỡng bật lại sau cạn |
| --- | --- | --- |
| Đèn pin / BodyLight | 180 giây | 27 giây năng lượng, 15% |
| Bật lửa | 90 giây | 13,5 giây năng lượng, 15% |

Hai nguồn dùng năng lượng riêng. Khi tắt, mỗi nguồn hồi **0,15 giây năng
lượng mỗi giây gameplay**, tới dung lượng tối đa. Từ cạn tới ngưỡng cần
khoảng **180 giây chơi** với đèn pin hoặc **90 giây chơi** với bật lửa.

Cạn sẽ khóa sử dụng và ép cờ bật/hiển thị nguồn sáng người chơi sau game
update. Không gửi lệnh tắt ngoài lặp lại hoặc ép cường độ về 0. Các ghi
mới của controller được giữ để khôi phục khi bỏ khóa/tắt mod; sau đó
người chơi bật đèn bằng thao tác bình thường.

HUD hiện năng lượng/ngưỡng khi chờ hồi và báo lúc sẵn sàng. Năng lượng
dương nhưng dưới 15% vẫn bị khóa. Trạng thái chờ hồi tồn tại qua reset
và khởi động lại. Ledger cũ dưới ngưỡng chuyển sang chờ hồi, giữ năng lượng.

Không thêm vật phẩm pin/nhiên liệu hoặc animation thay pin. Ánh sáng
chung của màn chơi giữ nguyên. Kiểm thử emitter giả lập chưa chứng minh
tất cả biến thể đèn tắt/bật đúng về mặt hình ảnh trong game.

## Túi và hòm đồ không pause

Chặn yêu cầu pause đã nhận diện của balo Grace, inventory Leon, item box
và tab/nền/mô tả/crafting trong luồng inventory. Quái và thời gian chơi
có thể tiếp tục khi quản lý đồ. Esc, loading và cutscene giữ pause gốc.
Một số dialog con hoặc cảnh đặc biệt có thể dùng đường pause khác.

## Autosave và save thủ công

**Cấm ghi tiến độ tự động khi mod bật**, không có công tắc autosave riêng.

- Chặn Auto và category gameplay tùy biến 6–9.
- Guard segment/slot chặn thêm đường ghi khác; slot Auto vẫn bị chặn
  ngay cả trong luồng gọi save thủ công.
- Request chưa phân loại và không có category hợp lệ bị từ chối.
- Save cấu hình/profile vẫn được phép, không tiêu quota thủ công.

File autosave cũ được giữ. Chặn ghi không xóa checkpoint trong RAM.
Phản ứng retry/checkpoint/chuyển chương chưa được xác minh toàn chiến dịch.

### Hạn mức thủ công

| Luật | Mặc định |
| --- | --- |
| Save thành công tối đa mỗi `run_id` | 12 |
| Chờ sau lần thành công | 900 giây gameplay, 15 phút |
| Save đầu của run mới | Không có cooldown ban đầu |
| Save thất bại | Không tăng quota/cooldown thành công |

Request thủ công phải qua giao diện máy lưu của game và luật mod. Phần
không yêu cầu ribbon vẫn chịu quota/cooldown. Chỉ callback ghi thành
công của game mới tăng số save đã dùng.

### Mực có thể hỏng

Luồng vốn yêu cầu ribbon cần **ribbon hữu hạn thật**; bonus mực vô hạn
không thay thế được. Mỗi giao dịch dùng mực hợp lệ có **25% nguy cơ hỏng**.

Mực hỏng mất đúng **một ribbon**, chặn ghi, không hoàn mực và không tăng
số save thành công. HUD báo **MỰC BỊ HỎNG**; game có thể hiện lỗi save gốc.
Cùng giao dịch giữ kết quả roll, không roll lại khi kiểm tra nhiều lần.
Bị chặn vì quota/cooldown vẫn giữ cơ chế hoàn mực bình thường của game.

Hỏng mực áp dụng nơi game vốn cần ribbon, thường là Grace. Không thêm
yêu cầu mực ở phần khác, không phá hoặc xóa save cũ để mô phỏng hỏng.

## Đồng hồ gameplay

Stress, thể lực, nhiệt/gỡ kẹt, đèn và cooldown dùng thời gian gameplay
đã nhận diện, không dùng số frame hoặc thời gian ngồi ở menu.

Bộ đếm dừng khi pause/loading, context không hợp lệ/chết/suspend,
cutscene invalidation, mất focus/thu nhỏ nếu có API. Frame trên
**0,5 giây** bị bỏ qua để tránh trừ tài nguyên hàng loạt khi đứng máy.
Inventory thực sự không pause vẫn để các đồng hồ tiếp tục.

## HUD và ngôn ngữ

HUD hiện Stress, thể lực/kiệt sức, lượt Một mạng, năng lượng, quota,
luật hữu hạn/cấm autosave, kẹt đạn/hoảng loạn và quái gần đã nhận diện.
Vị trí mặc định **(28, 80)**, có thể sửa `hud_x`/`hud_y`.

Menu có bật/tắt mod, HUD, One Life, Continue/nhặt Easy, chọn ngôn ngữ và
xuất báo cáo. Ẩn HUD không tắt gameplay hoặc overlay hoảng loạn; thông
báo lượt Một mạng chết vẫn hiện.

English và Tiếng Việt bao phủ nhãn, nút và thông báo; thông báo đang chờ
dùng ngôn ngữ hiện tại. Chọn ngôn ngữ lưu ngay, giữ sau reload, không
reset run. Pre.5 dùng đúng khóa bảng Lua 1/2 của combo REFramework.

Phông Noto Sans có dấu tiếng Việt chỉ áp dụng cho UI mod. ID engine,
khóa JSON, tên file và event chẩn đoán giữ định danh kỹ thuật tiếng Anh.

## Dữ liệu run và cấu hình

Cấu hình: `reframework/data/project_requiem/config.json`. Ledger:
`reframework/data/project_requiem/<run_id>.json`.

Ledger lưu Stress/hoảng loạn, thể lực/kiệt sức/chờ hồi, đèn/trạng thái
chờ hồi, thời gian, quota/cooldown, RNG/quyết định mực, Một mạng/lượt
chết/slot được tải, cache/nhật ký Easy và bộ đếm tổng.

Ghi phụ khoảng **15 giây gameplay**, khi save/config/reset/report liên
quan; ghi ngay khi Một mạng chết/đổi chế độ/New Game/save thành công.
Đây là dữ liệu phụ, không phải autosave tiến độ game. Crash hoặc lỗi
đĩa có thể mất trạng thái chưa ghi.

Ledger gắn với `run_id`. Load slot cũ không hoàn tài nguyên/quota. New
Game tạo lượt mới trong ID hiện tại. ID khác tách chiến dịch. Sửa/xóa
ledger có thể vượt luật; mod không phải chống gian lận.

Config kiểm tra kiểu/khoảng giá trị, bỏ khóa chưa biết, giới hạn hoặc
trả mặc định khi sai. Đóng game trước khi sửa. Danh sách đầy đủ khóa,
mặc định và ngưỡng cố định: [Configuration](../CONFIGURATION.md).

Cấm autosave, ép hữu hạn, bán kính 12 m, Stress 100/90, lệch 2,5° và
ngưỡng đèn 15% không có công tắc JSON riêng. Tắt mod chung dừng luật
thông thường; luật chết/tải của lượt Một mạng đã bật vẫn có hiệu lực.

## Chẩn đoán và phân phối

- Có **mười file Lua** chạy qua REFramework. Reflection kiểm tra chữ ký
  TDB83, không dùng offset cố định; hook storage hỗ trợ gọi lồng theo luồng.
- Báo cáo `status.json` tự xuất sau 120 frame, mỗi 1.800 frame hoặc nút UI.
- Báo cáo gồm hook/lỗi/event, tài nguyên, di chuyển/thể lực/tốc độ motion,
  Một mạng/slot/cache, súng/kẹt, nhân vật/camera, field request đạn phản
  chiếu, cờ đèn/renderer, bonus, save bị chặn, quét quái và ngôn ngữ.
- `installed` nghĩa hook đã gắn; `calls` là game gọi; `events` là đường
  luật đã chạy. Chúng không chứng minh kết quả gameplay hoặc hình ảnh.
- Log chung ở `re2_framework_log.txt`.
- Bộ cài sao lưu file sở hữu, chuyển tên cũ, giữ mod khác. Gỡ giữ dữ liệu
  và file đã chỉnh sửa. Gói không chứa DLL REFramework hoặc tài sản game.
- Mã MIT; phông Noto Sans có giấy phép OFL riêng.

Không chạy cùng overhaul độ khó, vô hạn đạn/đồ/độ bền, no reload, rapid
fire hoặc sửa save. Giữ mod khác trong cài đặt không chứng nhận mọi
phiên bản của các mod đó tương thích.

Xem [Cài và dùng](README.md), [Kiểm thử](TESTING.md),
[Changelog](../../CHANGELOG.md) và [Sources](../SOURCES.md).
