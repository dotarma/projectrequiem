# Installation

This guide covers Project Requiem **0.3.0-pre.5**. For balance and mode
rules, see [Features](FEATURES.md). Vietnamese readers can start with the
[Vietnamese guide](vi/README.md).

## Before installing

1. Close Resident Evil Requiem.
1. Locate the folder containing `re9.exe`.
1. Install the RE9-compatible build of [REFramework][reframework]. Its
   `dinput8.dll` belongs beside `re9.exe`.
1. Back up the game saves you intend to use with this pre-release.

Project Requiem contains ten Lua files, a default configuration and a
font/license pair. It does not replace the executable or REFramework DLL,
and does not require Loose File Loader.

## Recommended installation

Extract the release ZIP and open PowerShell in the extracted folder:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1 `
  -GamePath 'C:\Games\Resident Evil Requiem'
```

Replace `GamePath` with your game folder. The execution-policy override
applies to this PowerShell process; it does not change machine policy.

The installer validates the package and configuration, backs up replaced
owned files, then installs the Lua scripts and font. Existing balance
settings and run ledgers are retained. A missing language key becomes
`"language": "en"`; an existing language preference is retained.

The installer normally stops if the game is running. `-AllowRunning` can
stage files on disk, but copying them does not activate the new scripts.
A full game restart is still required.

## Upgrading older versions

Use `Install.ps1` when upgrading Project Requiem, Khúc Cầu Hồn / Requiem
0.2.x or ULTRADEAD 0.1.x. Do not merge old and new autorun folders and leave
both entrypoints enabled.

For recognized legacy installations, the installer:

1. Checks the old entrypoint's ownership marker. An unrecognized legacy
   entrypoint stops the upgrade before replacement.
1. Backs up owned files, preserving relative paths, under
   `reframework/data/project_requiem/install-backups/<timestamp>/`.
1. Migrates old JSON ledgers only when the destination does not exist.
   Configuration priority is Project Requiem, `khuc_cau_hon`, then
   `ultradead`.
1. Adds English as the default only when the language key is missing.
1. Installs the current namespace and removes recognized legacy code and
   font files. Original legacy data folders remain available.

Old `status.json` reports are not migrated as current reports. The
installer does not edit native game saves. If installation fails, resolve
the reported file/configuration issue before starting the game. A restored
legacy entrypoint must not run alongside the current one.

## Manual fresh installation

For a fresh install, copy the package's `reframework` folder beside
`re9.exe`. The resulting layout is:

```text
Resident Evil Requiem/
  re9.exe
  dinput8.dll                 # REFramework; installed separately
  reframework/
    autorun/
      project_requiem.lua
      project_requiem/
        core.lua
        sdk_util.lua
        combat.lua
        world.lua
        saves.lua
        locale.lua
        survival.lua
        loot_codec.lua
        easy_life.lua
    data/project_requiem/config.json
    fonts/project_requiem/
      NotoSans-Regular.ttf
      OFL.txt
```

For upgrades, use the installer so the default JSON does not overwrite
your settings and recognized old namespaces are removed safely.

## First startup

Open **Insert → Script Generated UI → Project Requiem**. Fresh installs
enable the mod and HUD; upgrades retain existing settings.

Choose **Language → English / Tiếng Việt** to change the interface. The
choice saves immediately. Version pre.5 fixes the selector's table-key
mapping. Its automated checks pass; direct native UI verification remains
pending.

The preset targets a new Insanity/Madness run and multiplies other selected
difficulties too. It does not change the native difficulty setting.
World-item visibility changes may require reloading the area or save.

## Separate campaigns

Native **New Game** resets the active mod ledger and increments the
attempt number. To retain separate campaign ledgers, close the game and
choose another `run_id`, such as `campaign-02`, in the configuration.

A new ID starts with full resources and quota. Normal native saves share
the active ledger. One Life additionally limits resume to successful
manual saves from the current attempt. See [Configuration](CONFIGURATION.md).

## Optional One Life

### Strict

Choose **Enable One Life** in the mod menu. Strict is off by default. It
can be enabled before New Game or while alive in an existing campaign.
After activation, make a successful manual save before quitting if you
need resume access. Disable only while alive.

After death, return to the title screen and start **New Game**. Native
save files remain on disk. The general mod checkbox and script resets do
not revive a dead One Life attempt.

### Easy

During live gameplay at a calm point, choose **Enable One Life (Easy)**.
Activation checks the current carried inventory before enabling the mode.

After a supported defeat, press **F6 / Continue (Easy)**. The current live
world resumes at the last recorded calm point in the same player/area,
with 50% HP. Return within **2 m** of the marked death cache and use
**F7 / Recover**.

After Continue, make a successful manual save before quitting if you need
resume access. The full native revival/transfer/recovery cycle remains
unverified. See [Easy rules and limits](FEATURES.md#one-life-easy).

## Removal

Close the game. Run the installer from the same release package:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1 `
  -GamePath 'C:\Games\Resident Evil Requiem' -Uninstall
```

Only installed files whose hashes match the package are removed. Modified
or unverifiable files, including files from another version, are retained
with a warning. Configuration, ledgers, backups, REFramework and unrelated
mods remain available.

For manual removal, remove only the Project Requiem entrypoint, its nine
Lua modules and its dedicated font/license files. Keep the data folder if
you plan to reinstall.

[reframework]: https://github.com/praydog/REFramework-nightly/releases
