# Verification and testing

Project Requiem **0.3.0-pre.5** has automated rule, API-fixture, UI and
installer coverage. These checks do not establish complete native gameplay,
visual correctness or campaign compatibility. The release remains a
**pre-release**.

## Automated checks

| Lua suite | Checks |
| --- | --- |
| Core rules | 26 |
| Stamina and One Life | 11 |
| Easy and loot transactions | 25 |
| Runtime/API fixtures | 44 |
| Locale | 4 |
| UI and migration | 11 |
| Total | 121 |

All ten shipped Lua files compile under Lua 5.4. Hook signatures are checked
against captured RE9 **TDB83** metadata. Nine installer scenarios cover
fresh installation, both previous namespaces, settings/ledger/backup
preservation, reinstall, modified-file-safe removal and rejection of
unrecognized/broken input.

### Gameplay and resource coverage

- Damage/healing scaling, finite bonuses, scarcity, jams, live inventory,
  manual/automatic saving and dormant-threat scanning.
- Sprint duration, delayed/half-rate recovery, exhaustion thresholds,
  pause/stall guards and persisted exhaustion. Native post-input sprint
  rewrites, forced-walk restoration and non-compounding locomotion playback
  cover transitions into/out of reloads. Root-translation restoration is
  still checked for One Life's death lock.
- Panic thresholds and Grace/Leon kind-ID eligibility; cached-target
  recalculation, temporary final shell rotation and reflected request
  direction discovery/deduplication. Camera checks cover bounded sway without
  drift and restoration on pause, disable and recovery.
- Both light pools through repeated depletion/unlock/toggle cycles, exact
  15% thresholds, persisted latches and legacy migration. Checks assert no
  intensity change or external off request, plus recharge/ready messages.

The uncaptured projectile-request parent direction field is an explicitly
synthetic fixture, not evidence of a native field layout.

### One Life and Easy coverage

- Immediate current-player death persistence, resistance to config/reset
  bypass and successful-save slot registration.
- Old/unknown/dead-slot denial, allowed system loads, native New Game reset,
  stale-death suppression and in-memory respawn movement/fire/save guards.
  The dead notice stays visible with the ordinary HUD/mod disabled.
- Easy activation preflight, soft lethal/force-death guards and same-session
  Continue without save/load calls.
- Exact cache coordinates, typed owned-data round trips, attached-panel
  deduplication, archive/key-item transfer, capacity/range/identity checks
  and retention of newly acquired items.
- Failure rollback, journal reconciliation and mode/slot restrictions.

Serializer tests use synthetic weapon, attachment, round and boxed-data
graphs. They do not claim captured native weapon layouts. Mutation method
signatures match TDB83; archive read getters are checked by reflection.

### Language, UI and package coverage

- English defaults, Vietnamese selection, key/format parity and fallback.
- Loading the renamed entrypoint with older config/ledger data.
- Switching both languages through the real one-based Lua table keys,
  immediate persistence and reload of saved Vietnamese without resetting
  resources, death status or One Life attempt. The UI mock reproduces
  REFramework's first-key fallback for an invalid selection.
- Stable widget IDs and balanced font handling.
- Bundled font codepoints/ranges for the interface text.
- Release archive CRC and SHA-256 manifest verification.

These are Lua/SDK/UI mocks and file checks. They do not emulate every native
weapon animation, ValueType ABI, visual pipeline or save/checkpoint
transaction.

## Native evidence

### Earlier 0.2 reports

Collected reports show a live gameplay clock, jam input/ammo guards,
light-renderer override events, finite-bonus enforcement and rejection of an
automatic gameplay save, without collected callback errors. They confirm
calls/guards, not complete gameplay or visual correctness.

The user reported no Stress increase near a Licker. The old scanner excluded
suspended contexts and depended on HP readings. New scanning, positions and
diagnostics address possible exclusions, but the exact native cause was
not conclusively captured. A zero-call accuracy getter also motivated
additional reticle/target paths.

### Pre.3 report and reported failures

A collected pre.3 development report contains:

- Six stamina exhaustion/recovery events.
- 2,176 movement-scaling events and 2,371 sprint-block events.
- No collected hook errors on those paths.
- An attached Easy `forceDead` hook with zero calls and no observed Easy
  death/cache/Continue cycle.

The user then reported running with empty stamina, no Grace dizziness, no
bullet deviation and lights that would not switch on after recharge. The
report shows zero calls to native sprint-switch, sick/fear and
`calcFireDirection` methods, plus repeated light-renderer shutoff events.
Those findings prevent interpreting the old event counts as gameplay
success.

Recorded flashlight energy was 16.049, below the 27-energy unlock threshold.
The old HUD did not explain that threshold. This may explain that particular
locked state; it does not resolve every light-control problem.

### Pre.4 and pre.5 corrections

Pre.4 replaces ineffective movement, projectile, camera and light-control
paths as described in [features](FEATURES.md). The replacements have **not
been re-tested live**. Automated checks cover control flow/restoration,
not native motion, ValueType ABI or visual results. A full game restart
clears the previous runtime's possible external light latch. No manual
game reset or new gameplay test was performed for that update.

The user next reported that English could not switch to Vietnamese. Pre.5
corrects zero-based combo indices to the returned Lua keys 1/2 and checks
immediate persistence/reload using the corrected mock. It has **not been
verified in the native UI**. No further gameplay test was requested.

## Remaining verification gaps

No full native validation covers the later Licker/panic changes,
localization, One Life or Easy. Outstanding checks include:

- Grace's sick-state appearance and each weapon's actual trajectory.
- Empty lighter visuals and every chapter/checkpoint transition.
- Native death, New Game and value-type slot identity.
- A successful native resume through category-level slot-resolution fallback.
- Easy current-inventory preflight, owned-item serialization, warp/HP reset,
  capacity, rollback and recovery with real items.

Easy points are not engine checkpoints/navmesh validation. Scripted death,
streaming, one-way routes, story progress and character changes may bypass
guards or make caches unreachable. See [Easy limits](FEATURES.md#one-life-easy).

## Running the source checks

Use Python with a compatible Lupa wheel:

```powershell
python -m pip install --target .tools/python lupa
python tools/test.py
powershell -NoProfile -ExecutionPolicy Bypass -File .\tests\installer_spec.ps1
python tools/package.py
```

The development workspace also provides `.tools/python314/python.exe` for
Lua checks. Portable runtimes, archives, research dumps and personal ledgers
are excluded from the release ZIP.

With Node.js 22 or later, run Markdown checks from the repository root
using its configuration:

```powershell
npx markdownlint-cli2
```

## Future native test matrix

Use disposable/backed-up game-save slots when native testing is available.
This matrix records future verification work; it does not request another
test from the current user.

### Startup, timing and interface

1. **Launch/load/menu:** no initialization errors; resources do not drain
   during loading, Esc pause or unfocus.
1. **English/Vietnamese:** menu, HUD and notifications switch; accents render
   completely and preference survives restart.
1. **Grace/Leon in FPS/TPS:** HUD and supported rules target the active player.
1. **Upgrade/reinstall/uninstall:** one active namespace; settings/resources
   preserved and unrelated mods retained.

### Stamina and panic

1. **Sprint to zero, hold sprint, rest/walk:** drain 16/second, wait 2 seconds,
   recover 12/second idle or 6/second moving; sprint unlocks at 25.
1. **Stairs/crouch/aim/terrain/damage/riding:** ordinary locomotion slows;
   excluded actions and unrelated animations remain native.
1. **Reset/restart exhausted:** stamina, exhaustion and delay persist.
1. **Dormant/live Licker within 12 m:** Stress rises and scan diagnostics
   identify the threat. Corpses, despawned contexts and enemies outside
   12 m contribute nothing through proximity.
1. **Stress 100, 99, 90:** panic starts, stays latched, then releases.
1. **Panic with HUD hidden:** projectile deviation, bounded sway and overlay
   remain; pause/recovery restores the camera.
1. **Native sick-state comparison:** record Grace and Leon separately;
   method calls alone do not establish matching visuals.

### Combat and resources

1. **Cold shots/hot bursts:** cold shots do not jam; hot bursts can. Blocked
   later shots consume no ammunition.
1. **Jam with full magazine/weapon swap:** Reload/R starts timed clearing;
   swapping alone does not clear it.
1. **Reload variants/upgrades:** slower animation without cumulative scaling.
1. **Healing at low/high Stress:** reduced recovery, no double scaling and
   unchanged maximum HP.
1. **Pickup revisit/item-box transfers:** stable scarcity; transfers remove
   no additional items and key items remain.
1. **Inventory/box/crafting dialogs:** recognized panels leave the world live;
   Esc still pauses. Record special subdialogs separately.
1. **Repeated light depletion/recharge/toggle:** emitters turn off; the HUD
   explains 15% and announces readiness at 27/13.5 energy. Normal toggle
   works after release for both light types.

### Strict and Easy attempts

1. **Arm/save/quit/resume:** only confirmed manual slots in that attempt load.
1. **Strict death/reset/restart:** Continue/Load stays locked; resolved
   system/profile loads remain available.
1. **In-memory retry:** native game over is requested; recognized movement
   and firing stay blocked.
1. **Easy preflight:** weapons, attachments, rounds and keys round-trip before
   activation without removing inventory.
1. **Supported lethal hit/forceDead:** one custom defeat prompt and cache at
   the death position; no duplicate transfer.
1. **F6 Continue:** same-area calm point, 50% HP and unchanged mod resources
   in the current world, without native save loading.
1. **Return/F7:** same player/area, within 2 m, full metadata preserved;
   inventory overflow remains in the cache.
1. **Further deaths/Lua reset:** earlier unclaimed caches remain; interrupted
   transactions reconcile once.
1. **Execution/fall/cutscene death:** record guard bypass; do not assume Easy
   can Continue after every native death.
1. **Quit after Easy Continue:** only a subsequent successful manual save
   establishes a valid resume slot.
1. **Cancel/start New Game:** cancel preserves the lock; actual setup resets
   the attempt and rejects earlier attempts' slots.

### Saving and campaign transitions

1. **Success/quota/cooldown:** native success counts once; rejected attempts
   do not count as successful saves.
1. **Forced spoiled ink in test config:** one ribbon lost, write denied,
   no refund, existing save still readable.
1. **Autosave/chapter/checkpoint:** gameplay writes denied; examine native
   retries and transition behavior.
1. **Profile/settings:** writes allowed without consuming manual quota.
