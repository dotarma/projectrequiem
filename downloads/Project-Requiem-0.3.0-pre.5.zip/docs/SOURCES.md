# Sources and licensing

This page records the API references and licenses used by Project Requiem
**0.3.0-pre.5**. A matching API signature establishes compatibility with a
captured method, not correct behavior in every native gameplay path.

## Captured game metadata

Game-specific method signatures were checked against read-only reflection
from the user's Resident Evil Requiem **TDB83** installation, captured on
14 October 2026. The recorded framework build was dated 26 April 2026, with
commit:

```text
c4b1314820d20255febf7834903e8cedb669b49c
```

The installer retains the existing REFramework DLL. Reflection dumps and
reference repositories are development inputs and do not ship in the ZIP.
No fixed game memory offsets are used.

## Official REFramework references

- [REFramework source][framework] provides the framework implementation.
- The [SDK API][sdk] covers hooks, native fields, allocation and the primary
  camera. Temporary projectile rotation and One Life translation arguments
  use this API.
- [Hook-local storage][thread] isolates recursive and threaded hook calls.
- [Type reflection][types] supports exact method signatures and inherited
  fields. Uncaptured request-direction fields and archive-state getters
  are accepted only after runtime name/type checks.
- [Application callbacks][callbacks] supply gameplay and render timing.
- [Quaternion][quaternion] documents the constructor order `(w, x, y, z)`.
- [Managed objects][objects], [fields][fields] and [arrays][arrays] support
  the owned item-data codec used by One Life (Easy).
- [Draw][draw] provides the HUD, panic overlay and death-cache markers.
- [ImGui][imgui] provides controls and font loading. Its combo binding
  returns a key from the Lua options table; the language list uses 1/2.
- The [combo implementation][combo] confirms table-key selection and the
  fallback to the first key for an unavailable selection.
- [JSON persistence][json] documents configuration and ledger writes.

These references explain API contracts. Automated mocks based on them do
not establish native UI, camera, inventory or save-flow verification.

## Community API references

### Namsku's RE Engine trainer

The [trainer repository][trainer] supplies additional references for
infinity flags, rank factors, weapon data and native motion-layer speed.
The RE9 implementation is in `re9/requiem_trainer/features.lua`.

### RE9 Randomiser

[KyroGeorge2's randomiser][randomiser] identifies healing item IDs and
illustrates why general inventory merge hooks would also affect item-box
transfers. Project Requiem limits scarcity to recognized world objects.

### RELit

[originalnicodr's RELit][relit] provides renderer enable/intensity API
references. Project Requiem's current depleted-light path uses reversible
enable/visibility flags and leaves intensity unchanged.

The Lua algorithms are written for this mod. Names, signatures and item
IDs are used for API interaction; external repositories are not bundled.

## Documentation style

The documentation follows the user-requested [Markdown skill][skill],
version 1.2.1. The project lint configuration checks current English and
Vietnamese documents with markdownlint. Archived release documentation
retains its historical form.

## Bundled font

Noto Sans Regular is distributed unchanged from the [Noto font repository][noto]
under the
[SIL Open Font License 1.1](../reframework/fonts/project_requiem/OFL.txt).
The original copyright and license notice ship with the font. See the
[upstream font license][font-license].

Font SHA-256:

```text
b85c38ecea8a7cfb39c24e395a4007474fa5a4fc864f6ee33309eb4948d232d5
```

## Mod license and distribution

The [MIT license](../LICENSE.md#project-requiem-code) covers Project Requiem
code. The consolidated [LICENSE.md](../LICENSE.md) also contains notices
for the bundled font, separately supplied runtime, development tools and
reference sources, with installed development package inventories.

Components retain their own licenses. Reference sources without a located
license are identified explicitly. No Capcom executable, DLL or game
assets are distributed.

[framework]: https://github.com/praydog/REFramework
[sdk]: https://cursey.github.io/reframework-book/api/sdk.html
[thread]: https://cursey.github.io/reframework-book/api/thread.html
[types]:
  https://cursey.github.io/reframework-book/api/types/RETypeDefinition.html
[callbacks]: https://cursey.github.io/reframework-book/api/re.html
[quaternion]:
  https://cursey.github.io/reframework-book/api/types/Quaternion.html
[objects]:
  https://cursey.github.io/reframework-book/api/types/REManagedObject.html
[fields]: https://cursey.github.io/reframework-book/api/types/REField.html
[arrays]: https://cursey.github.io/reframework-book/api/types/SystemArray.html
[draw]: https://cursey.github.io/reframework-book/api/draw.html
[imgui]: https://cursey.github.io/reframework-book/api/imgui.html
[combo]:
  https://github.com/praydog/REFramework/blob/master/src/mods/bindings/ImGui.cpp
[json]: https://cursey.github.io/reframework-book/api/json.html
[trainer]: https://github.com/Namsku/re-engine-trainer
[randomiser]: https://github.com/KyroGeorge2/RE9-Randomiser
[relit]: https://github.com/originalnicodr/RELit
[skill]:
  https://github.com/RedondoK/claude-md-skill/blob/main/markdown/SKILL.md
[noto]: https://github.com/notofonts/noto-fonts
[font-license]: https://github.com/notofonts/noto-fonts/blob/main/LICENSE
