# Features and default balance

Project Requiem **0.3.0-pre.5** adds a hardcore survival preset to Resident
Evil Requiem PC through REFramework. English is the default; Vietnamese is
selectable. This document describes the shipped values and fixed rules.
The release remains experimental. See [verification](TESTING.md) for the
difference between automated checks and observed behavior in the game.

## Combat and finite bonuses

| Mechanic | Default factor |
| --- | --- |
| Enemy effective toughness | 1.80 |
| Incoming player damage | 1.45 |
| Player weapon damage | 0.70 |
| Enemy movement speed | 1.10 |
| Enemy stagger/wince | 0.65 |
| Minimum firing interval | 1.35 |
| Reload animation duration | 1.50 |

Toughness divides damage into registered enemy HitPoint objects. Combined
with weapon damage, enemies receive about **38.9%** of native damage before
integer rounding. It does not rewrite maximum HP or boss phase thresholds.
Melee and environmental damage using the same HP function are also affected.
The mod does not add AI or enemy spawns.

Speed and stagger use experimental rank getters that may be inlined or
bypassed. A call counter does not prove a visible effect on every enemy.
Firing intervals use a 0.25-second base if native weapon data is unreadable.
Reload scaling preserves native animation events and avoids compounding
the factor each frame.

While enabled, the mod forces off built-in infinite gun/rocket ammunition
and the shared infinite axe/knife durability bonus. It also clears equipped
loader panels' applicable infinite/zero-cost flags. Getter overrides and
boolean-field enforcement are combined. External trainers or conflicting
mods can bypass these paths.

## Healing and world scarcity

| Resource rule | Default |
| --- | --- |
| Recognized world healing pickups retained | About 40% |
| Item healing retained at Stress 0 | 45% |
| Item healing retained at Stress 100 | 33.75% |
| Recognized world ink ribbons retained | About 45% |

Keep/hide decisions are stable for the same seed, run ID, item and identified
location. Revisiting does not reroll them. These percentages describe many
locations, not a guaranteed fraction in each room.

Scarcity applies to recognized world pickups, not inventory transfers,
crafting, shops or inventory restoration. Unknown IDs, items without stable
location identity, and key/story items remain available. Nested recovery
calls are scaled once; healing modifiers do not lower maximum HP.

## Stress Meter and nearby threats

Stress ranges from **0 to 100** and worsens survival and weapon handling.

| Source | Default gain |
| --- | --- |
| Living, present enemy within 12 m | 1.8/second |
| Player below 30% HP | 0.9/second |
| Nearby threat with recognized player light off | Another 0.35/second |
| Taking damage | 8 plus HP-loss contribution |
| Registered physical shot | 0.7 |
| No continuing source | Recover 0.65/second |

Damage adds up to another 15 Stress according to the fraction of maximum HP
lost. Continuing source types add together; multiple nearby enemies do not
multiply the proximity gain. The light condition tests whether the
recognized light is on; it does not measure environmental darkness.

Threat scans combine and deduplicate enemy/context lists, preferring current
rendered transforms. A living, physically present suspended Licker can count
before waking or attacking. Corpses, inactive objects, despawned contexts
without an object and unreadable positions are excluded. Scans start with a
valid player and repeat about every 0.25 seconds. The radius is fixed at 12 m.

| Effect | Stress 0 | Stress 100 |
| --- | --- | --- |
| Incoming damage factor | 1.45 | 1.6675 |
| Item healing retained | 45% | 33.75% |
| Minimum firing-interval factor | 1.35 | 1.755 |
| Reload-duration factor | 1.50 | 1.875 |
| Reticle recovery multiplier | 1.00 | 0.45 |
| Jam chance at maximum heat | 8%/shot | 16%/shot |
| Jam-clearing duration | 3 seconds | 4.5 seconds |

Values interpolate continuously. HUD colors change at Stress 45 and 75.
The reticle-recovery method may be unused/inlined; panic has additional
enforcement paths.

## Panic at Stress 100

Panic starts at **100** and lasts until Stress reaches **90 or less**. It
applies to the recognized active Grace or Leon character. Kind IDs provide
a fallback when native character flags are unavailable.

- Reticle fitting is cleared after native updates, with its cached fit point
  driven to the weapon's minimum.
- A compatible reflected projectile direction receives a **2.5-degree**
  deviation cone while preserving its length. Otherwise the final shell
  rotation receives roughly **2.5 degrees** of pitch/yaw deviation. Time and
  shot count vary direction; a creation scope avoids applying both paths to
  one shot. Unlike the old cached target, these paths do not depend on a
  target that shell creation can overwrite.
- Render-camera sway is bounded at **0.6 degrees pitch, 0.7 degrees yaw and
  1.5 degrees roll**. The original rotation is restored before gameplay
  simulation, on recovery and on disable/reset. It does not accumulate drift
  or replace a later engine rotation.
- Slow haze and breathing tunnel vision remain visible when the HUD is
  hidden. They are not a blur filter or an exact copy of Leon's postprocess.
- Supplementary fear/sick hooks target only the current player. Sick-state
  enforcement requires that character's valid configuration; Leon's
  animations and configuration are not transplanted onto Grace.

Panic persists with Stress, suspends during pause/inactive gameplay and
releases on recovery or mod disable. Aim updates do not consume jam/ink RNG.
Every weapon's actual trajectory and character-specific native visuals
still need native verification.

## Heat and weapon jams

Each registered shot adds **0.18 heat**, capped at 1. Heat cools by
**0.14/second** of live gameplay. No jam roll occurs below **0.40 heat**.
At or above that threshold:

```text
jam chance = 0.16 * heat * (0.5 + 0.5 * Stress / 100)
```

One roll follows each registered shot. Holding input or per-frame updates
cannot reroll it. A jam gates fire requests, native fire eligibility,
projectile creation and further ammunition consumption. Deferred callbacks
do not count phantom shots while jammed.

Use the game's Reload action, or **R** as a keyboard fallback, to clear the
jam. Clearing takes **3-4.5 live seconds**, even with a full magazine, and
leaves heat at 0.20. Switching weapons does not clear a jam.

Heat/jams belong to individual player/weapon objects for the Lua session.
Resetting scripts, restarting or loading that discards the player context
can clear them. Total shots/jams persist; individual hot/jammed objects do
not.

## Stamina and exhaustion

The recognized active Grace or Leon player has a **0-100 Stamina Meter**.

| Rule | Default |
| --- | --- |
| Capacity and starting stamina | 100 |
| Sprint drain | 16/second |
| Uninterrupted sprint from full | 6.25 seconds |
| Recovery delay after sprint | 2 live seconds |
| Resting recovery | 12/second |
| Moving recovery | 6/second |
| Exhausted walking playback | 60% |
| Exhausted run-transition playback | 40% |
| Exhaustion release | 25 stamina |

Zero stamina latches exhaustion and blocks sprint. Holding sprint while
exhausted does not prevent recovery; normal walking costs no stamina.
After native input, the mod cancels sprint and requests walking. It also
scales the active locomotion layer without compounding, then restores its
original speed on release.

Terrain actions, damage reactions, riding and reloads are excluded. Movement
speed is restored before the separate reload modifier applies. Global time
and camera input are unchanged. Stamina, exhaustion and recovery delay
persist using the same live-time guards as Stress and lights.

FPS/TPS, stairs, crouching, both characters and engine paths bypassing the
identified movement/input methods still require native validation. Playback
factors are not a measurement of actual native movement velocity.

## One Life (Strict)

**Enable One Life** is optional and **off by default**. It can be disabled
while alive. Death permanently locks the attempt. Enabling it in an existing
campaign trusts no old resume slots: make a successful new manual save
before quitting to resume that living attempt. Quota, cooldown and ink rules
still apply.

- Native current-player death callbacks and a dead/zero-HP fallback persist
  death immediately. Enemy deaths do not count.
- After death, gameplay Continue/Load requests are denied, including category
  and final segment/slot overloads. While alive, only manual slots confirmed
  by successful saves in this attempt can resume. Unknown slots, autosaves
  and earlier attempts' slots are denied. Resolved system/profile loads are
  allowed.
- The run-ended notice survives hidden HUD, general mod disable, script reset
  and restart. General disable does not bypass an armed One Life attempt.
- If an in-memory checkpoint respawns the player, the mod requests native
  game over and guards recognized movement/fire paths. It does not delete
  checkpoints or replace the native game-over screen.
- Choose native **New Game** from the title screen to start another attempt.
  Actual setup resets resources, Stress, stamina, quota/cooldown, ink/RNG
  history and trusted slots, and increments the attempt. Opening/cancelling
  New Game does not reset it. The selected One Life mode carries forward.

Native saves are not deleted or corrupted. Previous-attempt slots become
usable only if successfully overwritten in the new attempt. Local config,
ledger edits, backups or removing the mod can bypass rules; there is no
leaderboard or tamper protection. Death, New Game, checkpoint paths and
native value-type slot identity have automated coverage, not play-testing.

## One Life (Easy)

Choose **Enable One Life (Easy)** during live gameplay with a valid calm
Continue point. Before activation, the update thread deploys every current
inventory entry's native `ItemAmountData`, encodes/decodes it and compares
the round trip. Unsupported data refuses activation. The check repeats at
death because inventory may have changed.

| Rule | Behavior |
| --- | --- |
| Continue action | F6 or menu's Continue (Easy) |
| Continue HP | 50% of current maximum; at least 1 |
| Recover action | F7 or menu button |
| Recovery range | Within 2 m; same player and area |
| Outstanding cache limit | 128 |
| Full inventory | Unclaimed entries stay in cache |

This is **soft death**, not native game-over Continue. Supported paths are
lethal `addDamageHitPoint` after incoming scaling and current-player
`forceDead`. Before irreversible death, the mod blocks movement, firing and
further HP damage. Continue warps to the last calm locomotion point for the
same character/native resume-area ID and resets HP through captured APIs.

The in-memory world continues without loading a save or rewinding progress.
It can keep advancing while the defeat prompt is open. Stress, stamina,
lights, elapsed time and save quota/cooldown keep their current values.
Continue makes no manual-save, load or autosave request.

All carried panels and archived inventory items, including keys, move to a
persistent cache at the recorded death position. A world-space marker,
distance label and recovery action represent the cache; no loose item
models are spawned. Weapon data includes loaded rounds and attachments;
attached panels are not duplicated as loose items. Item boxes, file
inventories and separate wallet currency are outside the carried inventory
returned by `GuiUtil.getInventory`. Later deaths retain unclaimed caches;
completed caches are pruned.

Transfers are journaled before removal. Native inventory snapshots permit
rollback if removal or persistence fails. Pickup checks capacity, journals
the claim and verifies the full stock increase before claiming the entry.
Unsupported, cyclic, oversized or ambiguous interrupted data is rejected.
If rollback fails, the transaction/error remains for reconciliation. This
does not provide crash-proof atomicity between native memory and JSON files.

Continue is **session-based**: the ledger cannot preserve the entire live
world after quitting. Death revokes earlier trusted resume slots. After
Continue, make a successful manual save under normal rules before quitting
to resume later. Pending defeats/cache journals survive Lua resets but do
not replace game saves. New Game resets the attempt and cache list. Pending
defeat or outstanding loot prevents menu mode changes/disabling One Life.

No complete native inventory/serialization/warp/recovery cycle has been
observed. Scripted executions, cutscenes, falls or deaths bypassing the
guards may cause irreversible death and end the attempt. Calm points are
not engine checkpoints or validated navmesh locations. One-way routes,
streaming changes, character switches and story progress may prevent cache
recovery. Easy remains experimental.

## Flashlight and lighter limits

| Source | Capacity | Unlock after depletion |
| --- | --- | --- |
| Flashlight / BodyLight | 180 seconds | 27 energy-seconds |
| Lighter | 90 seconds | 13.5 energy-seconds |

Separate pools recover **0.15 energy-seconds per live second** while off,
up to capacity. Unlock requires **15%** of capacity: from empty, about
**180 live seconds** for the flashlight or **90** for the lighter.

At zero, the mod blocks use and overrides the player's emitter enable and
visibility flags after native updates. It avoids external off requests and
intensity changes that could hold a recovered light off. Overrides preserve
fresh controller-written state and restore it on release/disable. Normal
player toggling resumes afterward.

While depleted, the HUD shows energy against the unlock threshold and
announces readiness. A small positive value alone does not unlock the light.
The recharge latch survives reset/restart. Legacy ledgers below the threshold
migrate as recharging without resetting energy.

There are no new battery/fuel items or animations, and scene lighting is
unchanged. Automated emitter tests do not establish visual extinction for
every native light variant.

## Live inventory and item box

Recognized Grace/Leon inventory, item-box and inventory crafting, tab,
background and description pause requests are disabled. Enemies and time
can continue while managing items. Esc pause, loading and cutscenes retain
native behavior. Special subdialogs may use other pause paths.

## Autosaves, manual saves and spoiled ink

**Automatic gameplay saving is forbidden while the mod is enabled.** There
is no separate autosave-enable setting. Auto/custom gameplay categories
6-9 are denied, with a segment/slot guard. A resolved Auto slot is blocked
even inside a manual call. Unclassified requests without valid category
scope are denied.

System/profile settings writes remain available without consuming quota.
Existing autosaves remain on disk. In-memory checkpoints are not removed;
chapter transitions and checkpoint retry behavior are not fully verified.

| Manual-save rule | Default |
| --- | --- |
| Successful saves per run ID | At most 12 |
| Cooldown after success | 900 live seconds / 15 minutes |
| Fresh run's first save | No initial cooldown |
| Spoiled ink chance | 25% per eligible ribbon transaction |

Manual saves must use the typewriter interface and pass all rules. Where
native saving needs a ribbon, a real finite ribbon is required; an infinite
ribbon bonus cannot replace it. The first save still needs other conditions.

**Spoiled ink consumes one ribbon, refuses the write and prevents refund.**
The HUD reports failure; the game may show its own save-error dialog. The
transaction result is remembered so repeated checks cannot reroll it.
Quota/cooldown rejection retains the native refund path. Failed saves do
not consume successful-save quota or start a success cooldown; only the
native successful-write callback increments quota.

Spoilage applies where the game already requires ribbons, usually Grace's
sections. The mod does not add a ribbon requirement elsewhere or corrupt
or delete existing saves.

## Time, HUD and language

Resources, cooldowns, heat and Stress use identified live gameplay time.
Timers stop for reported pause/loading, invalid/dead/suspended players,
cutscene invalidation, unfocus/minimize where detectable, and stalls above
0.5 seconds. Successfully unpaused inventory continues those timers.

The HUD at `(28, 80)` shows Stress, stamina/exhaustion, One Life status,
light energy, save count, finite/autosave restrictions, jam/panic notices and
the nearest recognized threat in range. Hiding it leaves gameplay and panic
visuals active; a dead One Life notice stays visible.

Choose **English / Tiếng Việt** in the menu. Both languages cover HUD,
controls and notifications; pending notifications use the current language.
Noto Sans applies only to this mod's UI. Engine IDs, JSON keys and diagnostic
events retain stable English identifiers.

Pre.5 corrects the combo's one-based Lua keys: English is 1, Vietnamese is 2.
Selection saves immediately and reloads without resetting the run. Switching
and persistence have automated coverage; native UI verification is pending.

## Persistence and diagnostics

Configuration and run ledgers live in `reframework/data/project_requiem/`.
The ledger stores Stress/panic, stamina/exhaustion/recovery delay, lights,
elapsed time, save quota/cooldown, RNG/ink decisions, One Life
activation/death/attempt/trusted slots and total counters. It flushes about
every 15 gameplay seconds and on relevant save/config/reset/report
callbacks. One Life death, mode changes, New Game and confirmed One Life
saves flush immediately. Sidecar writes are not gameplay autosaves. Crashes
or failed disk writes can lose state.

Loading earlier native progress does not refund a `run_id` ledger. New Game
starts a fresh attempt in that ID. Reports export after 120 frames, every
1,800 frames or through the menu. They include:

- Hook calls/errors, applied events and resource/timer state.
- Stamina/exhaustion, movement and applied/base locomotion speed.
- One Life death, attempt, trusted slots and Easy/cache state.
- Weapon/jam/panic, character eligibility, camera sway and reflected
  projectile-request fields.
- Light control/renderer writes, bonus flags and blocked save categories.
- Threat sources/counts/distances and selected language.

Reflection checks signatures without fixed memory offsets. The installer
backs up owned files, migrates old names and preserves unrelated mods.
Removal retains data and modified files. Code uses MIT; the bundled font
has its own OFL license.

See [configuration](CONFIGURATION.md), [troubleshooting](TROUBLESHOOTING.md)
and [sources](SOURCES.md).
