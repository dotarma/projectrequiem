# Configuration

Edit `reframework/data/project_requiem/config.json` with the game closed.
The mod ignores unknown keys, checks types, clamps valid numbers to the
ranges below and replaces invalid values with defaults. Seed and save-count
values are rounded down to integers.

## Interface and run identity

| Key | Default | Accepted value |
| --- | --- | --- |
| `enabled` | `true` | Boolean |
| `language` | `"en"` | `"en"` or `"vi"` |
| `run_id` | `"run-1"` | Up to 48 letters/digits/underscores/hyphens |
| `seed` | `9142026` | Integer 1-2147483646 |
| `hud` | `true` | Boolean |
| `hud_x` | `28` | 0-10000 |
| `hud_y` | `80` | 0-10000 |

- `enabled` controls ordinary gameplay modifiers. Armed One Life death/load
  guards remain active when it is false.
- `language` selects English or Vietnamese for the mod, not the game. English
  is the fresh/legacy fallback. Use the live menu to switch and save it
  immediately. The brand remains Project Requiem in both languages.
- `run_id` identifies an independent ledger. Use separate IDs for separate
  campaigns; loading an older native slot does not refund the current ledger.
- `seed` controls the isolated jam/ink RNG and stable location decisions.
- `hud` hides status information without disabling gameplay or panic visuals.
  A dead One Life notice stays visible. `hud_x`/`hud_y` set screen coordinates.

## Enemies, weapons and healing

| Key | Default | Range |
| --- | --- | --- |
| `enemy_toughness` | `1.8` | 1-6 |
| `enemy_attack` | `1.45` | 1-5 |
| `enemy_speed` | `1.1` | 1-1.5 |
| `enemy_stagger` | `0.65` | 0.1-1 |
| `weapon_damage` | `0.7` | 0.1-1 |
| `fire_delay` | `1.35` | 1-4 |
| `reload_duration` | `1.5` | 1-4 |
| `heal_effect` | `0.45` | 0.1-1 |
| `healing_keep_chance` | `0.4` | 0-1 |

- `enemy_toughness` divides damage into registered enemies, rather than
  changing maximum HP. `weapon_damage` multiplies the same incoming damage.
  Together the defaults retain about 38.9% before rounding.
- `enemy_attack` multiplies damage received by the player before Stress.
- `enemy_speed` and `enemy_stagger` use experimental rank movement/wince
  getters. Native calls or visible effects are not guaranteed for every enemy.
- `fire_delay` multiplies the minimum shot interval; `reload_duration`
  multiplies reload animation duration. Stress can increase both further.
- `heal_effect` is the fraction of item healing retained before Stress.
- `healing_keep_chance` is the retained fraction of recognized world healing
  pickups. It does not filter inventory transfers or key/story items.

## Stress

| Key | Default | Range |
| --- | --- | --- |
| `stress_gain_near` | `1.8` | 0-10 |
| `stress_gain_low_hp` | `0.9` | 0-10 |
| `stress_gain_dark` | `0.35` | 0-5 |
| `stress_decay` | `0.65` | 0-5 |
| `stress_per_hit` | `8` | 0-50 |
| `stress_per_shot` | `0.7` | 0-10 |

- `stress_gain_near` adds Stress per second when a living present threat is
  within 12 m. It does not multiply by the number of nearby enemies.
- `stress_gain_low_hp` adds Stress per second below 30% player HP.
- `stress_gain_dark` adds Stress per second when a threat is near and the
  recognized player light is off; it does not measure ambient brightness.
- `stress_decay` recovers Stress per second without a continuing source.
- `stress_per_hit` adds a base increase before the HP-loss fraction term,
  which contributes up to another 15.
- `stress_per_shot` adds Stress per registered physical shot.

## Stamina and One Life

| Key | Default | Accepted value |
| --- | --- | --- |
| `stamina_drain` | `16` | 1-100 |
| `stamina_recovery` | `12` | 1-100 |
| `stamina_recovery_delay` | `2` | 0-30 |
| `stamina_recover_threshold` | `25` | 1-100 |
| `stamina_exhausted_walk` | `0.6` | 0.1-1 |
| `stamina_exhausted_run` | `0.4` | 0.1-1 |
| `one_life` | `false` | Boolean |
| `one_life_mode` | `"strict"` | `"strict"` or `"easy"` |

- `stamina_drain` spends stamina per live sprint second.
- `stamina_recovery` restores stamina per live second at rest. Movement
  restores half that rate.
- `stamina_recovery_delay` delays recovery after the last sprint, in live
  seconds. Holding sprint while exhausted does not prevent recovery.
- `stamina_recover_threshold` releases exhaustion after reaching zero.
- `stamina_exhausted_walk` and `stamina_exhausted_run` scale walking and
  run-transition locomotion playback. They do not set global time or camera
  input and are not measured native velocity ratios.
- `one_life` opts in; `one_life_mode` selects the policy when armed. Prefer
  menu actions, which validate changes and persist immediately.

Stamina capacity is fixed at 100. Empty stamina blocks sprint until the
recovery threshold. Timers advance only in recognized live gameplay.

### Strict mode and trusted slots

Activation/death also live in the ledger. Editing `one_life` or `enabled`
to false does not revive a dead attempt. Disable through the menu while
alive, or start native New Game after death. Newly arming an existing
campaign clears trusted slots: make a successful new manual save before
quitting. Only slots saved in the current attempt are trusted; old and
unclassified gameplay loads are denied.

### Easy mode

Armed legacy ledgers without a mode remain Strict. Editing config alone
does not convert an armed Strict ledger. Choose **Enable One Life (Easy)**
in a calm live area to run inventory preflight and select Easy.

Easy uses fixed **F6/F7** actions, **50%** Continue HP, a **2 m** recovery
radius and at most **128** outstanding caches. Death revokes earlier resume
slots; save successfully after Continue before quitting to resume later.
Pending defeat and outstanding loot prevent menu mode changes. See
[Easy behavior and limits](FEATURES.md#one-life-easy).

## Jams and lights

| Key | Default | Range |
| --- | --- | --- |
| `jam_heat_per_shot` | `0.18` | 0-1 |
| `jam_cool_per_second` | `0.14` | 0.01-2 |
| `jam_min_heat` | `0.4` | 0-1 |
| `jam_max_chance` | `0.16` | 0-0.75 |
| `jam_clear_seconds` | `3` | 0.5-30 |
| `flashlight_seconds` | `180` | 10-3600 |
| `lighter_seconds` | `90` | 10-3600 |
| `light_recharge_per_second` | `0.15` | 0-1 |

- `jam_heat_per_shot` adds heat per registered shot, capped at 1.
- `jam_cool_per_second` removes heat per live second.
- `jam_min_heat` is the minimum heat for a jam roll.
- `jam_max_chance` is the probability factor at maximum heat and Stress.
  Actual chance is this value times heat times `(0.5 + 0.5 * Stress / 100)`.
- `jam_clear_seconds` is the base clearing duration before Stress scaling.
- `flashlight_seconds` and `lighter_seconds` set separate energy capacities.
  The flashlight pool also covers BodyLight.
- `light_recharge_per_second` restores energy-seconds per live second while
  the source is off. Setting it to zero prevents recharge.

After depletion, each light must recover 15% of its configured capacity to
unlock. At defaults, this means 27/13.5 energy-seconds, taking 180/90 live
seconds from empty. A persisted recharge latch preserves that restriction.

## Saving and ink

| Key | Default | Range |
| --- | --- | --- |
| `max_manual_saves` | `12` | Integer 1-100 |
| `save_cooldown_seconds` | `900` | 0-7200 |
| `ink_failure_chance` | `0.25` | 0-1 |
| `ink_keep_chance` | `0.45` | 0-1 |

- `max_manual_saves` limits successful manual saves per run.
- `save_cooldown_seconds` sets live waiting time after a successful save.
- `ink_failure_chance` rolls once per eligible consumed-ribbon transaction.
  Spoiled ink consumes one ribbon, refuses the write and prevents refund.
- `ink_keep_chance` retains this fraction of recognized world ribbons.

Spoilage applies only where native saving already needs a ribbon. Repeated
checks do not reroll a transaction. Quota/cooldown rejection keeps the normal
refund path; failed writes do not count as successful saves.

## Fixed rules

The following are not separate JSON settings:

- 12 m threat radius and Stress 100/90 panic thresholds.
- Approximately 2.5-degree panic deviation.
- Stamina capacity 100 and moving recovery factor 0.5.
- 15% light re-enable threshold.
- Built-in finite-ammunition/durability enforcement.
- Gameplay-autosave ban while the mod is enabled.

General disable stops ordinary gameplay modifiers. Armed One Life death/load
guards continue to protect the attempt.

## Run ledgers

`<run_id>.json` stores persistent mod state. Native New Game setup resets
the current ID for a fresh attempt, including trusted resume slots. Use a
different ID to keep a separate campaign ledger. Ordinary old-slot loads
retain quota, energy, Stress and stamina history; One Life additionally
requires a confirmed current-attempt slot. Individual weapon heat/jams are
session-only.

Framework callbacks can overwrite edits made while the game is running.
Keep recovery/cache journals intact when diagnosing errors. Editing or
deleting ledgers can reset local rules; there is no tamper protection.
