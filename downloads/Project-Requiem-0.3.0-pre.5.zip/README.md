# Project Requiem

Project Requiem is a survival difficulty mod for Resident Evil Requiem PC,
powered by REFramework. Current release: **0.3.0-pre.5**.

English is the default interface and documentation language.
[Tiếng Việt](docs/vi/README.md) is available with a bundled Vietnamese font.

## What the mod adds

- Tougher enemies, stronger incoming damage and weaker weapons.
- Slower firing and reloading, with heat-based weapon jams.
- Finite ammunition and knife/axe durability for built-in infinite bonuses.
- Fewer healing items and ink ribbons, with weaker item healing.
- Stress from nearby threats, low health, damage and gunfire.
- Panic at Stress 100: unsteady aim, projectile deviation, camera sway and
  a haze/tunnel-vision overlay.
- Stamina that drains while sprinting; exhaustion forces slower movement.
- Optional One Life (Strict) and One Life (Easy).
- Limited flashlight/lighter energy with gradual recharge while off.
- Inventory and item-box menus that keep gameplay running.
- No gameplay autosaves. Manual saves have a quota, cooldown and a 25%
  spoiled-ink chance where the game requires ribbons.

The preset multiplies the selected game difficulty. It is designed for a
new Insanity/Madness run and does not change the native difficulty setting.
See [features and default values](docs/FEATURES.md).

## Release status

This is a pre-release. **121 Lua checks and nine installer scenarios pass**,
but they do not establish correct native visuals, every weapon trajectory
or a complete campaign. The latest gameplay and language-selector fixes
have not been re-tested directly in the game.

One Life (Easy) is experimental. Its inventory transfer, revival and item
recovery cycle still needs native verification. Read the
[evidence and limits](docs/TESTING.md) before adopting the mod, and keep a
backup of the game saves you intend to use.

## Requirements

- Resident Evil Requiem PC, with `re9.exe` in the game folder.
- An RE9-compatible [official REFramework build][reframework].
- REFramework Lua SDK and hook-local thread storage support.

The captured compatibility baseline is **TDB83**. REFramework's DLL and
game assets are not included. Loose File Loader is not required.

## Install

1. Close the game and install REFramework if needed.
1. Extract `Project-Requiem-0.3.0-pre.5.zip` into a working folder.
1. Open PowerShell in that folder and run the command below. Replace the
   game path if yours differs.

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\Install.ps1 `
     -GamePath 'C:\Games\Resident Evil Requiem'
   ```

1. Start the game and open **Insert → Script Generated UI → Project Requiem**.
1. Choose the native difficulty for your run. One Life is optional and off
   by default.

Use the installer for upgrades. It backs up replaced mod files, preserves
settings and run ledgers, and migrates recognized older namespaces.
See [installation, upgrades and removal](docs/INSTALLATION.md).

## Language and settings

Choose **Language → English / Tiếng Việt** in the mod menu. The interface
updates immediately and saves the choice. Version pre.5 fixes the language
selector; the saved preference survives script reloads.

Configuration lives in `reframework/data/project_requiem/config.json`.
Close the game before editing it manually. See the
[configuration reference](docs/CONFIGURATION.md).

Each `run_id` has a separate mod ledger. Loading an earlier native save
does not refund the current run's resources or save quota. Native
**New Game** starts a fresh attempt in that ledger.

## One Life modes

| Mode | After a supported death |
| --- | --- |
| Strict | Continue/Load stays locked until New Game. |
| Easy | F6 continues; carried items stay at the death site. |

Strict permits resume only from successful manual saves made in the
current attempt after activation. Native save files are retained.

Easy returns you to the last recorded calm point in the same player/area
with 50% HP, without loading a save or rewinding the world. Return within
2 m of the marked death cache and press **F7** to recover items. Overflow
stays in the cache. After Continue, make a successful manual save before
quitting if you need resume access. See
[Easy rules](docs/FEATURES.md#one-life-easy).

## Documentation

- [Features and balance](docs/FEATURES.md)
- [Installation, upgrades and removal](docs/INSTALLATION.md)
- [Configuration](docs/CONFIGURATION.md)
- [Troubleshooting](docs/TROUBLESHOOTING.md)
- [Testing and native limits](docs/TESTING.md)
- [Sources and licensing](docs/SOURCES.md)
- [Changelog](CHANGELOG.md)
- [Tài liệu tiếng Việt](docs/vi/README.md)

## Development and licensing

Lua source is in `reframework/autorun/project_requiem/`, with
`reframework/autorun/project_requiem.lua` as the entrypoint. See
[source checks](docs/TESTING.md#running-the-source-checks) for validation
and packaging commands.

Mod code uses the [MIT license](LICENSE.md#project-requiem-code).
[LICENSE.md](LICENSE.md) also records third-party notices and development
tool licenses. Bundled Noto Sans uses the
[SIL Open Font License 1.1](reframework/fonts/project_requiem/OFL.txt).
Project Requiem is an unofficial mod; no Capcom executable or assets ship
in the package.

[reframework]: https://github.com/praydog/REFramework-nightly/releases
