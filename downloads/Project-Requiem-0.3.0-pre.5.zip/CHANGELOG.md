# Changelog

## 0.3.0-pre.5 — Language selector hotfix

- Fix English/Vietnamese switching by using the one-based keys of the Lua
  options table returned by REFramework's combo binding. Ignore unexpected
  selection keys; English remains the default.
- Save the choice immediately and restore it on script reload without
  resetting resources, death status or the One Life attempt.
- Correct the UI mock to reproduce table-key selection and first-key fallback.
  Add a saved-Vietnamese reload regression: 121 Lua checks and nine installer
  scenarios pass. Native UI verification remains pending.

## 0.3.0-pre.4 — Exhaustion, panic and light recovery fixes

- Replace ineffective exhaustion translation scaling with post-input sprint
  cancellation, forced walk requests and reversible locomotion playback
  scaling. Restore locomotion speed before reload scaling.
- Recognize the active Grace/Leon kind IDs even when native character flags
  are absent. Add bounded camera sway and a stronger haze/tunnel overlay at
  Stress 100, independent of the native sick-state getters.
- Move physical panic deviation from the cached firing target to finalized
  projectile requests or shell rotations. Avoid double deviation and restore
  temporary argument buffers.
- Remove repeated external light-off requests and zero-intensity overrides
  that could leave lights locked or dark after recovery. Preserve
  controller-written renderer states for release.
- Persist each depleted-light recharge latch. Show current energy versus the
  15% unlock threshold and notify when switching on becomes available.
- Add regression checks for native sprint rewrites, reload transitions,
  recalculated shot targets, camera drift/restoration, Grace/Leon eligibility
  and repeated depletion/recharge cycles for both lights. These fixes are
  automated-tested; native gameplay verification remains pending.

## 0.3.0-pre.3 — One Life (Easy)

- Keep Strict One Life and add a separate **Enable One Life (Easy)** action
  with a current-inventory preflight on the game update thread.
- Intercept supported lethal HP hits and current-player `forceDead` calls.
  **F6 / Continue (Easy)** resumes the live world at the last calm point in
  the same player/area, with 50% HP and unchanged mod resources/quota, without
  loading a game save.
- Transfer carried panels and archive items to a positional, marked death
  cache. Use native deployed item data to preserve stock, loaded rounds and
  attachment fields; persist owned data trees without engine pointers.
- **F7 / Recover** within 2 m returns items using native inventory capacity
  checks. Keep overflow in the cache, avoid duplicating attached panels, and
  preserve items acquired after Continue.
- Journal transfers/pickups, roll back failed mutations where the engine
  permits, and reconcile interrupted operations. Block earlier manual-slot
  resume after an Easy death and mode changes with outstanding loot.
- Add English/Vietnamese controls, diagnostics and documentation. Native
  scripted deaths, serialization of every item, warp/animation behavior and
  full-campaign recovery remain unverified; this is an experimental
  pre-release.

## 0.3.0-pre.2 — Stamina and One Life

- Add a persistent 0–100 Stamina Meter for the active Grace/Leon player.
  Sprint drains 16/second; recovery waits 2 seconds, then restores 12/second
  at rest or 6 while moving.
- Empty stamina blocks sprint and reduces locomotion translation to 60%
  walking / 40% run transitions. Exhaustion remains until 25 stamina. Pauses,
  loading, cutscenes and long stalls keep the existing live-time guards.
- Add an English/Vietnamese **Enable One Life** menu button, off by default. A
  living attempt can opt out; a dead attempt cannot be revived through the
  button, general mod toggle, script reset or old save load.
- Persist death immediately. Gate gameplay loads by the current attempt's
  successful manual-save slots; preserve system/profile loads. Native New Game
  setup starts a fresh attempt and revokes previous-attempt resume slots.
- Guard movement, firing, saving and game-over requests for a locked in-memory
  respawn. Native save files are retained.
- Extend the HUD, configuration, reports, installer and English/Vietnamese
  documentation. New features remain unverified in native gameplay; keep
  pre-release status.

## 0.3.0-pre.1 — Project Requiem 0.3 pre-release

- Rename the product, entrypoint, Lua namespace, font/data folders, logs and
  release archive to **Project Requiem**.
- Add complete **English and Vietnamese** UI catalogs. English is the default
  for fresh/legacy configs without a language setting; menu selection updates
  the interface immediately and persists.
- Preserve Vietnamese diacritics with the bundled Noto Sans font. Keep engine
  IDs, config keys and diagnostic events stable.
- Add English-first README, installation/upgrade/removal, feature,
  configuration, troubleshooting, testing and source/license documentation.
  Keep Vietnamese documentation under `docs/vi/`.
- Upgrade from Khúc Cầu Hồn / Requiem and ULTRADEAD with ownership checks,
  relative-path backups, ledger migration and removal of recognized old
  entrypoints. Retain original legacy data and existing Project Requiem
  preferences.
- Add localization and entrypoint/UI migration checks alongside the existing
  survival rules/API tests. Build a release ZIP with file manifest and a
  separate SHA-256 checksum.
- Carry forward the 0.2.2 gameplay preset. No claim of new native or
  full-campaign validation is made; this release is a **pre-release**.

## Earlier releases

- **0.2.2:** accented Vietnamese HUD/menu/toasts and bundled font.
- **0.2.1:** expanded dormant/Licker threat scanning, Stress 100 panic, target
  deviation and visual/native-effect paths.
- **0.2.0:** layered jam gates, depleted-light emitter shutoff, finite
  knife/axe bonus enforcement and forbidden gameplay autosaves.
- **0.1.0:** initial survival rules, Stress, scarcity, finite resources and
  restricted manual saving, released as ULTRADEAD.
