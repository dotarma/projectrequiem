[CmdletBinding()]
param(
    [string]$GamePath = 'C:\Games\Resident Evil Requiem',
    [switch]$Uninstall,
    [switch]$AllowRunning
)
$ErrorActionPreference = 'Stop'
$gameRoot = (Resolve-Path -LiteralPath $GamePath).Path.TrimEnd('\')
if (-not (Test-Path -LiteralPath (Join-Path $gameRoot 're9.exe') -PathType Leaf)) {
    throw 'GamePath must point to the folder containing re9.exe.'
}
if ((Get-Process re9 -ErrorAction SilentlyContinue) -and -not $AllowRunning) {
    throw 'Close Resident Evil Requiem before running this installer.'
}
$sourceRoot = $PSScriptRoot
$modules = @('core.lua','sdk_util.lua','combat.lua','world.lua','saves.lua','locale.lua','survival.lua','loot_codec.lua','easy_life.lua')
$ownedFiles = @('reframework\autorun\project_requiem.lua')
foreach ($module in $modules) { $ownedFiles += 'reframework\autorun\project_requiem\' + $module }
$ownedFiles += @('reframework\fonts\project_requiem\NotoSans-Regular.ttf','reframework\fonts\project_requiem\OFL.txt')
$dataRoot = Join-Path $gameRoot 'reframework\data\project_requiem'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$backupRoot = Join-Path $dataRoot ('install-backups\' + $stamp)
$legacy = @(
    @{Name='khuc_cau_hon'; Marker='KHUC CAU HON / REQUIEM'; Fonts=$true},
    @{Name='ultradead'; Marker='ULTRADEAD: Beyond Insanity'; Fonts=$false}
)
function Get-GameTarget([string]$Relative) {
    $resolved = [System.IO.Path]::GetFullPath((Join-Path $gameRoot $Relative))
    if (-not $resolved.StartsWith($gameRoot + '\', [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Invalid destination outside the game folder: $Relative"
    }
    return $resolved
}
function Backup-OwnedFile([string]$Relative) {
    $target = Get-GameTarget $Relative
    if (Test-Path -LiteralPath $target -PathType Leaf) {
        $destination = Join-Path $backupRoot $Relative
        New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
        Copy-Item -LiteralPath $target -Destination $destination
    }
}
if ($Uninstall) {
    foreach ($relative in $ownedFiles) {
        $target = Get-GameTarget $relative
        if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { continue }
        $source = Join-Path $sourceRoot $relative
        if (-not (Test-Path -LiteralPath $source -PathType Leaf) -or
            (Get-FileHash -LiteralPath $target).Hash -ne (Get-FileHash -LiteralPath $source).Hash) {
            Write-Warning "Left modified or unverifiable file in place: $relative"
            continue
        }
        Remove-Item -LiteralPath $target
        Write-Host "Removed $relative"
    }
    Write-Host 'Project Requiem removed. Configuration and run ledgers were retained in reframework/data/project_requiem.'
    return
}

# Validate the complete package and the selected configuration before replacing anything.
foreach ($relative in $ownedFiles + @('reframework\data\project_requiem\config.json')) {
    if (-not (Test-Path -LiteralPath (Join-Path $sourceRoot $relative) -PathType Leaf)) {
        throw "Missing package file: $relative"
    }
    $null = Get-GameTarget $relative
}
$legacyFiles = @()
foreach ($old in $legacy) {
    $entryRelative = 'reframework\autorun\' + $old.Name + '.lua'
    $entry = Get-GameTarget $entryRelative
    if (-not (Test-Path -LiteralPath $entry -PathType Leaf)) { continue }
    if (-not (Select-String -LiteralPath $entry -SimpleMatch $old.Marker -Quiet)) {
        throw "Unrecognized legacy entrypoint; refusing to replace it: $entryRelative"
    }
    $legacyFiles += $entryRelative
    foreach ($module in @('core.lua','sdk_util.lua','combat.lua','world.lua','saves.lua')) {
        $legacyFiles += 'reframework\autorun\' + $old.Name + '\' + $module
    }
    if ($old.Fonts) {
        $legacyFiles += 'reframework\fonts\' + $old.Name + '\NotoSans-Regular.ttf'
        $legacyFiles += 'reframework\fonts\' + $old.Name + '\OFL.txt'
    }
}
$configTarget = Get-GameTarget 'reframework\data\project_requiem\config.json'
$configSource = $configTarget
if (-not (Test-Path -LiteralPath $configSource -PathType Leaf)) {
    $configSource = $null
    foreach ($old in $legacy) {
        $candidate = Get-GameTarget ('reframework\data\' + $old.Name + '\config.json')
        if (Test-Path -LiteralPath $candidate -PathType Leaf) { $configSource=$candidate; break }
    }
    if (-not $configSource) { $configSource=Join-Path $sourceRoot 'reframework\data\project_requiem\config.json' }
}
try { $config = Get-Content -LiteralPath $configSource -Raw -Encoding UTF8 | ConvertFrom-Json }
catch { throw "Cannot read configuration; no scripts were replaced: $configSource" }
if (-not $config -or $config -isnot [pscustomobject]) { throw 'Configuration must be a JSON object.' }
$addLanguage = -not $config.PSObject.Properties['language']
if ($addLanguage) { $config | Add-Member -NotePropertyName language -NotePropertyValue 'en' }
$writeConfig = $addLanguage -or -not (Test-Path -LiteralPath $configTarget -PathType Leaf)
$preparedConfig = $config | ConvertTo-Json -Depth 32

foreach ($relative in $ownedFiles + $legacyFiles) { Backup-OwnedFile $relative }
New-Item -ItemType Directory -Path $dataRoot -Force | Out-Null
foreach ($old in $legacy) {
    $oldData = Get-GameTarget ('reframework\data\' + $old.Name)
    if (-not (Test-Path -LiteralPath $oldData -PathType Container)) { continue }
    Get-ChildItem -LiteralPath $oldData -File -Filter '*.json' | ForEach-Object {
        # Historical runtime reports must not be presented as this version's report.
        if ($_.Name -ne 'config.json' -and $_.Name -ne 'status.json') {
            $destination = Get-GameTarget ('reframework\data\project_requiem\' + $_.Name)
            if (-not (Test-Path -LiteralPath $destination)) { Copy-Item -LiteralPath $_.FullName -Destination $destination }
        }
    }
}
foreach ($relative in $ownedFiles) {
    $target = Get-GameTarget $relative
    New-Item -ItemType Directory -Path (Split-Path -Parent $target) -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $sourceRoot $relative) -Destination $target -Force
    Write-Host "Installed $relative"
}
if ($writeConfig) {
    if (Test-Path -LiteralPath $configTarget -PathType Leaf) { Backup-OwnedFile 'reframework\data\project_requiem\config.json' }
    [System.IO.File]::WriteAllText($configTarget, $preparedConfig + [Environment]::NewLine, (New-Object System.Text.UTF8Encoding($false)))
}
# Only remove exact, backed-up legacy paths after the new scripts and data are in place.
foreach ($relative in $legacyFiles) {
    $target = Get-GameTarget $relative
    if (Test-Path -LiteralPath $target -PathType Leaf) { Remove-Item -LiteralPath $target }
}
foreach ($old in $legacy) {
    foreach ($relative in @(('reframework\autorun\' + $old.Name), ('reframework\fonts\' + $old.Name))) {
        $directory = Get-GameTarget $relative
        if ((Test-Path -LiteralPath $directory -PathType Container) -and
            @(Get-ChildItem -LiteralPath $directory -Force).Count -eq 0) {
            Remove-Item -LiteralPath $directory
        }
    }
}
if (-not (Test-Path -LiteralPath (Join-Path $gameRoot 'dinput8.dll') -PathType Leaf)) {
    Write-Warning 'Install the official RE9 build of REFramework separately.'
}
Write-Host "Project Requiem 0.3.0-pre.5 installed. Backups: $backupRoot"
Write-Host 'English is the default. Select English / Tieng Viet in the mod menu. Start the game again to activate the new scripts.'
